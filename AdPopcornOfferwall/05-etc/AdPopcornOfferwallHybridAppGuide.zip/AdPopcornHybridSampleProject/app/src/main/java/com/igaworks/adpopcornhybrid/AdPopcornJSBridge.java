package com.igaworks.adpopcornhybrid;

import android.app.Activity;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import com.igaworks.adpopcorn.IgawAdpopcorn;
public class AdPopcornJSBridge {
    public final static String INTERFACE_NAME = "adpopcornJSBridge";
    private Context context;
    private WebView webView;
    private Activity mainActivity;

    public AdPopcornJSBridge(Context context, Activity mainActivity, WebView webView) {
        this.context = context;
        this.mainActivity = mainActivity;
        this.webView = webView;
    }

    /* 애드팝콘 연동 시, 기본적으로 사용하는 setUserId와 openOfferWall의 샘플이며 추가로 더 필요한 기능이 있다면
       아래와 동일한 방식으로 JavascriptInterface 추가하여 사용.*/

    // USN 설정
    @JavascriptInterface
    public void setAdPopcornUSN(String usn) {
        try {
            IgawAdpopcorn.setUserId(context, usn);
        }catch(Exception e){}
    }

    // 오퍼월 오픈
    @JavascriptInterface
    public void openOfferwall() {
        try {
            IgawAdpopcorn.openOfferWall(mainActivity);
        }catch(Exception e){}
    }
}
