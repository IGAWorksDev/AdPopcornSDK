package com.igaworks.adpopcornhybrid;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends Activity {
    private WebView hybridWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        hybridWebView = (WebView) findViewById(R.id.hybrid_webview);

        // Javascript 사용 여부
        hybridWebView.getSettings().setJavaScriptEnabled(true);
        // AdPopcornJSBridge 등록 : 여기서 등록한 이름을 가지고 html의 javascript에서 호출(index.html 참고)
        hybridWebView.addJavascriptInterface(new AdPopcornJSBridge(this, this, hybridWebView), AdPopcornJSBridge.INTERFACE_NAME);

        hybridWebView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}


