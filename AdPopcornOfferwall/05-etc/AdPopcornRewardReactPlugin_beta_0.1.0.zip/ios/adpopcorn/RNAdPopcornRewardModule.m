//
//  RNAdPopcornRewardModule.h
//  AdPopcornRewardReactPlugin
//
//  Created by Mick on 2023/06/07.
//
#import <Foundation/Foundation.h>
#import "RNAdPopcornRewardModule.h"

@implementation RNAdPopcornRewardModule

RCT_EXPORT_MODULE(RNAdPopcornRewardModule)

- (NSArray<NSString*>*)supportedEvents
{
  return @[@"OnClosedOfferWallPage"];
}

RCT_EXPORT_METHOD(setAppKey:(NSString *)appKey hashKey:(NSString *)hashKey)
{
  dispatch_async(dispatch_get_main_queue(), ^{
    [AdPopcornOfferwall setAppKey:appKey andHashKey:hashKey];
  });
}

RCT_EXPORT_METHOD(setLogLevel:(BOOL)enable)
{
  dispatch_async(dispatch_get_main_queue(), ^{
    if(enable)
    {
      [AdPopcornOfferwall setLogLevel:AdPopcornOfferwallLogTrace];
    }
    else
    {
      [AdPopcornOfferwall setLogLevel:AdPopcornOfferwallLogOff];
    }
  });
}

RCT_EXPORT_METHOD(openOfferwall)
{
  dispatch_async(dispatch_get_main_queue(), ^{
    [AdPopcornOfferwall shared].delegate = self;
    [AdPopcornOfferwall openOfferWallWithViewController:[[[[UIApplication sharedApplication] delegate] window] rootViewController] delegate:self userDataDictionaryForFilter:nil];
  });
}

RCT_EXPORT_METHOD(openCPMOfferwall)
{
  dispatch_async(dispatch_get_main_queue(), ^{
    [AdPopcornOfferwall shared].delegate = self;
    [AdPopcornOfferwall openCPMOfferWallWithViewController:[[[[UIApplication sharedApplication] delegate] window] rootViewController] delegate:self];
  });
}

RCT_EXPORT_METHOD(openCSPage:(NSString *)userId)
{
  dispatch_async(dispatch_get_main_queue(), ^{
    [AdPopcornOfferwall openCSViewController:[[[[UIApplication sharedApplication] delegate] window] rootViewController] userId:userId];
  });
}

RCT_EXPORT_METHOD(setUserId:(NSString *)userId)
{
  [AdPopcornOfferwall setUserId:userId];
}

RCT_EXPORT_METHOD(setStyle:(NSString *)offerwallTitle useSpecialOffer:(BOOL)useSpecialOffer mainOfferwallColor:(NSString *)colorCode startTabIndex:(NSInteger)startTabIndex)
{
  if(offerwallTitle != nil)
  {
    [AdPopcornStyle sharedInstance].offerwallTitle = offerwallTitle;
  }
  
  // #RRGGBB
  if(colorCode != nil && colorCode.length == 7)
  {
    [AdPopcornStyle sharedInstance].mainOfferwallColor = [self colorFromHexString:colorCode];
  }
  
  [AdPopcornStyle sharedInstance].useSpecialOffer = useSpecialOffer;
  [AdPopcornStyle sharedInstance].startTabIndex = startTabIndex;
  
}

- (UIColor *)colorFromHexString:(NSString *)hexString {
    unsigned rgbValue = 0;
    NSScanner *scanner = [NSScanner scannerWithString:hexString];
    [scanner setScanLocation:1]; // bypass '#' character
    [scanner scanHexInt:&rgbValue];
    return [UIColor colorWithRed:((rgbValue & 0xFF0000) >> 16)/255.0 green:((rgbValue & 0xFF00) >> 8)/255.0 blue:(rgbValue & 0xFF)/255.0 alpha:1.0];
}

#pragma mark AdPopcornOfferwallDelegate
- (void)didCloseOfferWall
{
  NSLog(@"RNAdPopcornRewardModule didCloseOfferWall");
  [self sendEventWithName:@"OnClosedOfferWallPage" body:nil];
}
@end
