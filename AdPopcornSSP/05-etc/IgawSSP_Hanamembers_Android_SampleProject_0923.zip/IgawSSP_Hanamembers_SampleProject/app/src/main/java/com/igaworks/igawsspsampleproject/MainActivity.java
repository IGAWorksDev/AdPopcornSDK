package com.igaworks.igawsspsampleproject;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.igaworks.ssp.IgawSSP;
import com.igaworks.ssp.SSPErrorCode;
import com.igaworks.ssp.part.IMediationLogListener;
import com.igaworks.ssp.part.interstitial.InterstitialAd;
import com.igaworks.ssp.part.interstitial.listener.IInterstitialEventCallbackListener;
import com.igaworks.ssp.part.video.IgawRewardVideoAd;
import com.igaworks.ssp.part.video.listener.IRewardVideoAdEventCallbackListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;


public class MainActivity extends Activity {
    private boolean completeloadAndShow = false;
    private IgawRewardVideoAd igawRewardVideoAd;
    private InterstitialAd igawInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 1. IgawSSP SDK 초기화
        IgawSSP.init(MainActivity.this);

        // 2. CS 처리를 위한 usn 세팅 추가.
        IgawSSP.setUserId(this, "TEST_USN");

        // 3. igaw reward video ad 생성
        igawRewardVideoAd = new IgawRewardVideoAd(this);

        // 4. AP SSP에서 발급 받은 placement id 설정
        igawRewardVideoAd.setPlacementId("wzbu2ob62if5zth");

        // 5. 이벤트 콜백 리스너 설정
        igawRewardVideoAd.setRewardVideoAdEventCallbackListener(iRewardVideoAdEventCallbackListener);

        Button button_reward_video_load = findViewById(R.id.button_reward_video_load_show);
        button_reward_video_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 6. 광고 요청
                completeloadAndShow = false;
                igawRewardVideoAd.loadAd();
            }
        });

        Button button_open_cs_page = findViewById(R.id.button_open_cs_page);
        button_open_cs_page.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 11. 리워드 비디오 CS 페이지 열기
                IgawSSP.openRewardVideoCSPage(MainActivity.this, "TEST_USN");
            }
        });

        // 7. 로그 이벤트 리스너 설정
        igawRewardVideoAd.setMediationLogListener(new IMediationLogListener() {

            @Override
            public void OnMediationLoadStart(String placementId, int networkId) {
                // 네트워크 ID List
                // 0: IGAW
                // 1: AdMob
                // 7: UnityAds
                // 8: Mintegral
                // 11: AppNext
                // 13: AdColony
                // 14: Vungle
                // 15: AppLovin

                // 6. ADID 정보 가져오기
                String adid = IgawSSP.getADID();
                Log.i("IgawSSPSample", "ADID : " + adid + ", OnMediationLoadStart : " + networkId);
            }

            @Override
            public void OnMediationLoadSuccess(String placementId, int networkId) {
                // 네트워크 ID List
                // 0: IGAW
                // 1: AdMob
                // 7: UnityAds
                // 8: Mintegral
                // 11: AppNext
                // 13: AdColony
                // 14: Vungle
                // 15: AppLovin

                // 6. ADID 정보 가져오기
                String adid = IgawSSP.getADID();
                Log.i("IgawSSPSample", "ADID : " + adid + ", OnMediationLoadSuccess : " + networkId);
            }

            @Override
            public void OnMediationLoadFailed(String placementId, int networkId) {
                // 네트워크 ID List
                // 0: IGAW
                // 1: AdMob
                // 7: UnityAds
                // 8: Mintegral
                // 11: AppNext
                // 13: AdColony
                // 14: Vungle
                // 15: AppLovin

                // 6. ADID 정보 가져오기
                String adid = IgawSSP.getADID();
                Log.i("IgawSSPSample", "ADID : " + adid + ", OnMediationLoadFailed : " + networkId);
            }
        });

        // 20200217 added code : UnityAds의 timeout 시간 변경을 위해 mediation timeout 시간 증가 기본 10초 -> 105초
        igawRewardVideoAd.setNetworkScheduleTimeout(15);

        // 20200217 added code : No Ad시, 전면 광고 호출 하기 위한 전면 광고 생성 코드
        igawInterstitialAd = new InterstitialAd(this);
        igawInterstitialAd.setPlacementId("r1x5eof1o4vkt1v");
        igawInterstitialAd.setInterstitialEventCallbackListener(interstitialEventCallbackListener);

        // 20200226 : 전면 광고 배경색 변경 옵션 코드 추가
        HashMap extras = new HashMap<>();
        extras.put(InterstitialAd.CustomExtraData.IGAW_AD_BACKGROUND_COLOR, Color.parseColor(
                "#66000000"));
        igawInterstitialAd.setCustomExtras(extras);
    }

    IRewardVideoAdEventCallbackListener iRewardVideoAdEventCallbackListener = new IRewardVideoAdEventCallbackListener() {
        @Override
        public void OnRewardVideoAdLoaded() {
            // 광고 로드 성공
            Toast.makeText(MainActivity.this, "OnRewardVideoAdLoaded", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdLoaded : " + completeloadAndShow);
            if(igawRewardVideoAd.isReady() && !completeloadAndShow)
                igawRewardVideoAd.showAd();

            // 현재 동작 중인 네트워크 이름 체크 API
            // 0: IGAW
            // 1: AdMob
            // 7: UnityAds
            // 8: Mintegral
            // 11: AppNext
            // 13: AdColony
            // 14: Vungle
            // 15: AppLovin
            int networkNum = -1;
            if(igawRewardVideoAd != null)
                networkNum = igawRewardVideoAd.getCurrentNetwork();
            Log.i("IgawSSPSample", "OnRewardVideoAdLoaded networkNum : " + networkNum);
        }

        @Override
        public void OnRewardVideoAdLoadFailed(SSPErrorCode sspErrorCode) {
            // 광고 로드 실패
            Toast.makeText(MainActivity.this, "OnRewardVideoAdLoadFailed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdLoadFailed");

            // 20200217 added code : 리워드 비디오 광고 No ad 시 전면 광고 호출
            if(sspErrorCode != null && sspErrorCode.getErrorCode() == 5002){
                if(igawInterstitialAd != null)
                    igawInterstitialAd.loadAd();
            }
        }

        @Override
        public void OnRewardVideoAdOpened() {
            Toast.makeText(MainActivity.this, "OnRewardVideoShowSuccess", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoShowSuccess");
            completeloadAndShow = true;
        }

        @Override
        public void OnRewardVideoAdOpenFalied() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed");
            completeloadAndShow = true;
        }

        @Override
        public void OnRewardVideoAdClosed() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed");
            completeloadAndShow = true;
        }

        @Override
        public void OnRewardVideoPlayCompleted(int networkId, boolean completed) {
            completeloadAndShow = true;
            Toast.makeText(MainActivity.this, "OnAdPopcornSSPVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnAdPopcornSSPVideoCompleted");
            onCompletedRewardVideoAd();
        }
    };

    IInterstitialEventCallbackListener interstitialEventCallbackListener =
            new IInterstitialEventCallbackListener() {
        @Override
        public void OnInterstitialLoaded() {
            Log.i("IgawSSPSample", "OnInterstitialLoaded");
            Toast.makeText(MainActivity.this, "OnInterstitialLoaded : " + igawInterstitialAd.getCurrentNetwork(), Toast.LENGTH_SHORT).show();
            // 20200217 added code : 전면 광고가 성공적으로 로드된 경우, 전면 광고 노출
            if(igawInterstitialAd != null && igawInterstitialAd.isLoaded())
                igawInterstitialAd.showAd();
        }

        @Override
        public void OnInterstitialOpened() {
            Log.i("IgawSSPSample", "OnInterstitialOpened");
            Toast.makeText(MainActivity.this, "OnInterstitialOpened", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void OnInterstitialReceiveFailed(SSPErrorCode errorCode) {
            Log.i("IgawSSPSample", "OnInterstitialReceiveFailed : " + errorCode.getErrorCode() + ", errorMessage : " + errorCode.getErrorMessage());
            Toast.makeText(MainActivity.this, "OnInterstitialReceiveFailed : " + errorCode.getErrorCode() + ", errorMessage : " + errorCode.getErrorMessage(), Toast.LENGTH_SHORT).show();
            // 20200217, added code : 전면 광고도 없는 경우 최종 No Ad
        }

        @Override
        public void OnInterstitialOpenFailed(SSPErrorCode errorCode) {
            Log.i("IgawSSPSample", "OnInterstitialOpenFailed : " + errorCode.getErrorCode() + ", errorMessage : " + errorCode.getErrorMessage());
            Toast.makeText(MainActivity.this, "OnInterstitialOpenFailed : " + errorCode.getErrorCode() + ", errorMessage : " + errorCode.getErrorMessage(), Toast.LENGTH_SHORT).show();
        }


        @Override
        public void OnInterstitialClosed(int closeEvent) {
            Log.i("IgawSSPSample", "OnInterstitialClosed : " + closeEvent);
        }
    };

    private void onCompletedRewardVideoAd(){
        // 리워드 비디오가 정상적으로 종료 되었을 때 처리.
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 8. Activity Life cycle에 맞춰 onResume 연동
        if(igawRewardVideoAd != null)
            igawRewardVideoAd.onResume();
        if(igawInterstitialAd != null)
            igawInterstitialAd.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 9. Activity Life cycle에 맞춰 onResume 연동
        if(igawRewardVideoAd != null)
            igawRewardVideoAd.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 10. 종료.
        if(igawRewardVideoAd != null)
            igawRewardVideoAd.destroy();
        if(igawInterstitialAd != null)
            igawInterstitialAd.destroy();
        IgawSSP.destroy();
    }
}


