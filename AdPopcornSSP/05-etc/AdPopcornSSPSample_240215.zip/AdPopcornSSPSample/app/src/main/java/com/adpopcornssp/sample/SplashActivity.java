package com.adpopcornssp.sample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;

import com.igaworks.ssp.AdPopcornSSP;
import com.igaworks.ssp.SSPErrorCode;
import com.igaworks.ssp.part.splash.AdPopcornSSPSplashAd;
import com.igaworks.ssp.part.splash.listener.ISplashAdEventCallbackListener;

import java.util.Calendar;

public class SplashActivity extends Activity{
    private AdPopcornSSPSplashAd splashAd;
    private String appKey = "663451319";
    private String placementId = "SPLASH";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        AdPopcornSSP.init(this);

        splashAd = findViewById(R.id.adpopcorn_splash_ad);
        splashAd.setPlacementAppKey(appKey);
        splashAd.setPlacementId(placementId);

        // 전면 스플래시와 정사각 스플래시를 랜덤하게 노출 시키기 위한 코드 분기
        if(Calendar.getInstance().getTimeInMillis() % 2 == 0) {
            findViewById(R.id.adpopcorn_splash_logo).setVisibility(View.GONE);
            splashAd.setFullScreenSplash(true);
            splashAd.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        }
        splashAd.setSplashAdEventCallbackListener(new ISplashAdEventCallbackListener() {
            @Override
            public void onSplashAdLoadSuccess() {
                Log.i("AdPopcornSSPTestApp", "splashAd onSplashAdLoadSuccess");
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }, 3000);
            }

            @Override
            public void onSplashAdLoadFailed(SSPErrorCode errorCode) {
                Log.i("AdPopcornSSPTestApp", "splashAd onSplashAdLoadFailed");
                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void onImpression() {
                Log.i("AdPopcornSSPTestApp", "splashAd onImpression");
            }
        });

        splashAd.loadAd();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(splashAd != null)
            splashAd.destroy();
    }
}

