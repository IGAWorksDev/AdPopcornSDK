//
//  RNAdPopcornNativeAdViewManager.m
//  AdPopcornSSPReactPlugin
//
//  Created by 김민석 on 2023/11/22.
//

#import <Foundation/Foundation.h>
#import "RNAdPopcornNativeAdView.h"

@interface RNAdPopcornNativeAdViewManager : RCTViewManager
@end

@implementation RNAdPopcornNativeAdViewManager

RCT_EXPORT_MODULE(RNAdPopcornNativeAdView);

- (UIView *)view
{
  RNAdPopcornNativeAdView *reactNativeAd = [RNAdPopcornNativeAdView new];
  return reactNativeAd;
}

RCT_EXPORT_VIEW_PROPERTY(appKey, NSString)
RCT_EXPORT_VIEW_PROPERTY(placementId, NSString)
RCT_EXPORT_VIEW_PROPERTY(nativeWidth, NSInteger)
RCT_EXPORT_VIEW_PROPERTY(nativeHeight, NSInteger)

RCT_EXPORT_VIEW_PROPERTY(onNativeAdLoadSuccess, RCTDirectEventBlock)
RCT_EXPORT_VIEW_PROPERTY(onNativeAdLoadFailed, RCTDirectEventBlock)
RCT_EXPORT_VIEW_PROPERTY(onNativeImpression, RCTDirectEventBlock)
RCT_EXPORT_VIEW_PROPERTY(onNativeClicked, RCTDirectEventBlock)
@end
