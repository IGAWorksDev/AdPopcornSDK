//
//  RNAdPopcornInterstitialVideoAdModule.m
//  AdPopcornSSPReactPlugin
//
//  Created by 김민석 on 2023/05/18.
//

#import <Foundation/Foundation.h>
#import "RNAdPopcornInterstitialVideoAdModule.h"

@implementation RNAdPopcornInterstitialVideoAdModule

RCT_EXPORT_MODULE(RNAdPopcornInterstitialVideoAdModule)

@synthesize dictionary = _dictionary;
- (NSArray<NSString*>*)supportedEvents
{
  return @[@"OnInterstitialVideoAdLoaded", @"OnInterstitialVideoAdLoadFailed", @"OnInterstitialVideoAdOpened", @"OnInterstitialVideoAdOpenFalied", @"OnInterstitialVideoAdClosed", @"OnInterstitialVideoAdClicked"];
}

RCT_EXPORT_METHOD(createInstance:(NSString *)appKey placementId:(NSString *)placementId)
{
  if(_dictionary == nil)
  {
    _dictionary = [[NSMutableDictionary alloc] init];
  }
  
  if([_dictionary objectForKey:placementId])
  {
    NSLog(@"createInstance already exist rewardVideoAd placementId : %@", placementId);
    [_dictionary removeObjectForKey:placementId];
  }
  else
  {
    NSLog(@"createInstance rewardVideoAd placementId : %@", placementId);
  }
  
  AdPopcornSSPInterstitialVideoAd *interstitialVideoAd = [[AdPopcornSSPInterstitialVideoAd alloc] initWithKey:appKey placementId:placementId viewController:[[[[UIApplication sharedApplication] delegate] window] rootViewController]];
  interstitialVideoAd.placementId = placementId;
  [_dictionary setObject:interstitialVideoAd forKey:placementId];
}

RCT_EXPORT_METHOD(loadAd:(NSString *)placementId)
{
  NSLog(@"rewardVideoAd loadAd : %@", placementId);
  if(_dictionary == nil || [_dictionary objectForKey:placementId] == nil)
    return;
  AdPopcornSSPInterstitialVideoAd *interstitialVideoAd = [_dictionary objectForKey:placementId];
  if(interstitialVideoAd)
  {
    interstitialVideoAd.delegate = self;
    [interstitialVideoAd loadRequest];
  }
}

RCT_EXPORT_METHOD(showAd:(NSString *)placementId)
{
  NSLog(@"rewardVideoAd showAd : %@", placementId);
  if(_dictionary == nil || [_dictionary objectForKey:placementId] == nil)
    return;
  AdPopcornSSPInterstitialVideoAd *interstitialVideoAd = [_dictionary objectForKey:placementId];
  if(interstitialVideoAd)
  {
    // UI관련 작업을 main스레드에서 실행
    dispatch_async(dispatch_get_main_queue(), ^{
      interstitialVideoAd.delegate = self;
      [interstitialVideoAd presentFromViewController:[UIApplication sharedApplication].delegate.window.rootViewController];
    });
  }
}

#pragma mark APSSPInterstitialVideoAdDelegate
/*!
 @abstract
 interstitial video 광고 로드에 성공한 경우 호출된다.
 */
- (void)APSSPInterstitialVideoAdLoadSuccess:(AdPopcornSSPInterstitialVideoAd *)interstitialVideoAd
{
  NSLog(@"interstitialVideo APSSPInterstitialVideoAdLoadSuccess : %@", interstitialVideoAd.placementId);
  [self sendEventWithName:@"OnInterstitialVideoAdLoaded" body:@{@"placementId": interstitialVideoAd.placementId}];
}

/*!
 @abstract
 interstitial video 광고 로드에 실패한 경우 호출된다.
 */
- (void)APSSPInterstitialVideoAdLoadFail:(AdPopcornSSPInterstitialVideoAd *)interstitialVideoAd error:(AdPopcornSSPError *)error
{
  NSLog(@"interstitialVideo APSSPInterstitialVideoAdLoadFail : %@", interstitialVideoAd.placementId);
  [self sendEventWithName:@"OnInterstitialVideoAdLoadFailed" body:(@{
    @"errorCode": @(error.code),
    @"errorMessage": error.userInfo.description,
    @"placementId": interstitialVideoAd.placementId
  })];
}

/*!
 @abstract
 interstitial video 광고가 정상적으로 노출될 때 호출된다.
 */
- (void)APSSPInterstitialVideoAdShowSuccess:(AdPopcornSSPInterstitialVideoAd *)interstitialVideoAd
{
  NSLog(@"interstitialVideo APSSPInterstitialVideoAdShowSuccess : %@", interstitialVideoAd.placementId);
  [self sendEventWithName:@"OnInterstitialVideoAdOpened" body:@{@"placementId": interstitialVideoAd.placementId}];
}

/*!
 @abstract
 interstitial video 광고가 노출에 실패했을 때 호출된다.
 */
- (void)APSSPInterstitialVideoAdShowFail:(AdPopcornSSPInterstitialVideoAd *)interstitialVideoAd
{
  NSLog(@"interstitialVideo APSSPInterstitialVideoAdShowFail : %@", interstitialVideoAd.placementId);
  [self sendEventWithName:@"OnInterstitialVideoAdOpenFalied" body:@{@"placementId": interstitialVideoAd.placementId}];
}

/*!
 @abstract
 interstitial video 광고가 닫히면 호출된다.
 */
- (void)APSSPInterstitialVideoAdClosed:(AdPopcornSSPInterstitialVideoAd *)interstitialVideoAd
{
  NSLog(@"interstitialVideo APSSPInterstitialVideoAdClosed : %@", interstitialVideoAd.placementId);
  [self sendEventWithName:@"OnInterstitialVideoAdClosed" body:@{@"placementId": interstitialVideoAd.placementId}];
}
@end
