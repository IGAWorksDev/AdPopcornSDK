//
//  RNAdPopcornRewardVideoAdModule.m
//  AdPopcornSSPReactPlugin
//
//  Created by 김민석 on 2023/05/17.
//

#import <Foundation/Foundation.h>
#import "RNAdPopcornRewardVideoAdModule.h"

@implementation RNAdPopcornRewardVideoAdModule

RCT_EXPORT_MODULE(RNAdPopcornRewardVideoAdModule)

@synthesize dictionary = _dictionary;
- (NSArray<NSString*>*)supportedEvents
{
  return @[@"OnRewardVideoAdLoaded", @"OnRewardVideoAdLoadFailed", @"OnRewardVideoAdOpened", @"OnRewardVideoAdOpenFalied", @"OnRewardVideoAdClosed", @"OnRewardVideoPlayCompleted"];
}

RCT_EXPORT_METHOD(createInstance:(NSString *)appKey placementId:(NSString *)placementId)
{
  if(_dictionary == nil)
  {
    _dictionary = [[NSMutableDictionary alloc] init];
  }
  
  if([_dictionary objectForKey:placementId])
  {
    NSLog(@"createInstance already exist rewardVideoAd placementId : %@", placementId);
    [_dictionary removeObjectForKey:placementId];
  }
  else
  {
    NSLog(@"createInstance rewardVideoAd placementId : %@", placementId);
  }
  
  AdPopcornSSPRewardVideoAd *rewardVideoAd = [[AdPopcornSSPRewardVideoAd alloc] initWithKey:appKey placementId:placementId viewController:[[[[UIApplication sharedApplication] delegate] window] rootViewController]];
  rewardVideoAd.placementId = placementId;
  [_dictionary setObject:rewardVideoAd forKey:placementId];
}

RCT_EXPORT_METHOD(loadAd:(NSString *)placementId)
{
  NSLog(@"rewardVideoAd loadAd : %@", placementId);
  if(_dictionary == nil || [_dictionary objectForKey:placementId] == nil)
    return;
  AdPopcornSSPRewardVideoAd *rewardVideoAd = [_dictionary objectForKey:placementId];
  if(rewardVideoAd)
  {
    rewardVideoAd.delegate = self;
    [rewardVideoAd loadRequest];
  }
}

RCT_EXPORT_METHOD(showAd:(NSString *)placementId)
{
  NSLog(@"rewardVideoAd showAd : %@", placementId);
  if(_dictionary == nil || [_dictionary objectForKey:placementId] == nil)
    return;
  AdPopcornSSPRewardVideoAd *rewardVideoAd = [_dictionary objectForKey:placementId];
  if(rewardVideoAd)
  {
    // UI관련 작업을 main스레드에서 실행
    dispatch_async(dispatch_get_main_queue(), ^{
      rewardVideoAd.delegate = self;
      [rewardVideoAd presentFromViewController:[UIApplication sharedApplication].delegate.window.rootViewController];
    });
  }
}

#pragma mark APSSPRewardVideoAdDelegate
/*
 @abstract
 video 광고 로드에 성공한 경우 호출된다.
 */
- (void)APSSPRewardVideoAdLoadSuccess:(AdPopcornSSPRewardVideoAd *)rewardVideoAd
{
  NSLog(@"rewardVideoAd APSSPRewardVideoAdLoadSuccess : %@", rewardVideoAd.placementId);
  [self sendEventWithName:@"OnRewardVideoAdLoaded" body:@{@"placementId": rewardVideoAd.placementId}];
}
/*!
 @abstract
 video 광고 로드에 실패한 경우 호출된다.
 */
- (void)APSSPRewardVideoAdLoadFail:(AdPopcornSSPRewardVideoAd *)rewardVideoAd error:(AdPopcornSSPError *)error
{
  NSLog(@"rewardVideoAd APSSPRewardVideoAdLoadFail : %@", rewardVideoAd.placementId);
  [self sendEventWithName:@"OnRewardVideoAdLoadFailed" body:(@{
    @"errorCode": @(error.code),
    @"errorMessage": error.userInfo.description,
    @"placementId": rewardVideoAd.placementId
  })];
}
/*!
 @abstract
 video 광고가 정상적으로 노출될 때 호출된다.
 */
- (void)APSSPRewardVideoAdShowSuccess:(AdPopcornSSPRewardVideoAd *)rewardVideoAd
{
  NSLog(@"rewardVideoAd APSSPRewardVideoAdShowSuccess : %@", rewardVideoAd.placementId);
  [self sendEventWithName:@"OnRewardVideoAdOpened" body:@{@"placementId": rewardVideoAd.placementId}];
}

/*!
 @abstract
 video 광고가 노출에 실패했을 때 호출된다.
 */
- (void)APSSPRewardVideoAdShowFail:(AdPopcornSSPRewardVideoAd *)rewardVideoAd
{
  NSLog(@"rewardVideoAd APSSPRewardVideoAdShowFail : %@", rewardVideoAd.placementId);
  [self sendEventWithName:@"OnRewardVideoAdOpenFalied" body:@{@"placementId": rewardVideoAd.placementId}];
}

/*!
 @abstract
 video 광고가 닫히면 호출된다.
 */
- (void)APSSPRewardVideoAdClosed:(AdPopcornSSPRewardVideoAd *)rewardVideoAd
{
  NSLog(@"rewardVideoAd APSSPRewardVideoAdClosed : %@", rewardVideoAd.placementId);
  [self sendEventWithName:@"OnRewardVideoAdClosed" body:@{@"placementId": rewardVideoAd.placementId}];
}

/*!
 @abstract
 AP SSP reward video 재생 완료 시 호출된다.
 */
- (void)APSSPRewardVideoAdPlayCompleted:(AdPopcornSSPRewardVideoAd *)rewardVideoAd adNetworkNo:(long) adNetworkNo completed:(BOOL)completed
{
  NSLog(@"rewardVideoAd APSSPRewardVideoAdPlayCompleted : %@", rewardVideoAd.placementId);
  [self sendEventWithName:@"OnRewardVideoPlayCompleted" body:@{@"placementId": rewardVideoAd.placementId}];
}
@end

