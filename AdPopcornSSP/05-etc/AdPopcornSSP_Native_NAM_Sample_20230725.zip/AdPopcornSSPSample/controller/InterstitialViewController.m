//
//  InterstitialViewController.m
//  AdPopcornSSPSample
//
//  Created by 김민석 on 2019. 5. 9..
//  Copyright © 2019년 igaworks. All rights reserved.
//

#import "InterstitialViewController.h"
#import <AdPopcornSSP/AdPopcornSSPInterstitialAd.h>

@interface InterstitialViewController ()<APSSPInterstitialAdDelegate>{
    AdPopcornSSPInterstitialAd *_sspInterstitialAd;
}

@end

@implementation InterstitialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // 사업팀을 통해 발급 받은 appKey, placementID를 입력하여 사용
    _sspInterstitialAd = [[AdPopcornSSPInterstitialAd alloc] initWithKey:@"62198111" placementId:@"m4u84dnnns12v6v" viewController:self];
    
    _sspInterstitialAd.delegate = self;
    
    [_sspInterstitialAd loadRequest];
}

#pragma  mark - APSSPInterstitialAdDelegate
- (void)APSSPInterstitialAdLoadSuccess:(AdPopcornSSPInterstitialAd *)interstitialAd
{
    NSLog(@"APSSPInterstitialAdLoadSuccess : %@", interstitialAd);
    [_sspInterstitialAd presentFromViewController:self];
}

- (void)APSSPInterstitialAdLoadFail:(AdPopcornSSPInterstitialAd *)interstitialAd error:(AdPopcornSSPError *)error
{
    NSLog(@"APSSPInterstitialAdLoadFail : %@, error : %@", interstitialAd, error);
}

- (void)APSSPInterstitialAdClosed:(AdPopcornSSPInterstitialAd *)interstitialAd
{
    NSLog(@"APSSPInterstitialAdClosed : %@", interstitialAd);
}

- (void)APSSPInterstitialAdClicked:(AdPopcornSSPInterstitialAd *)interstitialAd
{
    NSLog(@"APSSPInterstitialAdClicked : %@", interstitialAd);
}

- (void)APSSPInterstitialAdShowSuccess:(AdPopcornSSPInterstitialAd *)interstitialAd
{
    NSLog(@"APSSPInterstitialAdShowSuccess : %@", interstitialAd);
}

- (void)APSSPInterstitialAdShowFail:(AdPopcornSSPInterstitialAd *)interstitialAd error:(AdPopcornSSPError *)error
{
    NSLog(@"APSSPInterstitialAdShowFail : %@", interstitialAd);
}
@end
