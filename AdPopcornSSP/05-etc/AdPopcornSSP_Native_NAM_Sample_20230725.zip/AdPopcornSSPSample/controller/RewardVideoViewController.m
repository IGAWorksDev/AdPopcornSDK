//
//  RewardVideoViewController.m
//  AdPopcornSSPSample
//
//  Created by 김민석 on 2019. 5. 9..
//  Copyright © 2019년 igaworks. All rights reserved.
//

#import "RewardVideoViewController.h"
#import "AdPopcornSSP/AdPopcornSSPRewardVideoAd.h"

@interface RewardVideoViewController() <APSSPRewardVideoAdDelegate>{
    AdPopcornSSPRewardVideoAd *_sspRewardVideoAd;
}

@end

@implementation RewardVideoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // 사업팀을 통해 발급 받은 appKey, placementID를 입력하여 사용
    _sspRewardVideoAd = [[AdPopcornSSPRewardVideoAd alloc] initWithKey:@"62198111" placementId:@"bD8hmhrDoBu3dpf" viewController:self];
    _sspRewardVideoAd.delegate = self;
     [_sspRewardVideoAd loadRequest];
    
}
#pragma mark APSSPRewardVideoAdDelegate
- (void)APSSPRewardVideoAdLoadSuccess:(AdPopcornSSPRewardVideoAd *)rewardVideoAd
{
    NSLog(@"AdPopcornSSPLoadRewardVideoAdSuccess");
    if([_sspRewardVideoAd isReady])
        [_sspRewardVideoAd presentFromViewController:self];
}

- (void)APSSPRewardVideoAdLoadFail:(AdPopcornSSPRewardVideoAd *)rewardVideoAd error:(AdPopcornSSPError *)error
{
    NSLog(@"APSSPRewardVideoAdLoadFail : %@", error);
}

- (void)APSSPRewardVideoAdShowSuccess:(AdPopcornSSPRewardVideoAd *)rewardVideoAd
{
    NSLog(@"APSSPRewardVideoAdShowSuccess");
}

- (void)APSSPRewardVideoAdShowFail:(AdPopcornSSPRewardVideoAd *)rewardVideoAd
{
    NSLog(@"APSSPRewardVideoAdShowFail");
}

- (void)APSSPRewardVideoAdClosed:(AdPopcornSSPRewardVideoAd *)rewardVideoAd
{
    NSLog(@"APSSPRewardVideoAdClosed");
}

- (void)APSSPRewardVideoAdPlayCompleted:(AdPopcornSSPRewardVideoAd *)rewardVideoAd adNetworkNo:(long)adNetworkNo completed:(BOOL)completed
{
    NSLog(@"APSSPRewardVideoAdPlayCompleted %ld, completed : %d", adNetworkNo, completed);
}
@end
