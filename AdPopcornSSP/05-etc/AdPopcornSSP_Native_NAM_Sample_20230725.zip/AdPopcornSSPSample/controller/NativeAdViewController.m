//
//  NativeAdViewController.m
//  AdPopcornSSPSample
//
//  Created by 김민석 on 2019. 5. 9..
//  Copyright © 2019년 igaworks. All rights reserved.
//

#import "NativeAdViewController.h"
#import <AdPopcornSSP/AdPopcornSSPNativeAd.h>

@interface NativeAdViewController () <APSSPNativeAdDelegate>
{
}

// AdPopcornSSPNativeAd
@property (strong, nonatomic) IBOutlet AdPopcornSSPNativeAd *adPopcornSSPNativeAd;

// APSSP NativeAd View
@property (strong, nonatomic) IBOutlet UIView *apSSPNativeAdView;
@property (strong, nonatomic) IBOutlet UIImageView *apSSPIconImageView;
@property (strong, nonatomic) IBOutlet UIImageView *apSSPMainImageView;
@property (strong, nonatomic) IBOutlet UILabel *apSSPTitleView;
@property (strong, nonatomic) IBOutlet UILabel *apSSPDescView;
@property (strong, nonatomic) IBOutlet UILabel *apSSPCTAView;

@end

@implementation NativeAdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    // 1. AdPopcornSSPNativeAd 생성
    // storyboard에 AdPopcornSSPNativeAd 영역 지정 후 아울렛 연결
    // 사업팀을 통해 발급 받은 appKey, placementID를 입력하여 사용
    //[_adPopcornSSPNativeAd setPlacementInfoWithAppKey:@"62198111" placementId:@"xeh6ti3z7v9ozcw" viewController:self];
    _adPopcornSSPNativeAd.delegate = self;
    
    // 2. storyboard 에 직접 ui component add(adpopcorn ssp, fan)
    // 2.1 apssp
    APSSPNativeAdRenderer *apSSPNativeAdRenderer = [[APSSPNativeAdRenderer alloc] init];
    apSSPNativeAdRenderer.apSSPNativeAdView = _apSSPNativeAdView;
    apSSPNativeAdRenderer.titleLabel = _apSSPTitleView;
    apSSPNativeAdRenderer.descLabel = _apSSPDescView;
    apSSPNativeAdRenderer.mainImageView = _apSSPMainImageView;
    apSSPNativeAdRenderer.iconImageView = _apSSPIconImageView;
    apSSPNativeAdRenderer.ctaLabel = _apSSPCTAView;
    [_adPopcornSSPNativeAd setApSSPRenderer:apSSPNativeAdRenderer superView:_apSSPNativeAdView];
    
    [_adPopcornSSPNativeAd loadRequest];
}

#pragma APSSPNativeAdDelegate
- (void)APSSPNativeAdLoadSuccess:(AdPopcornSSPNativeAd *)nativeAd
{
    NSLog(@"APSSPNativeAdLoadSuccess");
}

- (void)APSSPNativeAdLoadFail:(AdPopcornSSPNativeAd *)nativeAd error:(AdPopcornSSPError *)error
{
    NSLog(@"APSSPNativeAdLoadFail : %@", error);
}

- (void)APSSPNativeAdImpression:(AdPopcornSSPNativeAd *)nativeAd
{
    NSLog(@"APSSPNativeAdImpression");
}

- (void)APSSPNativeAdClicked:(AdPopcornSSPNativeAd *)nativeAd
{
    NSLog(@"APSSPNativeAdClicked");
}

@end
