//
//  InterstitialVideoViewController.m
//  AdPopcornSSPSample
//
//  Created by 김민석 on 2019. 5. 9..
//  Copyright © 2019년 igaworks. All rights reserved.
//

#import "InterstitialVideoViewController.h"
#import "AdPopcornSSP/AdPopcornSSPInterstitialVideoAd.h"

@interface InterstitialVideoViewController() <APSSPInterstitialVideoAdDelegate>{
    AdPopcornSSPInterstitialVideoAd *_sspInterstitialVideoAd;
}
@end

@implementation InterstitialVideoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // 사업팀을 통해 발급 받은 appKey, placementID를 입력하여 사용
    _sspInterstitialVideoAd = [[AdPopcornSSPInterstitialVideoAd alloc] initWithKey:@"62198111" placementId:@"bt1qp32zn49g9so" viewController:self];
    _sspInterstitialVideoAd.delegate = self;
    [_sspInterstitialVideoAd loadRequest];
    
}
#pragma mark APSSPInterstitialVideoAdDelegate
/*!
 @abstract
 interstitial video 광고 로드에 성공한 경우 호출된다.
 */
- (void)APSSPInterstitialVideoAdLoadSuccess:(AdPopcornSSPInterstitialVideoAd *)interstitialVideoAd
{
    NSLog(@"APSSPInterstitialVideoAdLoadSuccess");
    if([_sspInterstitialVideoAd isReady])
        [_sspInterstitialVideoAd presentFromViewController:self];
}

/*!
 @abstract
 interstitial video 광고 로드에 실패한 경우 호출된다.
 */
- (void)APSSPInterstitialVideoAdLoadFail:(AdPopcornSSPInterstitialVideoAd *)interstitialVideoAd error:(AdPopcornSSPError *)error
{
    NSLog(@"APSSPInterstitialVideoAdLoadFail");
}

/*!
 @abstract
 interstitial video 광고가 정상적으로 노출될 때 호출된다.
 */
- (void)APSSPInterstitialVideoAdShowSuccess:(AdPopcornSSPInterstitialVideoAd *)interstitialVideoAd
{
    NSLog(@"APSSPInterstitialVideoAdShowSuccess");
}

/*!
 @abstract
 interstitial video 광고가 노출에 실패했을 때 호출된다.
 */
- (void)APSSPInterstitialVideoAdShowFail:(AdPopcornSSPInterstitialVideoAd *)interstitialVideoAd
{
    NSLog(@"APSSPInterstitialVideoAdShowFail");
}

/*!
 @abstract
 interstitial video 광고가 닫히면 호출된다.
 */
- (void)APSSPInterstitialVideoAdClosed:(AdPopcornSSPInterstitialVideoAd *)interstitialVideoAd
{
    NSLog(@"APSSPInterstitialVideoAdClosed");
}
@end
