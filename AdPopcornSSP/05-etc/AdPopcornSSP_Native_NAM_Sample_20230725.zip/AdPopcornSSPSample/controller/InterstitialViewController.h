//
//  InterstitialViewController.h
//  AdPopcornSSPSample
//
//  Created by 김민석 on 2019. 5. 9..
//  Copyright © 2019년 igaworks. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface InterstitialViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
