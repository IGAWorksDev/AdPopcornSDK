//
//  BannerViewController.m
//  AdPopcornSSPSample
//
//  Created by 김민석 on 2019. 5. 9..
//  Copyright © 2019년 igaworks. All rights reserved.
//

#import "BannerViewController.h"

#import <AdPopcornSSP/AdPopcornSSPBannerView.h>
#import <AdPopcornSSP/AdPopcornSSPAdSize.h>
#import <AdPopcornSSP/AdPopcornSSP.h>
#import <AdPopcornSSP/AdPopcornSSPWKScriptMessageHandler.h>

@interface BannerViewController () <APSSPBannerViewDelegate>
{
    AdPopcornSSPBannerView *_bannerView, *_secondBannerView;
}


@end

@implementation BannerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    float bottomArea = 0;
    float topArea = 0;
    if (@available(iOS 11.0, *)) {
        if([UIApplication sharedApplication].keyWindow.safeAreaInsets.bottom > 0)
        {
            bottomArea = [UIApplication sharedApplication].keyWindow.safeAreaInsets.bottom;
        }
        
        if([UIApplication sharedApplication].keyWindow.safeAreaInsets.top > 0)
        {
            topArea = [UIApplication sharedApplication].keyWindow.safeAreaInsets.top;
        }
        else
        {
            CGRect statusBarRect = [[UIApplication sharedApplication] statusBarFrame];
            topArea = statusBarRect.size.height;
        }
        
        if(self.navigationController.navigationBar.frame.size.height > 0)
        {
            topArea = topArea + self.navigationController.navigationBar.frame.size.height;
        }
            
    }
    else
    {
        CGRect statusBarRect = [[UIApplication sharedApplication] statusBarFrame];
        topArea = statusBarRect.size.height;
    }
    
    // 사업팀을 통해 발급 받은 appKey, placementID를 입력하여 사용
    // Case1. ViewController에 AdPopcornSSPBannerView add하여 사용하고자 하는 경우.
    _bannerView = [[AdPopcornSSPBannerView alloc] initWithBannerViewSize:SSPBannerViewSize320x50 origin:CGPointMake(0.0f, self.view.frame.size.height - [AdPopcornSSPAdSize adSize:SSPBannerViewSize320x50].height - bottomArea) appKey:@"62198111" placementId:@"h488eh220khbz9c" viewController:self];
    _bannerView.adRefreshRate = 60;
    _bannerView.delegate = self;
    [_bannerView loadRequest];
    
    // Case2. 특정 UIView에 AdPopcornSSPBannerView를 add하여 사용하고자 하는 경우.
    UIView *secondBannerParentView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, topArea + 100.0f, [UIScreen mainScreen].bounds.size.width, 250.0f)];
    [self.view addSubview:secondBannerParentView];
    
    _secondBannerView = [[AdPopcornSSPBannerView alloc] initWithBannerViewSize:SSPBannerViewSize300x250 origin:CGPointMake(0.0f, 0.0f) appKey:@"62198111" placementId:@"701n2gz11hf5jd8" view:secondBannerParentView rootViewController:self];
     _secondBannerView.adRefreshRate = 60;
     _secondBannerView.delegate = self;
    [_secondBannerView loadRequest];
}

#pragma mark - APSSPBannerViewDelegate
- (void)APSSPBannerViewLoadSuccess:(AdPopcornSSPBannerView *)bannerView
{
    NSLog(@"APSSPBannerViewLoadSuccess : %@", bannerView);
}

- (void)APSSPBannerViewLoadFail:(AdPopcornSSPBannerView *)bannerView error:(AdPopcornSSPError *)error
{
    NSLog(@"APSSPBannerViewLoadFail : %@, error : %@", bannerView, error);
}

- (void)APSSPBannerViewClicked:(AdPopcornSSPBannerView *)bannerView
{
    NSLog(@"APSSPBannerViewClicked : %@", bannerView);
}
@end
