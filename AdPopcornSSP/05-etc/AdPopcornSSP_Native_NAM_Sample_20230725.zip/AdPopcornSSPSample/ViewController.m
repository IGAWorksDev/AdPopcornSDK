//
//  ViewController.m
//  AdPopcornTestApp
//
//  Created by 김민석 on 2016. 12. 5..
//  Copyright © 2016년 igaworks. All rights reserved.
//

#import "ViewController.h"
#import <AdPopcornSSP/AdPopcornSSP.h>

@interface ViewController (){

}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
