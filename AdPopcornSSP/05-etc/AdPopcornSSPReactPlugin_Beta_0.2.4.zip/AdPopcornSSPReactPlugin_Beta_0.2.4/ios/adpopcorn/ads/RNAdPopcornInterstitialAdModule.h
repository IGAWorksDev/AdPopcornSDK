//
//  RNAdPopcornInterstitialAdModule.h
//  AdPopcornSSPReactPlugin
//
//  Created by 김민석 on 2023/05/18.
//
#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>
#import <UIKit/UIKit.h>
#import <AdPopcornSSP/AdPopcornSSPInterstitialAd.h>

@interface RNAdPopcornInterstitialAdModule : RCTEventEmitter<RCTBridgeModule, APSSPInterstitialAdDelegate>
{
  
}

@property (retain, nonatomic) NSMutableDictionary *dictionary;

@end
