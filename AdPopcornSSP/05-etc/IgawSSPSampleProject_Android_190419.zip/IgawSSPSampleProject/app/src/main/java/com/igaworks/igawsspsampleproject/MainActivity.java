package com.igaworks.igawsspsampleproject;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.igaworks.ssp.IgawSSP;
import com.igaworks.ssp.SSPErrorCode;
import com.igaworks.ssp.part.video.IgawRewardVideoAd;
import com.igaworks.ssp.part.video.listener.IRewardVideoAdEventCallbackListener;


public class MainActivity extends Activity {
    private boolean completeloadAndShow = false;
    private IgawRewardVideoAd igawRewardVideoAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 1. IgawSSP SDK 초기화
        IgawSSP.init(MainActivity.this);

        // 2. igaw reward video ad 생성
        igawRewardVideoAd = new IgawRewardVideoAd(this);

        // 3. AP SSP에서 발급 받은 placement id 설정
        igawRewardVideoAd.setPlacementId("wzbu2ob62if5zth");

        // 4. 이벤트 콜백 리스너 설정
        igawRewardVideoAd.setRewardVideoAdEventCallbackListener(iRewardVideoAdEventCallbackListener);

        // 5. 리워드 스케쥴 수동 설정
        // setManualMediationSchedule();

        Button button_reward_video_load = findViewById(R.id.button_reward_video_load_show);
        button_reward_video_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 6. 광고 요청
                completeloadAndShow = false;
                igawRewardVideoAd.loadAd();
            }
        });
    }

    /*private void setManualMediationSchedule(){
        try {
            JSONArray manualMediationScheduelArray = new JSONArray();
            // 하나 멤버스 용 미디에이션 스케쥴은 아래의 순서대로 적용 됨.
            // IGAW -> Admob -> Mintegral -> UnityAds
            // JsonObject를 add 한 순서에 따라 스케쥴이 정해 지므로, 추후 스케쥴 변경을 하고 싶으면 JsonObject
            // Add 순서를 변경하여 사용하시면 됩니다.

            // IGAW
            JSONObject igawJsonSchedule = new JSONObject();
            igawJsonSchedule.put("AdNetworkNo", 0);
            igawJsonSchedule.put("IntegrationKey", "");
            manualMediationScheduelArray.put(igawJsonSchedule);

            // ADMob
            JSONObject admobJsonSchedule = new JSONObject();
            admobJsonSchedule.put("AdNetworkNo", 1);
            JSONObject admobIntegrationKeyJson = new JSONObject();
            admobIntegrationKeyJson.put("adUnitID", "ca-app-pub-1841010496601800/3810514973");
            admobJsonSchedule.put("IntegrationKey", admobIntegrationKeyJson);
            manualMediationScheduelArray.put(admobJsonSchedule);

            // MINTEGRAL
            JSONObject mintegralJsonSchedule = new JSONObject();
            mintegralJsonSchedule.put("AdNetworkNo", 8);

            JSONObject mintegralIntegrationKeyJson = new JSONObject();
            mintegralIntegrationKeyJson.put("MintegralAppId", "108970");
            mintegralIntegrationKeyJson.put("MintegralAppKey", "2f23f5c5f0cc24455e0b5a73067c96ff");
            mintegralIntegrationKeyJson.put("MintegralUnitId", "69378");
            mintegralIntegrationKeyJson.put("MintegralRewardId", "1");
            mintegralJsonSchedule.put("IntegrationKey", mintegralIntegrationKeyJson);

            manualMediationScheduelArray.put(mintegralJsonSchedule);

            // UNITY ADS
            JSONObject unityAdsJsonSchedule = new JSONObject();
            unityAdsJsonSchedule.put("AdNetworkNo", 7);

            JSONObject unityAdsIntegrationKeyJson = new JSONObject();
            unityAdsIntegrationKeyJson.put("UnityPlacementId", "roulettetv_android");
            unityAdsIntegrationKeyJson.put("UnityGameId", "2964975");
            unityAdsJsonSchedule.put("IntegrationKey", unityAdsIntegrationKeyJson);

            manualMediationScheduelArray.put(unityAdsJsonSchedule);

            // igawRewardVideoAd의 경우 코드에서 생성한 리워드 비디오 인스턴스.
            // 매체 측에서 사용하고 있는 리워드 비디오 인스턴스로 대체한 뒤, setManualMediationSchedule API 호출.
            igawRewardVideoAd.setManualMediationSchedule(manualMediationScheduelArray);
        }catch (Exception e){e.printStackTrace();}
    }*/

    IRewardVideoAdEventCallbackListener iRewardVideoAdEventCallbackListener = new IRewardVideoAdEventCallbackListener() {
        @Override
        public void OnRewardVideoAdLoaded() {
            // 광고 로드 성공
            Toast.makeText(MainActivity.this, "OneButton OnRewardVideoAdLoaded", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OneButton OnRewardVideoAdLoaded : " + completeloadAndShow);
            if(igawRewardVideoAd.isReady() && !completeloadAndShow)
                igawRewardVideoAd.showAd();
        }

        @Override
        public void OnRewardVideoAdLoadFailed(SSPErrorCode sspErrorCode) {
            // 광고 로드 실패
            Toast.makeText(MainActivity.this, "OnRewardVideoAdLoadFailed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdLoadFailed");
        }

        @Override
        public void OnRewardVideoAdOpened() {
            Toast.makeText(MainActivity.this, "OnRewardVideoShowSuccess", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoShowSuccess");
            completeloadAndShow = true;
        }

        @Override
        public void OnRewardVideoAdOpenFalied() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed");
            completeloadAndShow = true;
        }

        @Override
        public void OnRewardVideoAdClosed() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed");
            completeloadAndShow = true;
        }

        @Override
        public void OnRewardVideoPlayCompleted(long l, String s) {
            completeloadAndShow = true;
            Toast.makeText(MainActivity.this, "OnAdPopcornSSPVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnAdPopcornSSPVideoCompleted");
            onCompletedRewardVideoAd();
        }

        @Override
        public void OnMintegralVideoCompleted(float v) {
            completeloadAndShow = true;
            Toast.makeText(MainActivity.this, "OnMintegralVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnMintegralVideoCompleted");
            onCompletedRewardVideoAd();
        }

        @Override
        public void OnUnityAdsVideoCompleted() {
            completeloadAndShow = true;
            Toast.makeText(MainActivity.this, "OnUnityAdsVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnUnityAdsVideoCompleted");
            onCompletedRewardVideoAd();
        }

        @Override
        public void OnAdMobVideoCompleted(int i) {
            completeloadAndShow = true;
            Toast.makeText(MainActivity.this, "OnAdMobVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnAdMobVideoCompleted");
            onCompletedRewardVideoAd();
        }
    };

    private void onCompletedRewardVideoAd(){
        // 리워드 비디오가 정상적으로 종료 되었을 때 처리.
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 7. Activity Life cycle에 맞춰 onResume 연동
        if(igawRewardVideoAd != null)
            igawRewardVideoAd.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 8. Activity Life cycle에 맞춰 onResume 연동
        if(igawRewardVideoAd != null)
            igawRewardVideoAd.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 9. 종료.
        igawRewardVideoAd.destroy();
        IgawSSP.destroy();
    }
}


