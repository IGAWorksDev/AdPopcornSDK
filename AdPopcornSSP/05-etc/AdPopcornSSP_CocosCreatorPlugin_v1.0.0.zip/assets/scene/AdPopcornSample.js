const AdPopcornSSP = require('AdPopcornSSPPlugin');

cc.Class({
    extends: cc.Component,

    properties: {
        // 기존 광고 버튼
        btnInterstitial: cc.Button,
        btnInterstitialVideo: cc.Button,
        btnRewardVideo: cc.Button,
        btnVideoMix: cc.Button,
        btnPopContents: cc.Button,

        // ⭐️ 추가: Reward Ad Plus 버튼
        btnRewardAdPlusPage: cc.Button,
        btnRewardAdPlusStatus: cc.Button,
        
        // UI 출력 레이블
        eventLabel: {
            default: null,
            type: cc.Label
        }
    },

    onLoad() {
        const ANDROID_APP_KEY = '663451319'; // ⭐️ 사용자가 채울 Android App Key
        const IOS_APP_KEY = '397261446';     // ⭐️ 사용자가 채울 iOS App Key
        
        const currentAppKey = cc.sys.os === cc.sys.OS_IOS ? IOS_APP_KEY : ANDROID_APP_KEY;

        // OS별 초기화
        if (cc.sys.os === cc.sys.OS_ANDROID || cc.sys.os === cc.sys.OS_IOS) {
            // iOS는 init 시 appKey를 필요로 하므로, init(appKey, callback) 순서로 호출됩니다.
            AdPopcornSSP.init(currentAppKey, (event, params) => this._onAdEvent(event, params));
            AdPopcornSSP.setUserId("test_user_id_123");
            AdPopcornSSP.setLogEnable(true);
            
            // ⭐️ Reward Ad Plus 이벤트 리스너를 미리 설정합니다.
            AdPopcornSSP.setRewardAdPlusEventListener();

            this._updateEventDisplay("SDK 초기화 시도 중...", null);
        } else {
            this._updateEventDisplay("Native 환경이 아닙니다.", null);
        }

        // --- 버튼 클릭 이벤트 연결 ---
        this.btnInterstitial.node.on('click', () => this._showInterstitial());
        this.btnInterstitialVideo.node.on('click', () => this._showInterstitialVideo());
        this.btnRewardVideo.node.on('click', () => this._showRewardVideo());
        this.btnVideoMix.node.on('click', () => this._showVideoMix());
        this.btnPopContents.node.on('click', () => this._openPopContents());
        
        // ⭐️ Reward Ad Plus 버튼 연결
        this.btnRewardAdPlusPage.node.on('click', () => this._openRewardAdPlus());
        this.btnRewardAdPlusStatus.node.on('click', () => this._getRewardAdPlusStatus());
    },

    _loadAds() {
        const ANDROID_APP_KEY = '663451319';
        const IOS_APP_KEY = '397261446';
        
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            AdPopcornSSP.loadInterstitial(ANDROID_APP_KEY, 'INTERSTITIAL');
            AdPopcornSSP.loadInterstitialVideo(ANDROID_APP_KEY, 'VIDEO');
            AdPopcornSSP.loadRewardVideo(ANDROID_APP_KEY, 'REWARD_VIDEO');
            AdPopcornSSP.loadVideoMix(ANDROID_APP_KEY, 'VIDEO_MIX');
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            AdPopcornSSP.loadInterstitial(IOS_APP_KEY, 'iOS_INTERSTITIAL');
            AdPopcornSSP.loadInterstitialVideo(IOS_APP_KEY, 'iOS_VIDEO');
            AdPopcornSSP.loadRewardVideo(IOS_APP_KEY, 'iOS_REWARD_VIDEO');
            AdPopcornSSP.loadVideoMix(IOS_APP_KEY, 'iOS_VIDEO_MIX');
        }
    },

    // 버튼 클릭 시 광고 표시
    _showInterstitial() {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            AdPopcornSSP.showInterstitial('663451319', 'INTERSTITIAL');
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            AdPopcornSSP.showInterstitial('397261446', 'iOS_INTERSTITIAL');
        }
    },

    _showInterstitialVideo() {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            AdPopcornSSP.showInterstitialVideo('663451319', 'VIDEO');
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            AdPopcornSSP.showInterstitialVideo('397261446', 'iOS_VIDEO');
        }
    },

    _showRewardVideo() {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            AdPopcornSSP.showRewardVideo('663451319', 'REWARD_VIDEO');
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            AdPopcornSSP.showRewardVideo('397261446', 'iOS_REWARD_VIDEO');
        }
    },

    _showVideoMix() {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            AdPopcornSSP.showVideoMix('663451319', 'VIDEO_MIX');
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            AdPopcornSSP.showVideoMix('397261446', 'iOS_VIDEO_MIX');
        }
    },

    _openPopContents() {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            AdPopcornSSP.openPopContents('663451319', 'POP_CONTENTS');
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            AdPopcornSSP.openPopContents('397261446', 'iOS_POP_CONTENTS');
        }
    },

    _openRewardAdPlus() {
        const appKey = cc.sys.os === cc.sys.OS_ANDROID ? '663451319' : '397261446';
        
        // ⭐️ RewardAdPlus 페이지 열기 (iOS는 appKey 필수)
        AdPopcornSSP.openRewardAdPlusPage(appKey);
    },
    
    _getRewardAdPlusStatus() {
        const appKey = cc.sys.os === cc.sys.OS_ANDROID ? '663451319' : '397261446';
        const placementId = cc.sys.os === cc.sys.OS_ANDROID ? 'PLUS_PLACEMENT_ID_ANDROID' : 'PLUS_PLACEMENT_ID_IOS';
        
        // ⭐️ 미디어 전체 상태 조회 (iOS는 appKey 필수)
        AdPopcornSSP.getRewardAdPlusUserMediaStatus(appKey);

        // ⭐️ 특정 지면 상태 조회 (iOS는 appKey 필수)
        // AdPopcornSSP.getRewardAdPlusUserPlacementStatus(appKey, placementId);
    },

    _onAdEvent(event, params) {
        if (event === "AdPopcornSSPSDKDidInitialize") {
            this._loadAds();
        }

        this._updateEventDisplay(event, params);
    },

    _updateEventDisplay(event, params) {
        if (!this.eventLabel) {
            console.error("Event Label이 연결되지 않았습니다!");
            return;
        }

        let paramsStr = params ? JSON.stringify(params, null, 2) : "{}";

        // Label에 출력할 메시지 생성
        const message = `[${new Date().toLocaleTimeString()}]\n` +
                        `EVENT: ${event}\n` +
                        `PARAMS: ${paramsStr}`;

        this.eventLabel.string = message;

        // 디버깅을 위해 콘솔에도 출력 유지
        console.log(`[Ad Event Display] ${event}`, params);
    }
});

