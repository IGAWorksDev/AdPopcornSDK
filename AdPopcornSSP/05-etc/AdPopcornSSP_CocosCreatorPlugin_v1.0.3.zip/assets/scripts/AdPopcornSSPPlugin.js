let _callback = null;

const AdPopcornSSPPlugin = {
    init(appKey, callback) {
        _callback = callback || null;

        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "init",
                "()V"
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            // iOS: initSDK:
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "initSDK:",
                appKey
            );
        }
    },

    setUserId(userId) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "setUserId",
                "(Ljava/lang/String;)V",
                userId
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "setUserId:",
                userId
            );
        }
    },

    setLogEnable(enable) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "setLogEnable",
                "(Z)V",
                enable
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "setLogEnable:",
                enable
            );
        }
    },

    // Interstitial
    loadInterstitial(appKey, placementId) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "loadInterstitial",
                "(Ljava/lang/String;Ljava/lang/String;)V",
                appKey,
                placementId
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "loadInterstitial:placementId:",
                appKey,
                placementId
            );
        }
    },

    showInterstitial(appKey, placementId) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "showInterstitial",
                "(Ljava/lang/String;Ljava/lang/String;)V",
                appKey,
                placementId
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "showInterstitial:placementId:",
                appKey,
                placementId
            );
        }
    },

    // Interstitial Video
    loadInterstitialVideo(appKey, placementId) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "loadInterstitialVideo",
                "(Ljava/lang/String;Ljava/lang/String;)V",
                appKey,
                placementId
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "loadInterstitialVideo:placementId:",
                appKey,
                placementId
            );
        }
    },

    showInterstitialVideo(appKey, placementId) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "showInterstitialVideo",
                "(Ljava/lang/String;Ljava/lang/String;)V",
                appKey,
                placementId
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "showInterstitialVideo:placementId:",
                appKey,
                placementId
            );
        }
    },

    // Reward Video
    loadRewardVideo(appKey, placementId) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "loadRewardVideo",
                "(Ljava/lang/String;Ljava/lang/String;)V",
                appKey,
                placementId
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "loadRewardVideo:placementId:",
                appKey,
                placementId
            );
        }
    },

    showRewardVideo(appKey, placementId) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "showRewardVideo",
                "(Ljava/lang/String;Ljava/lang/String;)V",
                appKey,
                placementId
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "showRewardVideo:placementId:",
                appKey,
                placementId
            );
        }
    },

    // Video Mix
    loadVideoMix(appKey, placementId) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "loadVideoMix",
                "(Ljava/lang/String;Ljava/lang/String;)V",
                appKey,
                placementId
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "loadVideoMix:placementId:",
                appKey,
                placementId
            );
        }
    },

    showVideoMix(appKey, placementId) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "showVideoMix",
                "(Ljava/lang/String;Ljava/lang/String;)V",
                appKey,
                placementId
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "showVideoMix:placementId:",
                appKey,
                placementId
            );
        }
    },

    // PopContents
    openPopContents(appKey, placementId) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "openPopContents",
                "(Ljava/lang/String;Ljava/lang/String;)V",
                appKey,
                placementId
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "openPopContents:placementId:",
                appKey,
                placementId
            );
        }
    },

    // RewardAdPlus
    openRewardAdPlusPage(appKey) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "openRewardAdPlusPage",
                "()V"
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            // iOS: openRewardAdPlusPage:
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "openRewardAdPlusPage:",
                appKey
            );
        }
    },

    getRewardAdPlusUserMediaStatus(appKey) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "getRewardAdPlusUserMediaStatus",
                "()V"
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            // iOS: getRewardAdPlusUserMediaStatus:
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "getRewardAdPlusUserMediaStatus:",
                appKey
            );
        }
    },

    getRewardAdPlusUserPlacementStatus(appKey, placementId) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "getRewardAdPlusUserPlacementStatus",
                "(Ljava/lang/String;)V",
                placementId
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            // iOS: getRewardAdPlusUserPlacementStatus:placementId:
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "getRewardAdPlusUserPlacementStatus:placementId:",
                appKey,
                placementId
            );
        }
    },

    setRewardAdPlusEventListener() {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod(
                "com.adpopcorn.sspplugin.AdPopcornSSPPlugin",
                "setRewardAdPlusEventListener",
                "()V"
            );
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(
                "AdPopcornSSPPlugin",
                "setRewardAdPlusEventListener"
            );
        }
    },

    // Native → JS 이벤트 수신
    _onNativeEvent(eventName, params = {}) {
        if (_callback) {
            _callback(eventName, params);
        }
    }
};

module.exports = AdPopcornSSPPlugin;
window.AdPopcornSSPPlugin = AdPopcornSSPPlugin;