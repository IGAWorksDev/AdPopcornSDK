package com.igaworks.adpopcornhybrid;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.igaworks.ssp.AdPopcornSSP;
import com.igaworks.ssp.SSPErrorCode;
import com.igaworks.ssp.part.video.AdPopcornSSPRewardVideoAd;
import com.igaworks.ssp.part.video.listener.IRewardVideoAdEventCallbackListener;

public class AdPopcornJSBridge {
    public final static String INTERFACE_NAME = "adpopcornJSBridge";
    private Context context;
    private WebView webView;
    private Activity mainActivity;
    private AdPopcornSSPRewardVideoAd rewardVideoAd;

    public AdPopcornJSBridge(Context context, Activity mainActivity, WebView webView) {
        this.context = context;
        this.mainActivity = mainActivity;
        this.webView = webView;
    }

    /* 애드팝콘 SSP 리워드 비디오 연동 시, 기본적으로 사용하는 init, destroy, load, show API 이외에 추가로 더 필요한 기능이 있다면
       아래와 동일한 방식으로 JavascriptInterface 추가하여 사용.*/

    // SSP SDK 초기화(앱 시작 시 1번)
    @JavascriptInterface
    public void init() {
        try {
            Log.d("TEST111", "init");
            AdPopcornSSP.init(context);
        }catch(Exception e){}
    }

    // SSP SDK 해제 (앱 종료 시)
    @JavascriptInterface
    public void destroy() {
        try {
            Log.d("TEST111", "destroy");
            AdPopcornSSP.destroy();
        }catch(Exception e){}
    }

    // Reward Video instance 생성
    @JavascriptInterface
    public void createRewardVideoAd(String placementId) {
        try {
            Log.d("TEST111", "createRewardVideoAd");
            if(rewardVideoAd == null){
                rewardVideoAd = new AdPopcornSSPRewardVideoAd(context);
                rewardVideoAd.setPlacementId(placementId);
                rewardVideoAd.setRewardVideoAdEventCallbackListener(rewardVideoAdEventCallbackListener);
            }
        }catch(Exception e){}
    }

    // load Ad
    @JavascriptInterface
    public void loadAd() {
        try {
            Log.d("TEST111", "loadAd");
            if(rewardVideoAd != null)
                rewardVideoAd.loadAd();
        }catch(Exception e){}
    }

    // show Ad
    @JavascriptInterface
    public void showAd() {
        try {
            Log.d("TEST111", "showAd");
            if(rewardVideoAd != null && rewardVideoAd.isReady())
                rewardVideoAd.showAd();
        }catch(Exception e){}
    }

    IRewardVideoAdEventCallbackListener rewardVideoAdEventCallbackListener = new IRewardVideoAdEventCallbackListener() {
        @Override
        public void OnRewardVideoAdLoaded() {
            webView.loadUrl("javascript:loadSuccess()");
        }

        @Override
        public void OnRewardVideoAdLoadFailed(SSPErrorCode sspErrorCode) {
            webView.loadUrl("javascript:loadFailed(" + sspErrorCode.getErrorMessage() + ")");
        }

        @Override
        public void OnRewardVideoAdOpened() {

        }

        @Override
        public void OnRewardVideoAdOpenFalied() {

        }

        @Override
        public void OnRewardVideoAdClosed() {

        }

        @Override
        public void OnRewardVideoPlayCompleted(int networkNo, boolean complete) {

        }

        @Override
        public void OnRewardVideoAdClicked() {

        }
    };
}
