package com.igaworks.igawsspsampleproject;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.igaworks.ssp.IgawSSP;
import com.igaworks.ssp.SSPErrorCode;
import com.igaworks.ssp.part.IMediationLogListener;
import com.igaworks.ssp.part.interstitial.InterstitialAd;
import com.igaworks.ssp.part.interstitial.listener.IInterstitialEventCallbackListener;
import com.igaworks.ssp.part.video.IgawRewardVideoAd;
import com.igaworks.ssp.part.video.listener.IRewardVideoAdEventCallbackListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;


public class MainActivity extends Activity {
    private final String REWARD_VIDEO_PLACEMENT_ID = "vjb8xcc5vgzdvba";
    private IgawRewardVideoAd igawRewardVideoAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. IgawSSP SDK 초기화
        IgawSSP.init(MainActivity.this);

        // 2. CS 처리를 위한 usn 세팅 추가.
        IgawSSP.setUserId(this, "TEST_USN");

        // 3. igaw reward video ad 생성
        igawRewardVideoAd = new IgawRewardVideoAd(this);

        // 4. AP SSP에서 발급 받은 placement id 설정
        igawRewardVideoAd.setPlacementId(REWARD_VIDEO_PLACEMENT_ID);

        // 5. 이벤트 콜백 리스너 설정
        igawRewardVideoAd.setRewardVideoAdEventCallbackListener(iRewardVideoAdEventCallbackListener);

        Button button_reward_video_load = findViewById(R.id.button_reward_video_load_show);
        button_reward_video_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 6. 광고 요청
                igawRewardVideoAd.loadAd();
            }
        });

        Button button_open_cs_page = findViewById(R.id.button_open_cs_page);
        button_open_cs_page.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 10. 리워드 비디오 CS 페이지 열기
                IgawSSP.openRewardVideoCSPage(MainActivity.this, "TEST_USN");
            }
        });
    }

    IRewardVideoAdEventCallbackListener iRewardVideoAdEventCallbackListener = new IRewardVideoAdEventCallbackListener() {
        @Override
        public void OnRewardVideoAdLoaded() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdLoaded", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdLoaded");
            if(igawRewardVideoAd.isReady())
                igawRewardVideoAd.showAd();
        }

        @Override
        public void OnRewardVideoAdLoadFailed(SSPErrorCode sspErrorCode) {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdLoadFailed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdLoadFailed");
        }

        @Override
        public void OnRewardVideoAdOpened() {
            Toast.makeText(MainActivity.this, "OnRewardVideoShowSuccess", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoShowSuccess");
        }

        @Override
        public void OnRewardVideoAdOpenFalied() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed");
        }

        @Override
        public void OnRewardVideoAdClosed() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed");
        }

        @Override
        public void OnRewardVideoPlayCompleted(int networkId, boolean completed) {
            Toast.makeText(MainActivity.this, "OnAdPopcornSSPVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnAdPopcornSSPVideoCompleted");
            if(completed)
                onCompletedRewardVideoAd();
        }
    };

    private void onCompletedRewardVideoAd(){
        // 리워드 비디오가 정상적으로 종료 되었을 때 처리
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 7. Activity Life cycle에 맞춰 onResume 연동
        if(igawRewardVideoAd != null)
            igawRewardVideoAd.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 8. Activity Life cycle에 맞춰 onResume 연동
        if(igawRewardVideoAd != null)
            igawRewardVideoAd.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 9. 종료.
        if(igawRewardVideoAd != null)
            igawRewardVideoAd.destroy();
        IgawSSP.destroy();
    }
}


