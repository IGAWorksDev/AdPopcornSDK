package com.igaworks.igawsspsampleproject;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.igaworks.ssp.IgawSSP;
import com.igaworks.ssp.SSPErrorCode;
import com.igaworks.ssp.part.video.IgawRewardVideoAd;
import com.igaworks.ssp.part.video.listener.IRewardVideoAdEventCallbackListener;


public class MainActivity extends Activity {
    private boolean completeloadAndShow = false;
    private IgawRewardVideoAd igawRewardVideoAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 1. IgawSSP SDK 초기화
        IgawSSP.init(MainActivity.this);

        // 2. igaw reward video ad 생성
        igawRewardVideoAd = new IgawRewardVideoAd(this);

        // 3. AP SSP에서 발급 받은 placement id 설정
        igawRewardVideoAd.setPlacementId("wzbu2ob62if5zth");

        // 4. 이벤트 콜백 리스너 설정
        igawRewardVideoAd.setRewardVideoAdEventCallbackListener(iRewardVideoAdEventCallbackListener);

        Button button_reward_video_load = findViewById(R.id.button_reward_video_load_show);
        button_reward_video_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 6. 광고 요청
                completeloadAndShow = false;
                igawRewardVideoAd.loadAd();
            }
        });
    }

    IRewardVideoAdEventCallbackListener iRewardVideoAdEventCallbackListener = new IRewardVideoAdEventCallbackListener() {
        @Override
        public void OnRewardVideoAdLoaded() {
            // 광고 로드 성공
            Toast.makeText(MainActivity.this, "OnRewardVideoAdLoaded", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdLoaded : " + completeloadAndShow);
            if(igawRewardVideoAd.isReady() && !completeloadAndShow)
                igawRewardVideoAd.showAd();

            // 현재 동작 중인 네트워크 이름 체크 API
            // 0: IGAW
            // 1: AdMob
            // 7: UnityAds
            // 8: Mintegral
            // 11: AppNext
            int networkNum = -1;
            if(igawRewardVideoAd != null)
                networkNum = igawRewardVideoAd.getCurrentNetwork();
            Log.i("IgawSSPSample", "OnRewardVideoAdLoaded networkNum : " + networkNum);
        }

        @Override
        public void OnRewardVideoAdLoadFailed(SSPErrorCode sspErrorCode) {
            // 광고 로드 실패
            Toast.makeText(MainActivity.this, "OnRewardVideoAdLoadFailed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdLoadFailed");
        }

        @Override
        public void OnRewardVideoAdOpened() {
            Toast.makeText(MainActivity.this, "OnRewardVideoShowSuccess", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoShowSuccess");
            completeloadAndShow = true;
        }

        @Override
        public void OnRewardVideoAdOpenFalied() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed");
            completeloadAndShow = true;
        }

        @Override
        public void OnRewardVideoAdClosed() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed");
            completeloadAndShow = true;
        }

        @Override
        public void OnRewardVideoPlayCompleted(long l, String s) {
            completeloadAndShow = true;
            Toast.makeText(MainActivity.this, "OnAdPopcornSSPVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnAdPopcornSSPVideoCompleted");
            onCompletedRewardVideoAd();
        }

        @Override
        public void OnMintegralVideoCompleted(float v) {
            completeloadAndShow = true;
            Toast.makeText(MainActivity.this, "OnMintegralVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnMintegralVideoCompleted");
            onCompletedRewardVideoAd();
        }

        @Override
        public void OnUnityAdsVideoCompleted() {
            completeloadAndShow = true;
            Toast.makeText(MainActivity.this, "OnUnityAdsVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnUnityAdsVideoCompleted");
            onCompletedRewardVideoAd();
        }

        @Override
        public void OnAdMobVideoCompleted(int i) {
            completeloadAndShow = true;
            Toast.makeText(MainActivity.this, "OnAdMobVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnAdMobVideoCompleted");
            onCompletedRewardVideoAd();
        }

        @Override
        public void OnAppNextVideoCompleted() {
            completeloadAndShow = true;
            Toast.makeText(MainActivity.this, "OnAppNextVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnAppNextVideoCompleted");
            onCompletedRewardVideoAd();
        }
    };

    private void onCompletedRewardVideoAd(){
        // 리워드 비디오가 정상적으로 종료 되었을 때 처리.
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 7. Activity Life cycle에 맞춰 onResume 연동
        if(igawRewardVideoAd != null)
            igawRewardVideoAd.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 8. Activity Life cycle에 맞춰 onResume 연동
        if(igawRewardVideoAd != null)
            igawRewardVideoAd.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 9. 종료.
        igawRewardVideoAd.destroy();
        IgawSSP.destroy();
    }
}


