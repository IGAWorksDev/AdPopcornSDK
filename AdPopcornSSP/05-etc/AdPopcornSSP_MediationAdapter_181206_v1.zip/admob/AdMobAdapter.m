//
//  AdMobAdapter.m
//  AdPopcornSSP
//
//  Created by mick on 2017. 8. 2..
//  Copyright (c) 2017년 igaworks All rights reserved.
//

#import "AdMobAdapter.h"

static inline NSString *SSPErrorString(SSPErrorCode code)
{
    switch (code)
    {
        case AdPopcornSSPException:
            return @"Exception";
        case AdPopcornSSPInvalidParameter:
            return @"Invalid Parameter";
        case AdPopcornSSPUnknownServerError:
            return @"Unknown Server Error";
        case AdPopcornSSPInvalidMediaKey:
            return @"Invalid Media key";
        case AdPopcornSSPInvalidPlacementId:
            return @"Invalid Placement Id";
        case AdPopcornSSPInvalidNativeAssetsConfig:
            return @"Invalid native assets config";
        case AdPopcornSSPNativePlacementDoesNotInitialized:
            return @"Native Placement Does Not Initialized";
        case AdPopcornSSPServerTimeout:
            return @"Server Timeout";
        case AdPopcornSSPLoadAdFailed:
            return @"Load Ad Failed";
        case AdPopcornSSPNoAd:
            return @"No Ad";
        case AdPopcornSSPNoInterstitialLoaded:
            return @"No Interstitial Loaded";
        case AdPopcornSSPNoRewardVideoAdLoaded:
            return @"No Reward video ad Loaded";
        case AdPopcornSSPMediationAdapterNotInitialized:
            return @"Mediation Adapter Not Initialized";
        default: {
            return @"Success";
        }
    }
}

@interface AdMobAdapter () <GADBannerViewDelegate, GADInterstitialDelegate>
{
    
}

@property (NS_NONATOMIC_IOSONLY, readonly, copy) GADRequest *request;
- (void)addAlignCenterConstraint;
@end

@implementation AdMobAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;
@synthesize viewController = _viewController;
@synthesize bannerView = _bannerView;

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}


- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(AdPopcornSSPBannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = SSPAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPAdInterstitialType;
}

- (BOOL)isSupportInterstitialAd
{
    return YES;
}

- (void)loadAd
{
    if (_adType == SSPAdBannerType)
    {
        if (_integrationKey != nil)
        {
            NSString *adUnitID = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
            NSLog(@"AdMobAdapter SSPAdBannerType adUnitID : %@", adUnitID);
          
            if(_size.width == 320.0f && _size.height == 100.0f)
            {
                _adBannerView = [[GADBannerView alloc] initWithAdSize:kGADAdSizeLargeBanner origin:CGPointMake(0.0f, 0.0f)];
            }
            else if(_size.width == 300.0f && _size.height == 250.0f)
            {
                _adBannerView = [[GADBannerView alloc] initWithAdSize:kGADAdSizeMediumRectangle origin:CGPointMake(0.0f, 0.0f)];
            }
            else
            {
                _adBannerView = [[GADBannerView alloc] initWithAdSize:kGADAdSizeBanner origin:CGPointMake(0.0f, 0.0f)];
            }
            _adBannerView.adUnitID = adUnitID;
            _adBannerView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
            
            // add banner view
            [_bannerView addSubview:_adBannerView];
            
            [self addAlignCenterConstraint];
            
            _adBannerView.delegate = self;
            _adBannerView.rootViewController = _viewController;
           
            // load request
            [_adBannerView loadRequest:[self request]];
        }
        else
        {
          if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
          {
            [_delegate AdPopcornSSPAdapterBannerView:_adBannerView didFailToReceiveAdWithError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
          }
          
          [self closeAd];
        }
    }
    else if (_adType == SSPAdInterstitialType)
    {
        if (_integrationKey != nil)
        {
            NSString *adUnitID = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
            NSLog(@"AdMobAdapter SSPAdInterstitialType adUnitID : %@", adUnitID);
            
            _interstitial = [[GADInterstitial alloc] initWithAdUnitID:adUnitID];
            _interstitial.delegate = self;
            [_interstitial loadRequest:[self request]];
        }
        else
        {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
            {
              [_delegate AdPopcornSSPAdapterInterstitial:_interstitial didFailToReceiveAdWithError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
          
            [self closeAd];
        }
    }
}

- (void)showAd
{
    NSLog(@"AdMobAdapter %@ : showAd", self);
    
    if (_adType == SSPAdInterstitialType)
    {
        if(_interstitial.isReady)
            [_interstitial presentFromRootViewController:_viewController];
    }
}

- (void)closeAd
{
    NSLog(@"AdMobAdapter %@ : closeAd", self);
    
    if (_adType == SSPAdBannerType)
    {
        [_adBannerView removeFromSuperview];
        _adBannerView.delegate = nil;
        _adBannerView = nil;
    }
    else if (_adType == SSPAdInterstitialType)
    {
        _interstitial.delegate = nil;
        _interstitial = nil;
    }
}

- (void)loadRequest
{
    if (_adType == SSPAdBannerType)
    {
        [_adBannerView loadRequest:[self request]];
    }
    else if (_adType == SSPAdInterstitialType)
    {
        [_interstitial loadRequest:[self request]];
    }
}

- (void)addAlignCenterConstraint
{
    // add constraints
    [_adBannerView setTranslatesAutoresizingMaskIntoConstraints:NO];
    UIView *superview = _bannerView;
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_adBannerView
                                  attribute:NSLayoutAttributeCenterX
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterX
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_adBannerView
                                  attribute:NSLayoutAttributeCenterY
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterY
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adBannerView
                                                          attribute:NSLayoutAttributeHeight
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeHeight
                                                         multiplier:0.0
                                                           constant:_size.height]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adBannerView
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeWidth
                                                         multiplier:0.0
                                                           constant:_size.width]];
}

#pragma mark GADRequest generation
- (GADRequest *)request
{
    GADRequest *request = [GADRequest request];
    
    // Make the request for a test ad. Put in an identifier for the simulator as well as any devices
    // you want to receive test ads.
    //    request.testDevices = @[
    // TODO: Add your device/simulator test identifiers here. Your device identifier is printed to
    // the console when the app is launched.
    //                            GAD_SIMULATOR_ID, @"2c127c4d3ac4eaaf79c48dc9e700e905"
    //                            ];
    
    return request;
}

#pragma mark - GADBannerViewDelegate
- (void)adViewDidReceiveAd:(GADBannerView *)view
{
    NSLog(@"AdMobAdapter GADBannerView : %@", view);
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewDidLoadAd:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterBannerViewDidLoadAd:view adapter:self];
    }
}

- (void)adView:(GADBannerView *)view didFailToReceiveAdWithError:(GADRequestError *)error
{
    NSLog(@"AdMobAdapter view : %@, error : %@", view, error);
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterBannerView:view didFailToReceiveAdWithError:error adapter:self];
    }
    
    [self closeAd];
}

- (void)adViewWillPresentScreen:(GADBannerView *)adView
{
    
}


- (void)adViewWillDismissScreen:(GADBannerView *)adView
{
    
}


- (void)adViewDidDismissScreen:(GADBannerView *)adView
{
    
}

- (void)adViewWillLeaveApplication:(GADBannerView *)adView
{
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewWillLeaveApplication:)])
    {
        [_delegate AdPopcornSSPAdapterBannerViewWillLeaveApplication:adView];
    }
}

#pragma mark - GADInterstitialDelegate
#pragma mark Ad Request Lifecycle Notifications

// Sent when an interstitial ad request succeeded.  Show it at the next
// transition point in your application such as when transitioning between view
// controllers.
- (void)interstitialDidReceiveAd:(GADInterstitial *)ad
{
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdDidLoadAd:)])
    {
        [_delegate AdPopcornSSPAdapterInterstitialAdDidLoadAd:ad];
    }
}

// Sent when an interstitial ad request completed without an interstitial to
// show.  This is common since interstitials are shown sparingly to users.
- (void)interstitial:(GADInterstitial *)ad didFailToReceiveAdWithError:(GADRequestError *)error
{
    [self closeAd];
    
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterInterstitial:ad didFailToReceiveAdWithError:error adapter:self];
    }
}

#pragma mark Display-Time Lifecycle Notifications

// Sent just before presenting an interstitial.  After this method finishes the
// interstitial will animate onto the screen.  Use this opportunity to stop
// animations and save the state of your application in case the user leaves
// while the interstitial is on screen (e.g. to visit the App Store from a link
// on the interstitial).
- (void)interstitialWillPresentScreen:(GADInterstitial *)ad
{
    
}

// Sent before the interstitial is to be animated off the screen.
- (void)interstitialWillDismissScreen:(GADInterstitial *)ad
{
    
}

// Sent just after dismissing an interstitial and it has animated off the
// screen.
- (void)interstitialDidDismissScreen:(GADInterstitial *)ad
{
    
}

// Sent just before the application will background or terminate because the
// user clicked on an ad that will launch another application (such as the App
// Store).  The normal UIApplicationDelegate methods, like
// applicationDidEnterBackground:, will be called immediately before this.
- (void)interstitialWillLeaveApplication:(GADInterstitial *)ad
{
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialWillLeaveApplication:)])
    {
        [_delegate AdPopcornSSPAdapterInterstitialWillLeaveApplication:ad];
    }
}
@end
