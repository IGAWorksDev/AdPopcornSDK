//
//  FANAdapter.m
//  AdPopcornSSP
//
//  Created by mick on 2017. 8. 2..
//  Copyright (c) 2017년 igaworks All rights reserved.
//

#import "FANAdapter.h"

static inline NSString *SSPErrorString(SSPErrorCode code)
{
    switch (code)
    {
        case AdPopcornSSPException:
            return @"Exception";
        case AdPopcornSSPInvalidParameter:
            return @"Invalid Parameter";
        case AdPopcornSSPUnknownServerError:
            return @"Unknown Server Error";
        case AdPopcornSSPInvalidMediaKey:
            return @"Invalid Media key";
        case AdPopcornSSPInvalidPlacementId:
            return @"Invalid Placement Id";
        case AdPopcornSSPInvalidNativeAssetsConfig:
            return @"Invalid native assets config";
        case AdPopcornSSPNativePlacementDoesNotInitialized:
            return @"Native Placement Does Not Initialized";
        case AdPopcornSSPServerTimeout:
            return @"Server Timeout";
        case AdPopcornSSPLoadAdFailed:
            return @"Load Ad Failed";
        case AdPopcornSSPNoAd:
            return @"No Ad";
        case AdPopcornSSPNoInterstitialLoaded:
            return @"No Interstitial Loaded";
        case AdPopcornSSPNoRewardVideoAdLoaded:
            return @"No Reward video ad Loaded";
        case AdPopcornSSPMediationAdapterNotInitialized:
            return @"Mediation Adapter Not Initialized";
        default: {
            return @"Success";
        }
    }
}

@interface FANAdapter () <FBAdViewDelegate, FBInterstitialAdDelegate, FBNativeAdDelegate>
{
    
}

- (void)addAlignCenterConstraint;

@end

@implementation FANAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;
@synthesize viewController = _viewController;
@synthesize bannerView = _bannerView;

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}


- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(AdPopcornSSPBannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = SSPAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPAdInterstitialType;
}

- (void)setNativeAdType
{
    _adType = SSPNativeAdType;
}

- (BOOL)isSupportInterstitialAd
{
    return YES;
}

- (void)loadAd
{
    /* For Test
    [FBAdSettings setLogLevel:FBAdLogLevelLog];
    [FBAdSettings addTestDevice:[FBAdSettings testDeviceHash]];
    FBAdSettings.testAdType = FBAdTestAdType_Default;
    */
    
    if (_adType == SSPAdBannerType)
    {
        if (_adView.superview == nil)
        {
            if (_integrationKey != nil)
            {
                NSString *placementID = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
                
                if(_size.width == 320.0f && _size.height == 100.0f)
                {
                    NSLog(@"%@ : FAN can not load 320x100", self);
                    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
                    {
                        [_delegate AdPopcornSSPAdapterBannerView:nil didFailToReceiveAdWithError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
                    }
                    
                    [self closeAd];
                    return;
                }
                else if(_size.width == 300.0f && _size.height == 250.0f)
                {
                    _adView = [[FBAdView alloc] initWithPlacementID:placementID
                                                             adSize:kFBAdSizeHeight250Rectangle
                                                 rootViewController:_viewController];
                }
                else
                {
                    _adView = [[FBAdView alloc] initWithPlacementID:placementID
                                                             adSize:kFBAdSizeHeight50Banner
                                                 rootViewController:_viewController];
                }
                
                _adView.frame = CGRectMake(0.0f, 0.0f, _size.width, _size.height);
                _adView.delegate = self;
                _adView.autoresizingMask = UIViewAutoresizingFlexibleWidth;

                NSLog(@"FB Banner placementID : %@", placementID);
                // add banner view
                [_bannerView addSubview:_adView];
                
                [self addAlignCenterConstraint];
                
                [_adView loadAd];
            }
            else
            {
                if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
                {
                    
                    [_delegate AdPopcornSSPAdapterBannerView:_adView didFailToReceiveAdWithError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
                }
                
                [self closeAd];
            }
        }
    }
    else if (_adType == SSPAdInterstitialType)
    {
        if (_integrationKey != nil)
        {
            NSString *placementID = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
            _interstitialAd = [[FBInterstitialAd alloc] initWithPlacementID:placementID];
            _interstitialAd.delegate = self;
            
            NSLog(@"FB Interstitial placementID : %@", placementID);
            [_interstitialAd loadAd];
        }
        else
        {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitial:_interstitialAd didFailToReceiveAdWithError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
            
            [self closeAd];
        }
    }
    else if (_adType == SSPNativeAdType)
    {
        NSString *placementID = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
        if(placementID != nil)
        {
            _nativeAd = [[FBNativeAd alloc] initWithPlacementID:placementID];
            _nativeAd.delegate = self;
            [_nativeAd loadAd];
        }
    }
}

- (void)showAd
{
    NSLog(@"FANAdapter  %@ : showAd", self);
    if (_adType == SSPAdInterstitialType)
    {
        [_interstitialAd showAdFromRootViewController:_viewController];
    }
}

- (void)closeAd
{
    if (_adType == SSPAdBannerType)
    {
        [_adView removeFromSuperview];
        _adView.delegate = nil;
        _adView = nil;
    }
    else if (_adType == SSPAdInterstitialType)
    {
        _interstitialAd.delegate = nil;
        _interstitialAd = nil;
    }
}


- (void)setAge:(NSInteger)age
{
}

- (void)setGender:(SSPGender)gender
{
}


- (void)addAlignCenterConstraint
{
    // add constraints
    if(_adView != nil)
    {
            [_adView setTranslatesAutoresizingMaskIntoConstraints:NO];
        UIView *superview = _bannerView;
        [superview addConstraint:
         [NSLayoutConstraint constraintWithItem:_adView
                                  attribute:NSLayoutAttributeCenterX
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterX
                                 multiplier:1
                                   constant:0]];
    
        [superview addConstraint:
         [NSLayoutConstraint constraintWithItem:_adView
                                  attribute:NSLayoutAttributeCenterY
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterY
                                 multiplier:1
                                   constant:0]];
    
        [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView
                                                          attribute:NSLayoutAttributeHeight
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeHeight
                                                         multiplier:0.0
                                                           constant:_size.height]];
    
        [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeWidth
                                                         multiplier:0.0
                                                           constant:_size.width]];
    }
}

#pragma mark - FBAdViewDelegate
- (void)adView:(FBAdView *)adView didFailWithError:(NSError *)error;
{
    NSLog(@"Banner Ad failed to load");
    // Add code to hide the ad unit...
    adView.hidden = YES;
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterBannerView:adView didFailToReceiveAdWithError:error adapter:self];
    }
}

- (void)adViewDidLoad:(FBAdView *)adView;
{
    NSLog(@"Banner Ad was loaded and ready to be displayed");
    // Add code to show the ad unit...
    adView.hidden = NO;
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewDidLoadAd:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterBannerViewDidLoadAd:adView adapter:self];
    }
}

#pragma mark - FBInterstitialAdDelegate
- (void)interstitialAdDidLoad:(FBInterstitialAd *)interstitialAd
{
    NSLog(@"FANAdapter Interstitial Ad is loaded and ready to be displayed");
    
    // You can now display the full screen ad using this code:
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdDidLoadAd:)])
    {
        [_delegate AdPopcornSSPAdapterInterstitialAdDidLoadAd:interstitialAd];
    }
}

- (void)interstitialAd:(FBInterstitialAd *)interstitialAd didFailWithError:(NSError *)error
{
    NSLog(@"FANAdapter Interstitial Ad failed to load");
    [self closeAd];
    
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterInterstitial:interstitialAd didFailToReceiveAdWithError:error adapter:self];
    }
}

#pragma mark - FBNativeAdDelegate
- (void)nativeAdDidLoad:(FBNativeAd *)nativeAd
{
    NSLog(@"FANAdapter nativeAdDidLoad...%@", nativeAd);
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdDidLoadAd:networkName:)])
    {
        [_delegate AdPopcornSSPAdapterNativeAdDidLoadAd:nativeAd networkName:@"FAN"];
    }
}

- (void)nativeAd:(FBNativeAd *)nativeAd didFailWithError:(NSError *)error
{
    NSLog(@"FANAdapter Native ad failed to load with error: %@", error);
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAd:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterNativeAd:nativeAd didFailToReceiveAdWithError:error adapter:self];
    }
}

- (void)nativeAdDidClick:(FBNativeAd *)nativeAd
{
    NSLog(@"FANAdapter Native ad was clicked.");
}

- (void)nativeAdDidFinishHandlingClick:(FBNativeAd *)nativeAd
{
    NSLog(@"FANAdapter Native ad did finish click handling.");
}

- (void)nativeAdWillLogImpression:(FBNativeAd *)nativeAd
{
    NSLog(@"FANAdapter Native ad impression is being captured.");
}

@end
