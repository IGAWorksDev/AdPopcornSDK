//
//  MopubAdapter.h
//  AdPopcornSSP
//
//  Created by mick on 2017. 8. 2..
//  Copyright (c) 2017년 igaworks All rights reserved.
//

#import "MPAdView.h"
#import "MPInterstitialAdController.h"

// Using pod install / unity
//#import <AdPopcornSSP/AdPopcornSSPAdapter.h>
// else
#import "AdPopcornSSPAdapter.h"

@interface MopubAdapter : AdPopcornSSPAdapter
{
    MPAdView *_adBannerView;
    MPInterstitialAdController *_interstitial;
}
@end
