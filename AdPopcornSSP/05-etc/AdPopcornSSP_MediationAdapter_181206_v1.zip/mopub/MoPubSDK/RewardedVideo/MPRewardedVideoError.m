//
//  MPRewardedVideoError.m
//  MoPubSDK
//
//  Copyright (c) 2015 MoPub. All rights reserved.
//

#import "MPRewardedVideoError.h"

NSString * const MoPubRewardedVideoAdsSDKDomain = @"MoPubRewardedVideoAdsSDKDomain";