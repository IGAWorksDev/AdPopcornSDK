//
//  MPNativeAdRendererConfiguration.m
//  MoPubSDK
//
//  Copyright (c) 2015 MoPub. All rights reserved.
//

#import "MPNativeAdRendererConfiguration.h"

@implementation MPNativeAdRendererConfiguration

@end
