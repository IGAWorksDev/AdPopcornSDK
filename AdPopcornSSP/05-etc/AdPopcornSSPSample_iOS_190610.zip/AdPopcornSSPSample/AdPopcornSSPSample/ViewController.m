//
//  ViewController.m
//  AdPopcornTestApp
//
//  Created by 김민석 on 2016. 12. 5..
//  Copyright © 2016년 igaworks. All rights reserved.
//

#import "ViewController.h"
#import "AdPopcornSSP/AdPopcornSSPRewardVideoAd.h"

@interface ViewController () <AdPopcornSSPRewardVideoAdDelegate>{
    AdPopcornSSPRewardVideoAd *_sspRewardVideoAd;
    BOOL _completeLoadAndShow; // 한 번의 load 당 한 번의 show만 동작 하도록 하는 flag
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _sspRewardVideoAd = [[AdPopcornSSPRewardVideoAd alloc] initWithKey:@"114554353" placementId:@"oel985g2ypygjff" viewController:self];
    _sspRewardVideoAd.delegate = self;
    _completeLoadAndShow = NO;
}

- (IBAction)LoadMediationVideo:(id)sender {
    if(![_sspRewardVideoAd isReady])
    {
        _completeLoadAndShow = NO;
        [_sspRewardVideoAd loadRequest];
    }
}

- (IBAction)ShowMediationVideo:(id)sender {
    if([_sspRewardVideoAd isReady] && !_completeLoadAndShow)
        [_sspRewardVideoAd presentFromViewController:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark AdPopcornSSPRewardVideoAdDelegate
- (void)AdPopcornSSPLoadRewardVideoAdSuccess
{
    int networkNum = -1;
    if(_sspRewardVideoAd != nil)
    {
        networkNum = [_sspRewardVideoAd getCurrentNetwork];
    }
    NSLog(@"AdPopcornSSPLoadRewardVideoAdSuccess : %ld", (long)networkNum);
}

- (void)AdPopcornSSPLoadRewardVideoAdFailedWithError:(AdPopcornSSPError *)error
{
    NSLog(@"AdPopcornSSPLoadRewardVideoAdFailedWithError : %@", error);
}
- (void)AdPopcornSSPShowRewardVideoAdSuccess
{
    NSLog(@"AdPopcornSSPShowRewardVideoAdSuccess");
    _completeLoadAndShow = YES;
}
- (void)AdPopcornSSPShowRewardVideoAdFailed
{
    NSLog(@"AdPopcornSSPShowRewardVideoAdFailed");
    _completeLoadAndShow = YES;
}
- (void)AdPopcornSSPRewardVideoAdClosed
{
    NSLog(@"AdPopcornSSPRewardVideoAdClosed");
    _completeLoadAndShow = YES;
}

- (void)AdPopcornSSPRewardVideoAdPlayCompletedWithQuantity:(long) quantity Currency:(NSString *)currency
{
    NSLog(@"AdPopcornSSPRewardVideoAdPlayCompletedWithQuantity %ld, %@", quantity, currency);
    _completeLoadAndShow = YES;
}

- (void)AdPopcornSSPRewardVideoAdMintegralVideoCompleted:(NSInteger)RewardAmount
{
    NSLog(@"AdPopcornSSPRewardVideoAdMintegralVideoCompleted %ld", RewardAmount);
    _completeLoadAndShow = YES;
}

- (void)AdPopcornSSPRewardVideoAdUnityAdsVideoCompleted
{
    NSLog(@"AdPopcornSSPRewardVideoAdUnityAdsVideoCompleted");
    _completeLoadAndShow = YES;
}

- (void)AdPopcornSSPRewardVideoAdAdMobVideoCompleted:(double)RewardAmount
{
    NSLog(@"AdPopcornSSPRewardVideoAdAdMobVideoCompleted %f", RewardAmount);
    _completeLoadAndShow = YES;
}

- (void)AdPopcornSSPRewardVideoAdAppNextAdsVideoCompleted
{
    NSLog(@"AdPopcornSSPRewardVideoAdAppNextAdsVideoCompleted");
    _completeLoadAndShow = YES;
}
@end
