//
//  AppnextRewardedVideoAdConfiguration.h
//  AppnextLib
//
//  Created by Eran Mausner on 11/01/2016.
//  Copyright © 2016 Appnext. All rights reserved.
//

#import <AppnextLib/AppnextVideoAdConfiguration.h>

@interface AppnextRewardedVideoAdConfiguration : AppnextVideoAdConfiguration

@end
