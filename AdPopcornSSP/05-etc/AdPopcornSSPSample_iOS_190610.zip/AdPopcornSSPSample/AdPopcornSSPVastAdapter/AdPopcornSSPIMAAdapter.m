//
//  AdPopcornSSPIMAAdapter.m
//  IgaworksDevApp
//
//  Created by 김민석 on 2018. 7. 3..
//  Copyright © 2018년 mick. All rights reserved.
//

#import "AdPopcornSSPIMAAdapter.h"
#import "AdPopcornSSPVastPlayer.h"

@interface AdPopcornSSPIMAAdapter()
{
    UIViewController *_viewController;
}

@end

@implementation AdPopcornSSPIMAAdapter

@synthesize delegate = _delegate;
@synthesize campaignWebData = _campaignWebData;

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}

- (void)showVastAdWithViewController:(UIViewController *)viewController
{
    AdPopcornSSPVastPlayer *vastPlayerController = [[AdPopcornSSPVastPlayer alloc] init];
    vastPlayerController.delegate = _delegate;
    vastPlayerController.vastAdData = _campaignWebData;
    
    [viewController presentViewController:vastPlayerController animated:YES completion:^(void){}];
}

@end
