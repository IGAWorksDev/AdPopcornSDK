//
//  AdPopcornSSPVastPlayer.m
//  AdPopcornSSP
//
//  Created by 김민석 on 2018. 6. 28..
//  Copyright © 2018년 mick. All rights reserved.
//

#import "AdPopcornSSPVastPlayer.h"

@interface AdPopcornSSPVastPlayer()<IMAAdsLoaderDelegate, IMAAdsManagerDelegate>
{
    /// Content video player.
    AVPlayer *contentPlayer;
    /// UIView in which we will render our AVPlayer for content.
    UIView *videoView;
    BOOL isVideoAdPlaying;
}


/// Entry point for the SDK. Used to make ad requests.
@property(nonatomic, strong) IMAAdsLoader *adsLoader;

/// Main point of interaction with the SDK. Created by the SDK as the result of an ad request.
@property(nonatomic, strong) IMAAdsManager *adsManager;

/// Playhead used by the SDK to track content video progress and insert mid-rolls.
@property(nonatomic, strong) IMAAVPlayerContentPlayhead *contentPlayhead;

@end

@implementation AdPopcornSSPVastPlayer

@synthesize delegate = _delegate;
@synthesize vastAdData = _vastAdData;

- (void)dealloc
{
    _delegate = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didBecomeActive) name:UIApplicationDidBecomeActiveNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didEnterBackground) name:UIApplicationDidEnterBackgroundNotification object:nil];
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    isVideoAdPlaying = NO;
    
    [self setupAdsLoader];
    [self setUpContentPlayer];
    [self requestAds];
}

- (void)didEnterBackground
{
    if(self.adsManager != nil && isVideoAdPlaying)
        [self.adsManager pause];
}

- (void)didBecomeActive
{
    if(self.adsManager != nil && isVideoAdPlaying)
        [self.adsManager resume];
}

#pragma mark Content Player Setup
- (void)setUpContentPlayer {
    videoView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    [self.view addSubview:videoView];
    
    // Load AVPlayer with path to our content.
    NSURL *contentURL = [NSURL URLWithString:@""];
    contentPlayer = [AVPlayer playerWithURL:contentURL];
    
    // Create a player layer for the player.
    AVPlayerLayer *playerLayer = [AVPlayerLayer playerLayerWithPlayer:contentPlayer];
    
    // Size, position, and display the AVPlayer.
    playerLayer.frame = videoView.layer.bounds;
    [videoView.layer addSublayer:playerLayer];
    
    // Set up our content playhead and contentComplete callback.
    self.contentPlayhead = [[IMAAVPlayerContentPlayhead alloc] initWithAVPlayer:contentPlayer];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(contentDidFinishPlaying:) name:AVPlayerItemDidPlayToEndTimeNotification object:contentPlayer.currentItem];
}

#pragma mark SDK Setup
- (void)setupAdsLoader {
    if(self.adsLoader == nil)
        self.adsLoader = [[IMAAdsLoader alloc] initWithSettings:nil];
    self.adsLoader.delegate = self;
}

- (void)requestAds {
    // Create an ad display container for ad rendering.
    IMAAdDisplayContainer *adDisplayContainer =
    [[IMAAdDisplayContainer alloc] initWithAdContainer:videoView companionSlots:nil];
    // Create an ad request with our ad tag, display container, and optional user context.
    IMAAdsRequest *request = [[IMAAdsRequest alloc] initWithAdsResponse:_vastAdData
                                                  adDisplayContainer:adDisplayContainer
                                                     contentPlayhead:self.contentPlayhead
                                                         userContext:nil];
    [self.adsLoader requestAdsWithRequest:request];
}

- (void)contentDidFinishPlaying:(NSNotification *)notification {
    // Make sure we don't call contentComplete as a result of an ad completing.
}

- (void)finishPlayer
{
    [self dismissViewControllerAnimated:YES completion:^(void){
        if (self.adsManager) {
            [self.adsManager destroy];
            self.adsManager = nil;
        }
        isVideoAdPlaying = NO;
    }];
    
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPVastAdsClosed)])
    {
        [_delegate AdPopcornSSPVastAdsClosed];
    }
}

#pragma mark AdsLoader Delegates
- (void)adsLoader:(IMAAdsLoader *)loader adsLoadedWithData:(IMAAdsLoadedData *)adsLoadedData {
    // Grab the instance of the IMAAdsManager and set ourselves as the delegate.
    self.adsManager = adsLoadedData.adsManager;
    self.adsManager.delegate = self;
    // Create ads rendering settings to tell the SDK to use the in-app browser.
    IMAAdsRenderingSettings *adsRenderingSettings = [[IMAAdsRenderingSettings alloc] init];
    // adsRenderingSettings.webOpenerPresentingController = self;
    // Initialize the ads manager.
    [self.adsManager initializeWithAdsRenderingSettings:adsRenderingSettings];
}

- (void)adsLoader:(IMAAdsLoader *)loader failedWithErrorData:(IMAAdLoadingErrorData *)adErrorData {
    // Something went wrong loading ads. Log the error and play the content.
    NSLog(@"AdPopcornSSPVastPlayer Error loading ads: %@", adErrorData.adError.message);
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPVastAdsShowFailed)])
    {
        [_delegate AdPopcornSSPVastAdsShowFailed];
    }
    [self finishPlayer];
}

#pragma mark AdsManager Delegates
- (void)adsManager:(IMAAdsManager *)adsManager didReceiveAdEvent:(IMAAdEvent *)event {
    // When the SDK notified us that ads have been loaded, play them.
    NSLog(@"AdPopcornSSPVastPlayer didReceiveAdEvent type : %@ ", event.typeString);
    if (event.type == kIMAAdEvent_LOADED) {
        [adsManager start];
    }
    else if(event.type == kIMAAdEvent_STARTED){
        isVideoAdPlaying = YES;
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPVastAdsShowSuccess)])
        {
            [_delegate AdPopcornSSPVastAdsShowSuccess];
        }
    }
    else if (event.type == kIMAAdEvent_ALL_ADS_COMPLETED){
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPVastAdsCompleted)])
        {
            [_delegate AdPopcornSSPVastAdsCompleted];
        }
        [self finishPlayer];
    }
}

- (void)adsManager:(IMAAdsManager *)adsManager didReceiveAdError:(IMAAdError *)error {
    // Something went wrong with the ads manager after ads were loaded. Log the error and play the
    // content.
    NSLog(@"AdPopcornSSPVastPlayer AdsManager error: %@", error.message);
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPVastAdsShowFailed)])
    {
        [_delegate AdPopcornSSPVastAdsShowFailed];
    }
    [self finishPlayer];
}

- (void)adsManagerDidRequestContentPause:(IMAAdsManager *)adsManager {
    // The SDK is going to play ads, so pause the content.
}

- (void)adsManagerDidRequestContentResume:(IMAAdsManager *)adsManager {
    // The SDK is done playing ads (at least for now), so resume the content.
}
@end
