#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AdPopcornSSP/AdPopcornSSPSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface AdPopcornSSPPlugin : NSObject <APSSPSDKInitializeDelegate,
                                         APSSPInterstitialAdDelegate,
                                         APSSPInterstitialVideoAdDelegate,
                                         APSSPRewardVideoAdDelegate,
                                         APSSPVideoMixAdDelegate,
                                         APSSPPopContentsAdDelegate,
                                         APSSPRewardAdPlusEventDelegate>

+ (instancetype)sharedInstance;

// SDK & User Settings
+ (void)initSDK:(NSString *)appKey;
+ (void)setUserId:(NSString *)userId;
+ (void)setLogEnable:(BOOL)enable;

// Interstitial
+ (void)loadInterstitial:(NSString *)appKey placementId:(NSString *)placementId;
+ (void)showInterstitial:(NSString *)appKey placementId:(NSString *)placementId;

// Interstitial Video
+ (void)loadInterstitialVideo:(NSString *)appKey placementId:(NSString *)placementId;
+ (void)showInterstitialVideo:(NSString *)appKey placementId:(NSString *)placementId;

// Reward Video
+ (void)loadRewardVideo:(NSString *)appKey placementId:(NSString *)placementId;
+ (void)showRewardVideo:(NSString *)appKey placementId:(NSString *)placementId;

// Video Mix
+ (void)loadVideoMix:(NSString *)appKey placementId:(NSString *)placementId;
+ (void)showVideoMix:(NSString *)appKey placementId:(NSString *)placementId;

// PopContents
+ (void)openPopContents:(NSString *)appKey placementId:(NSString *)popContentsPlacementId;

// Reward Ad Plus
+ (void)openRewardAdPlusPage:(NSString *)appKey;
+ (void)getRewardAdPlusUserMediaStatus:(NSString *)appKey;
+ (void)getRewardAdPlusUserPlacementStatus:(NSString *)appKey placementId:(NSString *)placementId;
+ (void)setRewardAdPlusEventListener;


@property (nonatomic, strong) NSMutableDictionary *interstitialAds;
@property (nonatomic, strong) NSMutableDictionary *interstitialVideoAds;
@property (nonatomic, strong) NSMutableDictionary *rewardVideoAds;
@property (nonatomic, strong) NSMutableDictionary *videoMixAds;
@property (nonatomic, strong) NSMutableDictionary *popContentsAds;


// MARK: - Internal Helper Method
// Native -> JS 이벤트 전달 (클래스 메서드로 정의하여 Delegate에서도 쉽게 호출 가능)
+ (void)sendEventToJS:(NSString *)event params:(NSDictionary * _Nullable)params;


@end

NS_ASSUME_NONNULL_END

