#import "AdPopcornSSPPlugin.h"
#import "cocos2d.h"
#import "scripting/js-bindings/jswrapper/SeApi.h"
#import <AudioToolbox/AudioToolbox.h>
#include "scripting/js-bindings/manual/jsb_global.h"

static AdPopcornSSPPlugin *_sharedInstance = nil;
static dispatch_once_t onceToken;

@implementation AdPopcornSSPPlugin

@synthesize interstitialAds = _interstitialAds;
@synthesize interstitialVideoAds = _interstitialVideoAds;
@synthesize rewardVideoAds = _rewardVideoAds;
@synthesize videoMixAds = _videoMixAds;
@synthesize popContentsAds = _popContentsAds;


+ (instancetype)sharedInstance {
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    return _sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _interstitialAds = [[NSMutableDictionary alloc] init];
        _interstitialVideoAds = [[NSMutableDictionary alloc] init];
        _rewardVideoAds = [[NSMutableDictionary alloc] init];
        _videoMixAds = [[NSMutableDictionary alloc] init];
        _popContentsAds = [[NSMutableDictionary alloc] init];
    }
    return self;
}

- (UIViewController *)rootViewController {
    return [[[[UIApplication sharedApplication] delegate] window] rootViewController];
}

+ (void)initSDK:(NSString *)appKey {
    [[AdPopcornSSPPlugin sharedInstance] initSDKInstance:appKey];
}

- (void)initSDKInstance:(NSString *)appKey {
    [AdPopcornSSP initializeSDK:appKey];
    [AdPopcornSSP sharedInstance].initializeDelegate = self;
    
}

+ (void)setUserId:(NSString *)userId {
    [AdPopcornSSP setUserId:userId];
}

+ (void)setLogEnable:(BOOL)enable {
    if(enable)
        [AdPopcornSSP setLogLevel:AdPopcornSSPLogTrace];
    else
        [AdPopcornSSP setLogLevel:AdPopcornSSPLogOff];
    [AdPopcornSSP setLogLevel:AdPopcornSSPLogTrace];
}


// MARK: Interstitial
+ (void)loadInterstitial:(NSString *)appKey placementId:(NSString *)placementId {
    [[AdPopcornSSPPlugin sharedInstance] loadInterstitialInstance:appKey placementId:placementId];
}
- (void)loadInterstitialInstance:(NSString *)appKey placementId:(NSString *)placementId {
    AdPopcornSSPInterstitialAd *interstitialAd = _interstitialAds[placementId];
    if (!interstitialAd) {
        interstitialAd = [[AdPopcornSSPInterstitialAd alloc] initWithKey:appKey placementId:placementId viewController:[self rootViewController]];
        interstitialAd.delegate = self;
        _interstitialAds[placementId] = interstitialAd;
    }
    [interstitialAd loadRequest];
}

+ (void)showInterstitial:(NSString *)appKey placementId:(NSString *)placementId {
    [[AdPopcornSSPPlugin sharedInstance] showInterstitialInstance:appKey placementId:placementId];
}
- (void)showInterstitialInstance:(NSString *)appKey placementId:(NSString *)placementId {
    AdPopcornSSPInterstitialAd *interstitialAd = _interstitialAds[placementId];
    if (interstitialAd) {
        [interstitialAd presentFromViewController:[self rootViewController]];
    } else {
        [AdPopcornSSPPlugin sendEventToJS:@"OnInterstitialOpenFailed" params:@{@"placementId": placementId ?: @""}];
    }
}


// MARK: Interstitial Video
+ (void)loadInterstitialVideo:(NSString *)appKey placementId:(NSString *)placementId {
    [[AdPopcornSSPPlugin sharedInstance] loadInterstitialVideoInstance:appKey placementId:placementId];
}

- (void)loadInterstitialVideoInstance:(NSString *)appKey placementId:(NSString *)placementId {
    AdPopcornSSPInterstitialVideoAd *interstitialVideo = _interstitialVideoAds[placementId];
    if (!interstitialVideo) {
        interstitialVideo = [[AdPopcornSSPInterstitialVideoAd alloc] initWithKey:appKey placementId:placementId viewController:[self rootViewController]];
        interstitialVideo.delegate = self;
        _interstitialVideoAds[placementId] = interstitialVideo;
    }
    [interstitialVideo loadRequest];
}

+ (void)showInterstitialVideo:(NSString *)appKey placementId:(NSString *)placementId {
    [[AdPopcornSSPPlugin sharedInstance] showInterstitialVideoInstance:appKey placementId:placementId];
}
- (void)showInterstitialVideoInstance:(NSString *)appKey placementId:(NSString *)placementId {
    AdPopcornSSPInterstitialVideoAd *interstitialVideo = _interstitialVideoAds[placementId];
    if (interstitialVideo && [interstitialVideo isReady]) {
        [interstitialVideo presentFromViewController:[self rootViewController]];
    } else {
        [AdPopcornSSPPlugin sendEventToJS:@"OnInterstitialVideoAdOpenFailed" params:@{@"placementId": placementId ?: @""}];
    }
}


// MARK: Reward Video
+ (void)loadRewardVideo:(NSString *)appKey placementId:(NSString *)placementId {
    [[AdPopcornSSPPlugin sharedInstance] loadRewardVideoInstance:appKey placementId:placementId];
}
- (void)loadRewardVideoInstance:(NSString *)appKey placementId:(NSString *)placementId {
    AdPopcornSSPRewardVideoAd *rewardVideoAd = _rewardVideoAds[placementId];
    if (!rewardVideoAd) {
        rewardVideoAd = [[AdPopcornSSPRewardVideoAd alloc] initWithKey:appKey placementId:placementId viewController:[self rootViewController]];
        rewardVideoAd.delegate = self;
        _rewardVideoAds[placementId] = rewardVideoAd;
    }
    [rewardVideoAd loadRequest];
}

+ (void)showRewardVideo:(NSString *)appKey placementId:(NSString *)placementId {
    [[AdPopcornSSPPlugin sharedInstance] showRewardVideoInstance:appKey placementId:placementId];
}
- (void)showRewardVideoInstance:(NSString *)appKey placementId:(NSString *)placementId {
    AdPopcornSSPRewardVideoAd *rewardVideoAd = _rewardVideoAds[placementId];
    if (rewardVideoAd && [rewardVideoAd isReady]) {
        [rewardVideoAd presentFromViewController:[self rootViewController]];
    } else {
        [AdPopcornSSPPlugin sendEventToJS:@"OnRewardVideoAdOpenFailed" params:@{@"placementId": placementId ?: @""}];
    }
}


// MARK: Video Mix
+ (void)loadVideoMix:(NSString *)appKey placementId:(NSString *)placementId {
    [[AdPopcornSSPPlugin sharedInstance] loadVideoMixInstance:appKey placementId:placementId];
}
- (void)loadVideoMixInstance:(NSString *)appKey placementId:(NSString *)placementId {
    AdPopcornSSPVideoMixAd *videoMixAd = _videoMixAds[placementId];
    if (!videoMixAd) {
        videoMixAd = [[AdPopcornSSPVideoMixAd alloc] initWithKey:appKey placementId:placementId viewController:[self rootViewController]];
        videoMixAd.delegate = self;
        _videoMixAds[placementId] = videoMixAd;
    }
    [videoMixAd loadRequest];
}

+ (void)showVideoMix:(NSString *)appKey placementId:(NSString *)placementId {
    [[AdPopcornSSPPlugin sharedInstance] showVideoMixInstance:appKey placementId:placementId];
}
- (void)showVideoMixInstance:(NSString *)appKey placementId:(NSString *)placementId {
    AdPopcornSSPVideoMixAd *videoMixAd = _videoMixAds[placementId];
    if (videoMixAd && [videoMixAd isReady]) {
        [videoMixAd presentFromViewController:[self rootViewController]];
    } else {
        [self sendEventToJS:@"OnVideoMixAdOpenFailed" params:@{@"placementId": placementId ?: @""}];
    }
}


// MARK: PopContents
+ (void)openPopContents:(NSString *)appKey placementId:(NSString *)popContentsPlacementId {
    [[AdPopcornSSPPlugin sharedInstance] openPopContentsInstance:appKey placementId:popContentsPlacementId];
}
- (void)openPopContentsInstance:(NSString *)appKey placementId:(NSString *)popContentsPlacementId {
    AdPopcornSSPPopContentsAd *popContentsAd = _popContentsAds[popContentsPlacementId];
    if (!popContentsAd) {
        popContentsAd = [[AdPopcornSSPPopContentsAd alloc] initWithAppKey:appKey popContentsPlacementId:popContentsPlacementId viewController:[self rootViewController]];
        popContentsAd.delegate = self;
        _popContentsAds[popContentsPlacementId] = popContentsAd;
    }
    [popContentsAd openPopContents];
}


// MARK: Reward Ad Plus
+ (void)openRewardAdPlusPage:(NSString *)appKey
{
    [[AdPopcornSSPPlugin sharedInstance] openRewardAdPlusPageInstance:appKey];
}

- (void)openRewardAdPlusPageInstance:(NSString *)appKey
{
    [AdPopcornSSPRewardAdPlus openRewardAdPlusViewController:appKey viewCotroller:[[[[UIApplication sharedApplication] delegate] window] rootViewController]];
}

+ (void)getRewardAdPlusUserMediaStatus:(NSString *)appKey
{
    [[AdPopcornSSPPlugin sharedInstance] getRewardAdPlusUserMediaStatusInstance:appKey];
}

- (void)getRewardAdPlusUserMediaStatusInstance:(NSString *)appKey
{
    [AdPopcornSSPRewardAdPlus sharedInstance].delegate = self;
    [AdPopcornSSPRewardAdPlus getRewardAdPlusUserMediaStatus:appKey];
}

+ (void)getRewardAdPlusUserPlacementStatus:(NSString *)appKey placementId:(NSString *)placementId
{
    [[AdPopcornSSPPlugin sharedInstance] getRewardAdPlusUserPlacementStatusInstance:appKey placementId:placementId];
    
}

- (void)getRewardAdPlusUserPlacementStatusInstance:(NSString *)appKey placementId:(NSString *)placementId
{
    [AdPopcornSSPRewardAdPlus sharedInstance].delegate = self;
    [AdPopcornSSPRewardAdPlus getRewardAdPlusUserPlacementStatus:appKey placementId:placementId];
}

+ (void)setRewardAdPlusEventListener
{
    [[AdPopcornSSPPlugin sharedInstance] setRewardAdPlusEventListenerInstance];
}

- (void)setRewardAdPlusEventListenerInstance
{
    [AdPopcornSSPRewardAdPlus sharedInstance].delegate = self;
}

#pragma mark - Delegate Implementations
- (void)AdPopcornSSPSDKDidInitialize {
    NSLog(@"AdPopcornSSPSDKDidInitialize");
    [self sendEventToJS:@"AdPopcornSSPSDKDidInitialize" params:@{}];
}

// Interstitial
- (void)APSSPInterstitialAdLoadSuccess:(AdPopcornSSPInterstitialAd *)ad {
    [self sendEventToJS:@"OnInterstitialLoaded" params:@{@"placementId": ad.placementId ?: @""}];
}
- (void)APSSPInterstitialAdLoadFail:(AdPopcornSSPInterstitialAd *)ad error:(AdPopcornSSPError *)error {
    [self sendEventToJS:@"OnInterstitialLoadFailed" params:@{@"placementId": ad.placementId ?: @"", @"errorCode": @(error.code)}];
}
- (void)APSSPInterstitialAdShowSuccess:(AdPopcornSSPInterstitialAd *)ad {
    [self sendEventToJS:@"OnInterstitialOpened" params:@{@"placementId": ad.placementId ?: @""}];
}
- (void)APSSPInterstitialAdShowFail:(AdPopcornSSPInterstitialAd *)ad error:(AdPopcornSSPError *)error {
    [self sendEventToJS:@"OnInterstitialOpenFailed" params:@{@"placementId": ad.placementId ?: @""}];
}
- (void)APSSPInterstitialAdClosed:(AdPopcornSSPInterstitialAd *)ad {
    [self sendEventToJS:@"OnInterstitialClosed" params:@{@"placementId": ad.placementId ?: @""}];
}
- (void)APSSPInterstitialAdClicked:(AdPopcornSSPInterstitialAd *)ad {
    [self sendEventToJS:@"OnInterstitialClicked" params:@{@"placementId": ad.placementId ?: @""}];
}

// Interstitial Video
- (void)APSSPInterstitialVideoAdLoadSuccess:(AdPopcornSSPInterstitialVideoAd *)ad {
    [self sendEventToJS:@"OnInterstitialVideoAdLoaded" params:@{@"placementId": ad.placementId ?: @""}];
}
- (void)APSSPInterstitialVideoAdLoadFail:(AdPopcornSSPInterstitialVideoAd *)ad error:(AdPopcornSSPError *)error {
    [self sendEventToJS:@"OnInterstitialVideoAdLoadFailed" params:@{@"placementId": ad.placementId ?: @"", @"errorCode": @(error.code)}];
}
- (void)APSSPInterstitialVideoAdShowSuccess:(AdPopcornSSPInterstitialVideoAd *)ad {
    [self sendEventToJS:@"OnInterstitialVideoAdOpened" params:@{@"placementId": ad.placementId ?: @""}];
}
- (void)APSSPInterstitialVideoAdShowFail:(AdPopcornSSPInterstitialVideoAd *)ad {
    [self sendEventToJS:@"OnInterstitialVideoAdOpenFailed" params:@{@"placementId": ad.placementId ?: @""}];
}
- (void)APSSPInterstitialVideoAdClosed:(AdPopcornSSPInterstitialVideoAd *)ad {
    [self sendEventToJS:@"OnInterstitialVideoAdClosed" params:@{@"placementId": ad.placementId ?: @""}];
}

// Reward Video
- (void)APSSPRewardVideoAdLoadSuccess:(AdPopcornSSPRewardVideoAd *)ad {
    [self sendEventToJS:@"OnRewardVideoAdLoaded" params:@{@"placementId": ad.placementId ?: @""}];
}
- (void)APSSPRewardVideoAdLoadFail:(AdPopcornSSPRewardVideoAd *)ad error:(AdPopcornSSPError *)error {
    [self sendEventToJS:@"OnRewardVideoAdLoadFailed" params:@{@"placementId": ad.placementId ?: @"", @"errorCode": @(error.code)}];
}
- (void)APSSPRewardVideoAdShowSuccess:(AdPopcornSSPRewardVideoAd *)ad {
    [self sendEventToJS:@"OnRewardVideoAdOpened" params:@{@"placementId": ad.placementId ?: @""}];
}
- (void)APSSPRewardVideoAdShowFail:(AdPopcornSSPRewardVideoAd *)ad {
    [self sendEventToJS:@"OnRewardVideoAdOpenFailed" params:@{@"placementId": ad.placementId ?: @""}];
}
- (void)APSSPRewardVideoAdClosed:(AdPopcornSSPRewardVideoAd *)ad {
    [self sendEventToJS:@"OnRewardVideoAdClosed" params:@{@"placementId": ad.placementId ?: @""}];
}
- (void)APSSPRewardVideoAdPlayCompleted:(AdPopcornSSPRewardVideoAd *)ad adNetworkNo:(long)adNetworkNo completed:(BOOL)completed {
    [self sendEventToJS:@"OnRewardVideoPlayCompleted" params:@{@"placementId": ad.placementId ?: @"", @"adNetworkNo": @(adNetworkNo), @"completed": @(completed)}];
}

// Video Mix
- (void)APSSPVideoMixAdLoadSuccess:(AdPopcornSSPVideoMixAd *)ad videoMixAdType:(int)type {
    [self sendEventToJS:@"OnVideoMixAdLoaded" params:@{@"placementId": ad.placementId ?: @"", @"videoMixAdType": @(type)}];
}
- (void)APSSPVideoMixAdLoadFail:(AdPopcornSSPVideoMixAd *)ad error:(AdPopcornSSPError *)error {
    [self sendEventToJS:@"OnVideoMixAdLoadFailed" params:@{@"placementId": ad.placementId ?: @"", @"errorCode": @(error.code)}];
}
- (void)APSSPVideoMixAdShowSuccess:(AdPopcornSSPVideoMixAd *)ad {
    [self sendEventToJS:@"OnVideoMixAdOpened" params:@{@"placementId": ad.placementId ?: @""}];
}
- (void)APSSPVideoMixAdShowFail:(AdPopcornSSPVideoMixAd *)ad {
    [self sendEventToJS:@"OnVideoMixAdOpenFailed" params:@{@"placementId": ad.placementId ?: @""}];
}
- (void)APSSPVideoMixAdClosed:(AdPopcornSSPVideoMixAd *)ad videoMixAdType:(int)type {
    [self sendEventToJS:@"OnVideoMixAdClosed" params:@{@"placementId": ad.placementId ?: @"", @"campaignType": @(type)}];
}
- (void)APSSPVideoMixAdPlayCompleted:(AdPopcornSSPVideoMixAd *)ad adNetworkNo:(long)adNetworkNo completed:(BOOL)completed {
    [self sendEventToJS:@"OnVideoMixPlayCompleted" params:@{@"placementId": ad.placementId ?: @"", @"adNetworkNo": @(adNetworkNo), @"completed": @(completed)}];
}

// PopContent
- (void)APSSPPopContentsAdOpenSuccess:(AdPopcornSSPPopContentsAd *)contentsAd
{
    NSLog(@"AdPopcornSSPPlugin APSSPPopContentsAdOpenSuccess");
    [self sendEventToJS:@"OnPopContentsAdOpenSuccess" params:@{}];
}

- (void)APSSPPopContentsAdOpenFail:(AdPopcornSSPPopContentsAd *)contentsAd error:(AdPopcornSSPError *)error
{
    NSLog(@"AdPopcornSSPPlugin APSSPPopContentsAdOpenFail");
    [self sendEventToJS:@"OnPopContentsAdOpenFail" params:@{}];
}

- (void)APSSPPopContentsAdClosed:(AdPopcornSSPPopContentsAd *)contentsAd
{
    NSLog(@"AdPopcornSSPPlugin APSSPPopContentsAdClosed");
    [self sendEventToJS:@"OnPopContentsAdClosed" params:@{}];
}

// Reward Ad Plus
- (void)rewardAdPlusUserMediaStatusWithResult:(BOOL)result
                                   totalBoxCount:(NSInteger)totalBoxCount
                           placementStatusList:(NSArray*)placementStatusList
{
    NSLog(@"AdPopcornSSPPlugin rewardAdPlusUserMediaStatusWithResult");
    NSString *jsonString = @"";
    NSMutableArray *returnArray = [NSMutableArray array];
    for (APSSPRewardAdPlusStatusModel *placementStatusModel in placementStatusList)
    {
        NSMutableDictionary *dictionary = [NSMutableDictionary dictionary];
        dictionary[@"placementId"] = placementStatusModel.placementId;
        dictionary[@"dailyUserLimit"] = @(placementStatusModel.limit);
        dictionary[@"dailyUserCount"] = @(placementStatusModel.current);
        [returnArray addObject:dictionary];
        
        NSError *error = nil;
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:returnArray options:0 error:&error];
        
        if (!error) {
            jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        }
    }
    [self sendEventToJS:@"OnRewardAdPlusUserMediaStatus" params:@{@"result": @(result), @"totalBoxCount": @(totalBoxCount), @"placementStatusList":jsonString}];
}

- (void)rewardAdPlusUserPlacementStatusWithResult:(BOOL)result placementId:(NSString *)placementId dailyUserLimit:(NSInteger)dailyUserLimit dailyUserCount:(NSInteger)dailyUserCount {
    [self sendEventToJS:@"OnRewardAdPlusUserPlacementStatus" params:@{@"result": @(result), @"placementId": placementId ?: @"", @"dailyUserLimit": @(dailyUserLimit), @"dailyUserCount": @(dailyUserCount)}];
}

- (void)closedRewardAdPlusPage {
    [self sendEventToJS:@"OnClosedRewardAdPlusPage" params:@{}];
}

- (void)eventResult:(int)resultCode resultMessage:(NSString *)message {
    [self sendEventToJS:@"OnRewardAdPlusEventResult" params:@{@"resultCode": @(resultCode), @"resultMessage": message ?: @""}];
}

#pragma mark - JS Event
- (void)sendEventToJS:(NSString *)event params:(NSDictionary * _Nullable)params {
    NSLog(@"sendEventToJS : %@", event);
    NSString *jsonString = @"{}";
    if (params) {
        NSError *error;
        NSData *data = [NSJSONSerialization dataWithJSONObject:params options:0 error:&error];
        if (!error && data) {
            jsonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            jsonString = [jsonString stringByReplacingOccurrencesOfString:@"\"" withString:@"\\\""];
        }
    }

    NSString *jsCall = [NSString stringWithFormat:@"if(window.AdPopcornSSPPlugin){ window.AdPopcornSSPPlugin._onNativeEvent('%@', JSON.parse('%@')); }", event, jsonString];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        se::ScriptEngine* se = se::ScriptEngine::getInstance();
        se->evalString([jsCall UTF8String]);
    });
}
@end



