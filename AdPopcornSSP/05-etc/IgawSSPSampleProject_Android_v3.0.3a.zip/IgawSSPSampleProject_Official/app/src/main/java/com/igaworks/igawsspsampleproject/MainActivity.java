package com.igaworks.igawsspsampleproject;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.igaworks.ssp.AdPopcornSSP;
import com.igaworks.ssp.AdSize;
import com.igaworks.ssp.SSPErrorCode;
import com.igaworks.ssp.part.banner.AdPopcornSSPBannerAd;
import com.igaworks.ssp.part.banner.listener.IBannerEventCallbackListener;
import com.igaworks.ssp.part.interstitial.AdPopcornSSPInterstitialAd;
import com.igaworks.ssp.part.interstitial.listener.IInterstitialEventCallbackListener;
import com.igaworks.ssp.part.nativead.AdPopcornSSPNativeAd;
import com.igaworks.ssp.part.nativead.binder.AdMobViewBinder;
import com.igaworks.ssp.part.nativead.binder.AdPopcornSSPViewBinder;
import com.igaworks.ssp.part.nativead.binder.MintegralViewBinder;
import com.igaworks.ssp.part.nativead.listener.INativeAdEventCallbackListener;
import com.igaworks.ssp.part.video.AdPopcornSSPInterstitialVideoAd;
import com.igaworks.ssp.part.video.AdPopcornSSPRewardVideoAd;
import com.igaworks.ssp.part.video.listener.IInterstitialVideoAdEventCallbackListener;
import com.igaworks.ssp.part.video.listener.IRewardVideoAdEventCallbackListener; 


public class MainActivity extends Activity {
    private AdPopcornSSPRewardVideoAd apRewardVideoAd;
    private AdPopcornSSPBannerAd apBannerAd_320x50, apBannerAd_320x100, apBannerAd_300x250;
    private AdPopcornSSPInterstitialAd apInterstitialAd;
    private AdPopcornSSPNativeAd apNativeAd, apMediationNativeAd;
    private AdPopcornSSPInterstitialVideoAd apInterstitialVideoAd;

    private final static String BANNER_320x50_PLACEMENT_KEY = "BANNER_320x50";
    private final static String BANNER_320x100_PLACEMENT_KEY = "BANNER_320x100";
    private final static String BANNER_300x250_PLACEMENT_KEY = "BANNER_300x250";
    private final static String INTERSTITIAL_PLACEMENT_KEY = "INTERSTITIAL";
    private final static String REWARD_VIDEO_PLACEMENT_KEY = "REWARD_VIDEO";
    private final static String INTERSTITIAL_VIDEO_PLACEMENT_KEY = "VIDEO";
    private final static String NATIVE_PLACEMENT_KEY = "NATIVE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        /* 주의 사항
            샘플에서 사용하고 있는 placement ID 값은 반드시 애드팝콘에서 발급받은 키로 변경하여 사용하여야 합니다.
            기타 자세한 사항 및 최신 SDK는 애드팝콘 SSP 가이드 페이지를 참고해 주시기 바랍니다
        */

        // 1. AdPopcornSSP SDK 초기화
        if(!AdPopcornSSP.isInitialized(MainActivity.this))
            AdPopcornSSP.init(MainActivity.this);

        // 2. Banner 320x50
        apBannerAd_320x50 = findViewById(R.id.banner_container);
        apBannerAd_320x50.setAdSize(AdSize.BANNER_320x50);
        apBannerAd_320x50.setPlacementId(BANNER_320x50_PLACEMENT_KEY);
        apBannerAd_320x50.setBannerEventCallbackListener(new IBannerEventCallbackListener() {
            @Override
            public void OnBannerAdReceiveSuccess() {
                Log.i("APSSPTestApp", "320x50 OnBannerAdReceiveSuccess");
                Toast.makeText(MainActivity.this, "OnBannerAdReceiveSuccess : " + apBannerAd_320x50.getCurrentNetwork(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void OnBannerAdReceiveFailed(SSPErrorCode errorCode) {
                Log.i("APSSPTestApp", "320x50 BannerOnBannerAdReceiveFailed : " + errorCode.getErrorMessage());
                Toast.makeText(MainActivity.this, "OnBannerAdReceiveFailed : " + errorCode.getErrorCode() + ", " + errorCode.getErrorMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void OnBannerAdClicked() {
                Log.i("APSSPTestApp", "320x50 OnBannerAdClicked");
                Toast.makeText(MainActivity.this, "OnBannerAdClicked : " + apBannerAd_320x50.getCurrentNetwork(), Toast.LENGTH_SHORT).show();
            }
        });

        Button button_load_banner1 = findViewById(R.id.button_banner1_load);
        button_load_banner1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(apBannerAd_320x50 != null)
                    apBannerAd_320x50.loadAd();
            }
        });

        Button button_stop_banner1 = findViewById(R.id.button_banner1_stop);
        button_stop_banner1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(apBannerAd_320x50 != null)
                    apBannerAd_320x50.stopAd();
            }
        });

        // 3. Banner 320x100
        apBannerAd_320x100 = findViewById(R.id.banner_container_2);
        apBannerAd_320x100.setAdSize(AdSize.BANNER_320x100);
        apBannerAd_320x100.setPlacementId(BANNER_320x100_PLACEMENT_KEY);
        apBannerAd_320x100.setBannerEventCallbackListener(new IBannerEventCallbackListener() {
            @Override
            public void OnBannerAdReceiveSuccess() {
                Log.i("AdPopcornSSPTestApp", "320x100 OnBannerAdReceiveSuccess");
                Toast.makeText(MainActivity.this, "OnBannerAdReceiveSuccess : " + apBannerAd_320x100.getCurrentNetwork(), Toast.LENGTH_SHORT).show();
                apBannerAd_320x100.setVisibility(View.VISIBLE);
            }

            @Override
            public void OnBannerAdReceiveFailed(SSPErrorCode errorCode) {
                Log.i("AdPopcornSSPTestApp", "320x100 BannerOnBannerAdReceiveFailed : " + errorCode.getErrorMessage());
                Toast.makeText(MainActivity.this, "OnBannerAdReceiveFailed : " + errorCode.getErrorCode() + ", " + errorCode.getErrorMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void OnBannerAdClicked() {
                Log.i("AdPopcornSSPTestApp", "320x100 OnBannerAdClicked");
                Toast.makeText(MainActivity.this, "OnBannerAdClicked : " + apBannerAd_320x100.getCurrentNetwork(), Toast.LENGTH_SHORT).show();
            }
        });

        Button button_load_banner2 = findViewById(R.id.button_banner2_load);
        button_load_banner2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(apBannerAd_320x100 != null)
                    apBannerAd_320x100.loadAd();
            }
        });

        Button button_stop_banner2 = findViewById(R.id.button_banner2_stop);
        button_stop_banner2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(apBannerAd_320x100 != null)
                    apBannerAd_320x100.stopAd();
            }
        });

        // 4. Banner 300x250
        apBannerAd_300x250 = findViewById(R.id.banner_container_3);
        apBannerAd_300x250.setAdSize(AdSize.BANNER_300x250);
        apBannerAd_300x250.setPlacementId(BANNER_300x250_PLACEMENT_KEY);
        apBannerAd_300x250.setBannerEventCallbackListener(new IBannerEventCallbackListener() {
            @Override
            public void OnBannerAdReceiveSuccess() {
                Log.i("AdPopcornSSPTestApp", "300x250 OnBannerAdReceiveSuccess");
                Toast.makeText(MainActivity.this, "OnBannerAdReceiveSuccess : " + apBannerAd_300x250.getCurrentNetwork(), Toast.LENGTH_SHORT).show();
                apBannerAd_300x250.setVisibility(View.VISIBLE);
            }

            @Override
            public void OnBannerAdReceiveFailed(SSPErrorCode errorCode) {
                Log.i("AdPopcornSSPTestApp", "300x250 BannerOnBannerAdReceiveFailed : " + errorCode.getErrorMessage());
                Toast.makeText(MainActivity.this, "OnBannerAdReceiveFailed : " + errorCode.getErrorCode() + ", " + errorCode.getErrorMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void OnBannerAdClicked() {
                Log.i("AdPopcornSSPTestApp", "300x250 OnBannerAdClicked");
                Toast.makeText(MainActivity.this, "OnBannerAdClicked : " + apBannerAd_300x250.getCurrentNetwork(), Toast.LENGTH_SHORT).show();
            }
        });

        Button button_load_banner3 = findViewById(R.id.button_banner3_load);
        button_load_banner3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(apBannerAd_300x250 != null)
                    apBannerAd_300x250.loadAd();
            }
        });

        Button button_stop_banner3 = findViewById(R.id.button_banner3_stop);
        button_stop_banner3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(apBannerAd_300x250 != null)
                    apBannerAd_300x250.stopAd();
            }
        });

        // 5. interstitialAd
        apInterstitialAd = new AdPopcornSSPInterstitialAd(this);
        apInterstitialAd.setPlacementId(INTERSTITIAL_PLACEMENT_KEY);
        apInterstitialAd.setInterstitialEventCallbackListener(new IInterstitialEventCallbackListener() {
            @Override
            public void OnInterstitialLoaded() {
                Log.i("AdPopcornSSPTestApp", "OnInterstitialLoaded");
                Toast.makeText(MainActivity.this, "OnInterstitialLoaded : " + apInterstitialAd.getCurrentNetwork(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void OnInterstitialOpened() {
                Log.i("AdPopcornSSPTestApp", "OnInterstitialOpened");
                Toast.makeText(MainActivity.this, "OnInterstitialOpened", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void OnInterstitialReceiveFailed(SSPErrorCode errorCode) {
                Log.i("AdPopcornSSPTestApp", "OnInterstitialReceiveFailed : " + errorCode.getErrorCode() + ", errorMessage : " + errorCode.getErrorMessage());
                Toast.makeText(MainActivity.this, "OnInterstitialReceiveFailed : " + errorCode.getErrorCode() + ", errorMessage : " + errorCode.getErrorMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void OnInterstitialOpenFailed(SSPErrorCode errorCode) {
                Log.i("AdPopcornSSPTestApp", "OnInterstitialOpenFailed : " + errorCode.getErrorCode() + ", errorMessage : " + errorCode.getErrorMessage());
                Toast.makeText(MainActivity.this, "OnInterstitialOpenFailed : " + errorCode.getErrorCode() + ", errorMessage : " + errorCode.getErrorMessage(), Toast.LENGTH_SHORT).show();
            }


            @Override
            public void OnInterstitialClosed(int closeEvent) {
                Log.i("AdPopcornSSPTestApp", "OnInterstitialClosed : " + closeEvent);
                if(closeEvent == AdPopcornSSPInterstitialAd.CloseEvent.UNKNOWN)
                    Toast.makeText(MainActivity.this, "OnInterstitialClosed : unknwon", Toast.LENGTH_SHORT).show();
                else if(closeEvent == AdPopcornSSPInterstitialAd.CloseEvent.CLICK_CLOSE_BTN)
                    Toast.makeText(MainActivity.this, "OnInterstitialClosed : click close btn", Toast.LENGTH_SHORT).show();
                else if(closeEvent == AdPopcornSSPInterstitialAd.CloseEvent.PRESSED_BACK_KEY)
                    Toast.makeText(MainActivity.this, "OnInterstitialClosed : pressed back key", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void OnInterstitialClicked() {
                Log.i("AdPopcornSSPTestApp", "OnInterstitialClicked");
                Toast.makeText(MainActivity.this, "OnInterstitialClicked", Toast.LENGTH_SHORT).show();
            }
        });

        Button button_load_interstitial = findViewById(R.id.button_interstitial_load);
        button_load_interstitial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(apInterstitialAd != null)
                    apInterstitialAd.loadAd();
            }
        });

        Button button_show_interstitial = findViewById(R.id.button_interstitial_show);
        button_show_interstitial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(apInterstitialAd != null && apInterstitialAd.isLoaded())
                    apInterstitialAd.showAd();
                else
                    Toast.makeText(MainActivity.this, "InterstitialAd is not loaded", Toast.LENGTH_SHORT).show();
            }
        });


        // 6.Reward Video
        apRewardVideoAd = new AdPopcornSSPRewardVideoAd(this);
        apRewardVideoAd.setPlacementId(REWARD_VIDEO_PLACEMENT_KEY);
        apRewardVideoAd.setRewardVideoAdEventCallbackListener(iRewardVideoAdEventCallbackListener);
        Button button_reward_video_load = findViewById(R.id.button_reward_video_load);
        button_reward_video_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(apRewardVideoAd != null)
                    apRewardVideoAd.loadAd();
            }
        });

        Button button_reward_video_show = findViewById(R.id.button_reward_video_show);
        button_reward_video_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(apRewardVideoAd != null && apRewardVideoAd.isReady())
                    apRewardVideoAd.showAd();
                else
                    Toast.makeText(MainActivity.this, "RewardVideo is not loaded", Toast.LENGTH_SHORT).show();
            }
        });


        // 8. Native Ad(SSP Mediation, 샘플로 admob, mintegral mediation만 제공)
        // admob, mintegral 이외의 업체 코드는 가이드 페이지의 샘플 코드를 참고.
        apMediationNativeAd = (AdPopcornSSPNativeAd) findViewById(R.id.igaw_mediation_native_ad);
        apMediationNativeAd.setPlacementId(NATIVE_PLACEMENT_KEY);

        AdPopcornSSPViewBinder igawMediationViewBinder = new AdPopcornSSPViewBinder.Builder(R.id.igaw_native_ad_view)
                .iconImageViewId(R.id.igaw_native_ad_icon_image1)
                .descViewId(R.id.igaw_native_ad_desc1)
                .mainImageViewId(R.id.igaw_native_ad_main_image1)
                .titleViewId(R.id.igaw_native_ad_title1)
                .callToActionId(R.id.igaw_native_ad_ctatext1)
                .build();

        apMediationNativeAd.setAdPopcornSSPViewBinder(igawMediationViewBinder);

        AdMobViewBinder adMobViewBinder = new AdMobViewBinder.Builder(R.id.admob_unified_native_ad_view, R.layout.admob_native_ad_unit_layout)
                .iconViewId(R.id.admob_ad_app_icon)
                .headlineViewId(R.id.admob_ad_headline)
                .bodyViewId(R.id.admob_ad_body)
                .mediaViewId(R.id.admob_ad_media)
                .callToActionId(R.id.admob_ad_call_to_action)
                .advertiserViewId(R.id.admob_ad_advertiser)
                .priceViewId(R.id.admob_ad_price)
                .starRatingViewId(R.id.admob_ad_stars)
                .storeViewId(R.id.admob_ad_store)
                .build();
        apMediationNativeAd.setAdMobViewBinder(adMobViewBinder);

        MintegralViewBinder mintegralViewBinder = new MintegralViewBinder.Builder(R.id.mintegral_native_ad_view, R.layout.mintegral_native_ad_unit_layout)
                .mainImageViewId(R.id.mintegral_native_main_image)
                .iconViewId(R.id.mintegral_native_icon_image)
                .titleViewId(R.id.mintegral_native_title)
                .descViewId(R.id.mintegral_native_text)
                .adCallViewId(R.id.mintegral_native_cta)
                .adChoiceViewId(R.id.mintegral_ad_choice_image)
                .build();
        apMediationNativeAd.setMintegralViewBinder(mintegralViewBinder);

        apMediationNativeAd.setNativeAdEventCallbackListener(new INativeAdEventCallbackListener() {
            @Override
            public void onNativeAdLoadSuccess() {
                Log.i("AdPopcornSSPTestApp", "Mediation NativeAd onNativeAdLoadSuccess : " + apMediationNativeAd.isLoaded());
                Toast.makeText(MainActivity.this, "onNativeAdLoadSuccess", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNativeAdLoadFailed(SSPErrorCode errorCode) {
                Log.i("AdPopcornSSPTestApp", "Mediation NativeAd onNativeAdLoadFailed : " + apMediationNativeAd.isLoaded() +  " errorCode : " + errorCode.getErrorMessage());
                Toast.makeText(MainActivity.this, "onNativeAdLoadFailed : " + errorCode.getErrorCode() + ", " + errorCode.getErrorMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onImpression() {
                Log.i("AdPopcornSSPTestApp", "Mediation NativeAd onImpression");
                Toast.makeText(MainActivity.this, "onImpression", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onClicked() {
                Log.i("AdPopcornSSPTestApp", "Mediation NativeAd onClicked");
                Toast.makeText(MainActivity.this, "onClicked", Toast.LENGTH_SHORT).show();
            }
        });

        Button button_mediation_native_ad_load = (Button) findViewById(R.id.button_mediation_native_ad_load);
        button_mediation_native_ad_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                apMediationNativeAd.loadAd();
            }
        });

        // 9. Interstitial Video
        apInterstitialVideoAd = new AdPopcornSSPInterstitialVideoAd(this);
        apInterstitialVideoAd.setPlacementId(INTERSTITIAL_VIDEO_PLACEMENT_KEY);
        apInterstitialVideoAd.setEventCallbackListener(interstitialVideoAdEventCallbackListener);
        Button button_interstitial_video_load = findViewById(R.id.button_interstitial_video_load);
        button_interstitial_video_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(apInterstitialVideoAd != null)
                    apInterstitialVideoAd.loadAd();
            }
        });

        Button button_interstitial_video_show = findViewById(R.id.button_interstitial_video_show);
        button_interstitial_video_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(apInterstitialVideoAd != null && apInterstitialVideoAd.isReady())
                    apInterstitialVideoAd.showAd();
                else
                    Toast.makeText(MainActivity.this, "Interstitial VideoAd is not loaded", Toast.LENGTH_SHORT).show();
            }
        });
    }

    IRewardVideoAdEventCallbackListener iRewardVideoAdEventCallbackListener = new IRewardVideoAdEventCallbackListener() {
        @Override
        public void OnRewardVideoAdLoaded() {
            // 광고 로드 성공
            Toast.makeText(MainActivity.this, "OneButton OnRewardVideoAdLoaded", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OneButton OnRewardVideoAdLoaded");
        }

        @Override
        public void OnRewardVideoAdLoadFailed(SSPErrorCode sspErrorCode) {
            // 광고 로드 실패
            Toast.makeText(MainActivity.this, "OnRewardVideoAdLoadFailed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdLoadFailed");
        }

        @Override
        public void OnRewardVideoAdOpened() {
            Toast.makeText(MainActivity.this, "OnRewardVideoShowSuccess", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoShowSuccess");
        }

        @Override
        public void OnRewardVideoAdOpenFalied() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed");
        }

        @Override
        public void OnRewardVideoAdClosed() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed");
        }

        @Override
        public void OnRewardVideoPlayCompleted(int networkId, boolean completed) {
            Toast.makeText(MainActivity.this, "OnRewardVideoPlayCompleted : " + networkId + ", " +
                            "completed : " + completed,
                    Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoPlayCompleted : " + networkId + ", " +
                    "completed : " + completed);
            onCompletedRewardVideoAd();
        }
    };

    IInterstitialVideoAdEventCallbackListener interstitialVideoAdEventCallbackListener = new IInterstitialVideoAdEventCallbackListener() {
        @Override
        public void OnInterstitialVideoAdLoaded() {

        }

        @Override
        public void OnInterstitialVideoAdLoadFailed(SSPErrorCode sspErrorCode) {

        }

        @Override
        public void OnInterstitialVideoAdOpened() {

        }

        @Override
        public void OnInterstitialVideoAdOpenFalied() {

        }

        @Override
        public void OnInterstitialVideoAdClosed() {

        }
    };

    private void onCompletedRewardVideoAd(){
        // 리워드 비디오가 정상적으로 종료 되었을 때 처리.
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 8. Activity Life cycle에 맞춰 onResume 연동
        if(apBannerAd_320x50 != null)
            apBannerAd_320x50.onResume();
        if(apBannerAd_320x100 != null)
            apBannerAd_320x100.onResume();
        if(apBannerAd_300x250 != null)
            apBannerAd_300x250.onResume();
        if(apRewardVideoAd != null)
            apRewardVideoAd.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 9. Activity Life cycle에 맞춰 onResume 연동
        if(apBannerAd_320x50 != null)
            apBannerAd_320x50.onPause();
        if(apBannerAd_320x100 != null)
            apBannerAd_320x100.onPause();
        if(apBannerAd_300x250 != null)
            apBannerAd_300x250.onPause();
        if(apRewardVideoAd != null)
            apRewardVideoAd.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 9. 종료.
        if(apRewardVideoAd != null)
            apRewardVideoAd.destroy();
        if(apInterstitialVideoAd != null)
            apInterstitialVideoAd.destroy();
        AdPopcornSSP.destroy();
    }
}


