package com.igaworks.igawsspsampleproject;

import android.app.Activity;
import android.util.Log;

import com.igaworks.ssp.SSPErrorCode;
import com.igaworks.ssp.part.video.IgawRewardVideoAd;
import com.igaworks.ssp.part.video.listener.IRewardVideoAdEventCallbackListener;
//import com.mintegral.msdk.MIntegralSDK;
//import com.mintegral.msdk.out.MIntegralSDKFactory;
//import com.mintegral.msdk.out.MTGRewardVideoHandler;
//import com.mintegral.msdk.out.RewardVideoListener;
import com.mobvista.msdk.MobVistaSDK;
import com.mobvista.msdk.out.MVRewardVideoHandler;
import com.mobvista.msdk.out.MobVistaSDKFactory;
import com.mobvista.msdk.out.RewardVideoListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.services.UnityServices;
import com.unity3d.services.monetization.IUnityMonetizationListener;
import com.unity3d.services.monetization.UnityMonetization;
import com.unity3d.services.monetization.placementcontent.ads.IShowAdListener;
import com.unity3d.services.monetization.placementcontent.ads.ShowAdPlacementContent;
import com.unity3d.services.monetization.placementcontent.core.PlacementContent;

import java.util.ArrayList;
import java.util.Map;

public class HMRewardVideoMediation {
    private final String TAG = "HMRewardVideoMediation";

    /////////////////////////////////////////////////////
    // 반드시 아래의 내용이 맞는지 확인해 주세요
    // AdPopcorn SSP Settings
    private String ADPOPCORN_PLACEMENTID = "wzbu2ob62if5zth";

    // Mintegral Settings
    private String MINTEGRAL_APPID = "108970";
    private String MINTEGRAL_APPKEY = "2f23f5c5f0cc24455e0b5a73067c96ff";
    private String MINTEGRAL_UNITID = "69378";
    private String MINTEGRAL_REWARDID = "1";

    // Unity Settings
    private String UNITYADS_PLACEMENTID = "roulettetv_android";
    private String UNITYADS_GAMEID = "2964975";
    // 1. 테스트 종료 후, 반드시 false로 바꿔준다.
    private boolean UNITY_TESTMODE = true;

    ///////////////////////////////////////////////

    private Activity activity;

    private IgawRewardVideoAd igawRewardVideoAd;
    private boolean isReadyRewardVideoAd = false;
    private String readyMediationName = "";
    //private MTGRewardVideoHandler mMTGRewardVideoHandler;
    private MVRewardVideoHandler mMTGRewardVideoHandler;

    private final String IGAW = "IGAW";
    private final String MINTEGRAL = "MINTEGRAL";
    private final String UNITY_ADS = "UNITY_ADS";

    private ArrayList<String> mediationSchedule = new ArrayList<String>();
    private int currentScheduleIndex;

    private HMRewardVideoEventListener hmRewardVideoEventListener;

    public interface HMRewardVideoEventListener {
        void OnRewardVideoAdLoaded(); // 비디오 광고 로드 성공
        void OnRewardVideoAdLoadFailed(); // 비디오 광고 로드 실패
        void OnRewardVideoAdClosed(); // 비디오 광고 close(UnityAds는 지원 안함)
        void OnRewardVideoShowSuccess(); // 비디오 광고 노출 성공
        void OnRewardVideoShowFailed(); // 비디오 광고 노출 실패
        void OnAdPopcornSSPVideoCompleted(long quantity); // 애드팝콘 SSP 비디오 광고 재생 완료
        void OnMintegralVideoCompleted(float RewardAmout); //Mintegral 비디오 광고 재생 완료
        void OnUnityAdsVideoCompleted(); //UnityAds 비디오 광고 재생 완료.
    }

    public HMRewardVideoMediation(Activity activity, HMRewardVideoEventListener hmRewardVideoEventListener) {
        this.activity = activity;
        currentScheduleIndex = 0;

        // 2. 원하는 순서대로 미디에이션 스케쥴 설정
        if(mediationSchedule == null)
            mediationSchedule = new ArrayList<String>();

        mediationSchedule.add(MINTEGRAL);
        mediationSchedule.add(UNITY_ADS);
        mediationSchedule.add(IGAW);

        this.hmRewardVideoEventListener = hmRewardVideoEventListener;
    }

    public void loadRewardVideoAd(){
        if(isReadyRewardVideoAd){
            Log.i(TAG, "이미 비디오가 로딩되어 있습니다.");
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoAdLoaded();
            return;
        }
        readyMediationName = "";
        currentScheduleIndex = 0;
        internalLoadRewardVideoAd();
    }

    public boolean isReady(){
        return isReadyRewardVideoAd;
    }

    public void showRewardVideoAd(){
        if(isReadyRewardVideoAd){
            if(readyMediationName.equalsIgnoreCase(IGAW)){
                igawRewardVideoAd.showAd();
                // IGAW 광고의 show 관련 event는 IRewardVideoAdEventCallbackListener에서 처리
                return;
            }
            else if(readyMediationName.equalsIgnoreCase(MINTEGRAL)){
                if(mMTGRewardVideoHandler.isReady()) {
                    mMTGRewardVideoHandler.show(MINTEGRAL_REWARDID);
                    // Mintegral 광고의 show 관련 event는 RewardVideoListener에서 처리
                    return;
                }
            }
            else if(readyMediationName.equalsIgnoreCase(UNITY_ADS)){
                if (UnityMonetization.isReady (UNITYADS_PLACEMENTID)) {
                    PlacementContent pc = UnityMonetization.getPlacementContent (UNITYADS_PLACEMENTID);
                    if (pc.getType().equalsIgnoreCase ("SHOW_AD")) {
                        ShowAdPlacementContent p = (ShowAdPlacementContent) pc;
                        p.show(activity, unityShowListener);
                        return;
                    }
                }
            }
        }
        if(hmRewardVideoEventListener != null)
            hmRewardVideoEventListener.OnRewardVideoShowFailed();
    }

    public void destroy(){
        if(igawRewardVideoAd != null)
            igawRewardVideoAd.destroy();
    }


    private void initIgawRewardVideoAd(){
        igawRewardVideoAd = new IgawRewardVideoAd(activity);
        igawRewardVideoAd.setPlacementId(ADPOPCORN_PLACEMENTID);
        igawRewardVideoAd.setRewardVideoAdEventCallbackListener(iRewardVideoAdEventCallbackListener);
    }

    private void initMintegralRewardVideo(){
        //MIntegralSDK sdk = MIntegralSDKFactory.getMIntegralSDK();
        //Map<String, String> map = sdk.getMTGConfigurationMap(MINTEGRAL_APPID, MINTEGRAL_APPKEY);

        MobVistaSDK sdk = MobVistaSDKFactory.getMobVistaSDK();
        Map<String, String> map = sdk.getMVConfigurationMap(MINTEGRAL_APPID, MINTEGRAL_APPKEY);
        sdk.init(map, activity);
        if(mMTGRewardVideoHandler == null) {
            //mMTGRewardVideoHandler = new MTGRewardVideoHandler(activity, MINTEGRAL_UNITID);
            //mMTGRewardVideoHandler.setRewardVideoListener(mintegralRewardVideoListener);
            mMTGRewardVideoHandler = new MVRewardVideoHandler(activity, MINTEGRAL_UNITID);
            mMTGRewardVideoHandler.setRewardVideoListener(mintegralRewardVideoListener);
        }
    }

    private void initUnityAdsRewardVideo(){
        if(UnityMonetization.isReady(UNITYADS_PLACEMENTID)){
            readyMediationName = UNITY_ADS;
            isReadyRewardVideoAd = true;
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoAdLoaded();
        }
        else {
            UnityMonetization.initialize(activity, UNITYADS_GAMEID, unityMonetizationListener, UNITY_TESTMODE);
        }
    }

    private void internalLoadRewardVideoAd(){
        if(currentScheduleIndex >= mediationSchedule.size()) {
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoAdLoadFailed();
            return;
        }
        String mediationName = mediationSchedule.get(currentScheduleIndex);
        currentScheduleIndex++;
        if(mediationName.equalsIgnoreCase(IGAW)){
            initIgawRewardVideoAd();
            igawRewardVideoAd.loadAd();
        }
        else if(mediationName.equalsIgnoreCase(MINTEGRAL)){
            initMintegralRewardVideo();
            if(mMTGRewardVideoHandler != null)
                mMTGRewardVideoHandler.load();
        }
        else if(mediationName.equalsIgnoreCase(UNITY_ADS)){
            initUnityAdsRewardVideo();
        }
    }

    // IGAW RewardVideo Listener
    IRewardVideoAdEventCallbackListener iRewardVideoAdEventCallbackListener = new IRewardVideoAdEventCallbackListener() {
        @Override
        public void OnRewardVideoAdLoaded() {
            Log.i(TAG, "IgawSSP OnRewardVideoAdLoaded");
            isReadyRewardVideoAd = true;
            readyMediationName = IGAW;
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoAdLoaded();
        }

        @Override
        public void OnRewardVideoAdLoadFailed(SSPErrorCode errorCode) {
            Log.i(TAG, "IgawSSP OnRewardVideoAdLoadFailed");
            // AdPopcornSSP Reward Video 광고가 없는 경우 다음 미디에이션 광고 노출 시도
            internalLoadRewardVideoAd();
        }

        @Override
        public void OnRewardVideoAdOpened() {
            Log.i(TAG, "IgawSSP OnRewardVideoAdOpened");
            isReadyRewardVideoAd = false;
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoShowSuccess();
        }

        @Override
        public void OnRewardVideoAdOpenFalied() {
            Log.i(TAG, "IgawSSP OnRewardVideoAdOpenFalied");
            isReadyRewardVideoAd = false;
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoShowFailed();
        }

        @Override
        public void OnRewardVideoAdClosed() {
            Log.i(TAG, "IgawSSP OnRewardVideoAdClosed");
            isReadyRewardVideoAd = false;
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoAdClosed();
        }

        @Override
        public void OnRewardVideoPlayCompleted(long quantity, String currency) {
            Log.i(TAG, "IgawSSP OnRewardVideoPlayCompleted");
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnAdPopcornSSPVideoCompleted(quantity);
        }
    };

/*    RewardVideoListener mintegralRewardVideoListener = new RewardVideoListener() {

        @Override
        public void onLoadSuccess(String unitId) {
            Log.d(TAG, "Mintegral onLoadSuccess:" + Thread.currentThread());
        }

        @Override
        public void onVideoLoadSuccess(String unitId) {
            Log.d(TAG, "Mintegral onVideoLoadSuccess:" + Thread.currentThread());
            readyMediationName = MINTEGRAL;
            isReadyRewardVideoAd = true;
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoAdLoaded();
        }

        @Override
        public void onVideoLoadFail(String errorMsg) {
            Log.d(TAG, "Mintegral onVideoLoadFail errorMsg:" + errorMsg);
            // Mintegral Reward Video 광고가 없는 경우 다음 미디에이션 광고 노출 시도
            internalLoadRewardVideoAd();
        }

        @Override
        public void onShowFail(String errorMsg) {
            Log.d(TAG, "Mintegral onShowFail=" + errorMsg);
            isReadyRewardVideoAd = false;
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoShowFailed();
        }

        @Override
        public void onAdShow() {
            Log.d(TAG, "Mintegral onAdShow");
            isReadyRewardVideoAd = false;
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoShowSuccess();
        }

        @Override
        public void onAdClose(boolean isCompleteView, String RewardName, float RewardAmout) {
            Log.d(TAG, "Mintegral onAdClose rewardinfo :" + "RewardName:" + RewardName + "RewardAmout:" + RewardAmout + " isCompleteView：" + isCompleteView);
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoAdClosed();
            if (isCompleteView) {
                if(hmRewardVideoEventListener != null)
                    hmRewardVideoEventListener.OnMintegralVideoCompleted(RewardAmout);
            }

            if(mMTGRewardVideoHandler.isReady()) {
                readyMediationName = MINTEGRAL;
                isReadyRewardVideoAd = true;
                if (hmRewardVideoEventListener != null)
                    hmRewardVideoEventListener.OnRewardVideoAdLoaded();
            }
        }

        @Override
        public void onVideoAdClicked(String unitId) {
            Log.d(TAG, "Mintegral onVideoAdClicked");
        }
    };*/

    RewardVideoListener mintegralRewardVideoListener = new RewardVideoListener() {
        @Override
        public void onVideoLoadSuccess(String unitId) {
            Log.d(TAG, "Mintegral onVideoLoadSuccess:" + Thread.currentThread());
            readyMediationName = MINTEGRAL;
            isReadyRewardVideoAd = true;
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoAdLoaded();
        }

        @Override
        public void onVideoLoadFail(String errorMsg) {
            Log.d(TAG, "Mintegral onVideoLoadFail errorMsg : " + errorMsg);
            // Mintegral Reward Video 광고가 없는 경우 다음 미디에이션 광고 노출 시도
            internalLoadRewardVideoAd();
        }

        @Override
        public void onShowFail(String errorMsg) {
            Log.d(TAG, "Mintegral onShowFail=" + errorMsg);
            isReadyRewardVideoAd = false;
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoShowFailed();
        }

        @Override
        public void onAdShow() {
            Log.d(TAG, "Mintegral onAdShow");
            isReadyRewardVideoAd = false;
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoShowSuccess();
        }

        @Override
        public void onAdClose(boolean isCompleteView, String RewardName, float RewardAmout) {
            Log.d(TAG, "Mintegral onAdClose rewardinfo :" + "RewardName:" + RewardName + "RewardAmout:" + RewardAmout + " isCompleteView：" + isCompleteView);
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoAdClosed();
            if (isCompleteView) {
                if(hmRewardVideoEventListener != null)
                    hmRewardVideoEventListener.OnMintegralVideoCompleted(RewardAmout);
            }

            if(mMTGRewardVideoHandler.isReady()) {
                readyMediationName = MINTEGRAL;
                isReadyRewardVideoAd = true;
                if (hmRewardVideoEventListener != null)
                    hmRewardVideoEventListener.OnRewardVideoAdLoaded();
            }
        }

        @Override
        public void onVideoAdClicked(String unitId) {
            Log.d(TAG, "Mintegral onVideoAdClicked");
        }
    };

    IUnityMonetizationListener unityMonetizationListener = new IUnityMonetizationListener() {
        @Override
        public void onPlacementContentReady(String placementId, PlacementContent placementContent) {
            if(placementId.equalsIgnoreCase(UNITYADS_PLACEMENTID)){
                if (placementContent instanceof ShowAdPlacementContent) {
                    ShowAdPlacementContent adPlacementContent = ((ShowAdPlacementContent) placementContent);
                    if (adPlacementContent.isRewarded ()) {
                        Log.d(TAG, "UnityAds onPlacementContentReady");
                        readyMediationName = UNITY_ADS;
                        isReadyRewardVideoAd = true;
                        if(hmRewardVideoEventListener != null)
                            hmRewardVideoEventListener.OnRewardVideoAdLoaded();
                    }
                }
            }
        }

        @Override
        public void onPlacementContentStateChange(String placementId, PlacementContent placementContent,
                                                  UnityMonetization.PlacementContentState previousState, UnityMonetization.PlacementContentState newState) {
            if(placementId.equalsIgnoreCase(UNITYADS_PLACEMENTID)){
                Log.d(TAG, "UnityAds onPlacementContentStateChange : " + previousState.name() + ", " + newState.name());
                if(newState == UnityMonetization.PlacementContentState.NOT_AVAILABLE
                        || newState == UnityMonetization.PlacementContentState.NO_FILL){
                    // UnityAds Reward Video 광고가 없는 경우 다음 미디에이션 광고 노출 시도
                    internalLoadRewardVideoAd();
                }
            }
        }

        @Override
        public void onUnityServicesError(UnityServices.UnityServicesError unityServicesError, String s) {
            Log.d(TAG, "UnityAds onUnityServicesError : " + unityServicesError);
            // UnityAds Reward Video 광고가 없는 경우 다음 미디에이션 광고 노출 시도
            internalLoadRewardVideoAd();
        }
    };

    IShowAdListener unityShowListener = new IShowAdListener() {
        @Override
        public void onAdFinished(String placementId, UnityAds.FinishState finishState) {
            Log.d(TAG, "UnityAds onAdFinished : " + finishState);
            if (finishState == UnityAds.FinishState.COMPLETED) {
                if (placementId.equals (UNITYADS_PLACEMENTID)) {
                    if(hmRewardVideoEventListener != null)
                        hmRewardVideoEventListener.OnUnityAdsVideoCompleted();
                }
            }
        }

        @Override
        public void onAdStarted(String s) {
            Log.d(TAG, "UnityAds onAdStarted");
            isReadyRewardVideoAd = false;
            if(hmRewardVideoEventListener != null)
                hmRewardVideoEventListener.OnRewardVideoShowSuccess();
        }
    };
}
