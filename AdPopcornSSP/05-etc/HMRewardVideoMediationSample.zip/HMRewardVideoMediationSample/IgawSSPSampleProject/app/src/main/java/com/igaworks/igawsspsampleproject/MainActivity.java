package com.igaworks.igawsspsampleproject;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.igaworks.ssp.IgawSSP;

public class MainActivity extends Activity {
    private HMRewardVideoMediation igawMediationRewardVideo, oneButtonMediationRewardVideo;
    private boolean completeloadAndShow = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // IgawSSP SDK 초기화
        IgawSSP.init(MainActivity.this);

        // Mediation Reward Video Instance 생성.
        igawMediationRewardVideo = new HMRewardVideoMediation(this, mediationListener);

        Button button_reward_video_load = (Button) findViewById(R.id.button_reward_video_load);
        button_reward_video_load.setOnClickListener(loadButtonClickListener);

        Button button_reward_video_show = (Button) findViewById(R.id.button_reward_video_show);
        button_reward_video_show.setOnClickListener(showButtonClickListener);

        // 원버튼

        // Mediation Reward Video Instance 생성.
        oneButtonMediationRewardVideo = new HMRewardVideoMediation(this, oneBtnMediationListener);

        Button one_button_load_show = (Button) findViewById(R.id.button_reward_video_load_show);
        one_button_load_show.setOnClickListener(oneButtonClickListener);

    }

    View.OnClickListener oneButtonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            // Mediation Reward Video 광고 로드
            completeloadAndShow = false;
            oneButtonMediationRewardVideo.loadRewardVideoAd();
        }
    };

    View.OnClickListener loadButtonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            // Mediation Reward Video 광고 로드
            igawMediationRewardVideo.loadRewardVideoAd();
        }
    };

    View.OnClickListener showButtonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            // Mediation Reward Video 광고 노출
            if(igawMediationRewardVideo.isReady())
                igawMediationRewardVideo.showRewardVideoAd();
        }
    };

    HMRewardVideoMediation.HMRewardVideoEventListener mediationListener = new HMRewardVideoMediation.HMRewardVideoEventListener() {
        @Override
        public void OnRewardVideoAdLoaded() {
            // 광고 로드 성공
            Toast.makeText(MainActivity.this, "OnRewardVideoAdLoaded", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdLoaded");
        }

        @Override
        public void OnRewardVideoAdLoadFailed() {
            // 광고 로드 실패
            Toast.makeText(MainActivity.this, "OnRewardVideoAdLoadFailed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdLoadFailed");
        }

        @Override
        public void OnRewardVideoAdClosed() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed");
        }

        @Override
        public void OnRewardVideoShowSuccess() {
            Toast.makeText(MainActivity.this, "OnRewardVideoShowSuccess", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoShowSuccess");
        }

        @Override
        public void OnRewardVideoShowFailed() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed");
        }

        @Override
        public void OnAdPopcornSSPVideoCompleted(long quantity) {
            Toast.makeText(MainActivity.this, "OnAdPopcornSSPVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnAdPopcornSSPVideoCompleted");
            onCompletedRewardVideoAd();
        }

        @Override
        public void OnMintegralVideoCompleted(float RewardAmout) {
            Toast.makeText(MainActivity.this, "OnMintegralVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnMintegralVideoCompleted");
            onCompletedRewardVideoAd();
        }

        @Override
        public void OnUnityAdsVideoCompleted() {
            Toast.makeText(MainActivity.this, "OnUnityAdsVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnUnityAdsVideoCompleted");
            onCompletedRewardVideoAd();
        }
    };

    HMRewardVideoMediation.HMRewardVideoEventListener oneBtnMediationListener = new HMRewardVideoMediation.HMRewardVideoEventListener() {
        @Override
        public void OnRewardVideoAdLoaded() {
            // 광고 로드 성공
            Toast.makeText(MainActivity.this, "OneButton OnRewardVideoAdLoaded", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OneButton OnRewardVideoAdLoaded");
            if(oneButtonMediationRewardVideo.isReady() && !completeloadAndShow)
                oneButtonMediationRewardVideo.showRewardVideoAd();
        }

        @Override
        public void OnRewardVideoAdLoadFailed() {
            // 광고 로드 실패
            Toast.makeText(MainActivity.this, "OneButton OnRewardVideoAdLoadFailed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OneButton OnRewardVideoAdLoadFailed");
        }

        @Override
        public void OnRewardVideoAdClosed() {
            Toast.makeText(MainActivity.this, "OneButton OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OneButton OnRewardVideoAdClosed");
            completeloadAndShow = true;
        }

        @Override
        public void OnRewardVideoShowSuccess() {
            Toast.makeText(MainActivity.this, "OneButton OnRewardVideoShowSuccess", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OneButton OnRewardVideoShowSuccess");
            completeloadAndShow = true;
        }

        @Override
        public void OnRewardVideoShowFailed() {
            Toast.makeText(MainActivity.this, "OneButton OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OneButton OnRewardVideoAdClosed");
            completeloadAndShow = true;
        }

        @Override
        public void OnAdPopcornSSPVideoCompleted(long quantity) {
            completeloadAndShow = true;
            Toast.makeText(MainActivity.this, "OneButton OnAdPopcornSSPVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OneButton OnAdPopcornSSPVideoCompleted");
            onCompletedRewardVideoAd();
        }

        @Override
        public void OnMintegralVideoCompleted(float RewardAmout) {
            completeloadAndShow = true;
            Toast.makeText(MainActivity.this, "OneButton OnMintegralVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OneButton OnMintegralVideoCompleted");
            onCompletedRewardVideoAd();
        }

        @Override
        public void OnUnityAdsVideoCompleted() {
            completeloadAndShow = true;
            Toast.makeText(MainActivity.this, "OneButton OnUnityAdsVideoCompleted", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OneButton OnUnityAdsVideoCompleted");
            onCompletedRewardVideoAd();
        }
    };

    private void onCompletedRewardVideoAd(){
        // 리워드 비디오가 정상적으로 종료 되었을 때 처리.
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Mediation Reward Video 광고 제거.
        igawMediationRewardVideo.destroy();
        IgawSSP.destroy();
    }
}


