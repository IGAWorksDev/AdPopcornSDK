//
//  RNAdPopcornNativeAdView.m
//  AdPopcornSSPReactPlugin
//
//  Created by 김민석 on 2023/11/22.
//

#import <Foundation/Foundation.h>
#import "RNAdPopcornNativeAdView.h"

@implementation RNAdPopcornNativeAdView

- (void)setAppKey:(NSString *)appKey
{
  NSLog(@"setAppKey : %@", appKey);
  _appKey = appKey;
  [self loadAd];
}

- (void)setPlacementId:(NSString *)placementId
{
  NSLog(@"setPlacementId : %@", placementId);
  _placementId = placementId;
  [self loadAd];
}

- (void)loadAd
{
  if (_appKey == nil || _placementId == nil) {
      return;
  }
  
  if (_reactNativeAdView) {
    [_reactNativeAdView removeFromSuperview];
    _reactNativeAdView = nil;
  }
  
  _reactNativeAdView = [[AdPopcornSSPReactNativeAd alloc] initWithFrame:CGRectMake(0, 0, 393, 98) appKey:_appKey placementId:_placementId viewController:RCTPresentedViewController()];
  [self addSubview:_reactNativeAdView];
  
  _reactNativeAdView.delegate = self;
  [_reactNativeAdView loadRequest];
}

- (void)addAlignCenterConstraint:(CGSize)size
{
  CGFloat width = size.width, height = size.height;
  // add constraints
  if(self.constraints)
  {
      [self removeConstraints:self.constraints];
  }
  [_reactNativeAdView setTranslatesAutoresizingMaskIntoConstraints:NO];
  
  UIView *superview = self;
  [superview addConstraint: [NSLayoutConstraint constraintWithItem:_reactNativeAdView attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:superview attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
  
  [superview addConstraint: [NSLayoutConstraint constraintWithItem:_reactNativeAdView attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:superview attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
  
  [superview addConstraint:[NSLayoutConstraint constraintWithItem:_reactNativeAdView attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:superview attribute:NSLayoutAttributeWidth multiplier:0.0 constant:width]];
  
  [superview addConstraint:[NSLayoutConstraint constraintWithItem:_reactNativeAdView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:superview attribute:NSLayoutAttributeHeight multiplier:0.0 constant:height]];
}

# pragma mark APSSPReactNativeAdDelegate
- (void)APSSPReactNativeAdLoadSuccess:(AdPopcornSSPReactNativeAd *)reactNativeAd adSize:(CGSize)adSize networkNo:(NSInteger)networkNo
{
  NSLog(@"APSSPReactNativeAdLoadSuccess : %f, %f", adSize.width, adSize.height);
  
  _reactNativeAdView.frame = CGRectMake(0, 0, adSize.width, adSize.height);
  [self addAlignCenterConstraint:adSize];
  
  if (_onNativeAdLoadSuccess) {
    _onNativeAdLoadSuccess(@{@"placementId":_placementId});
  }
}

- (void)APSSPReactNativeAdLoadFail:(AdPopcornSSPReactNativeAd *)reactNativeAd error:(AdPopcornSSPError *)error
{
  NSLog(@"APSSPReactNativeAdLoadFail : %@, error : %@", reactNativeAd, error);
  if (_onNativeAdLoadFailed) {
    (_onNativeAdLoadFailed)(@{
      @"errorCode": @(error.code),
      @"errorMessage": error.userInfo.description,
      @"placementId": _placementId
    });
  }
}

- (void)APSSPReactNativeAdImpression:(AdPopcornSSPReactNativeAd *)reactNativeAd
{
  NSLog(@"APSSPBannerViewLoadSuccess : %@", reactNativeAd);
  if (_onNativeImpression) {
    _onNativeImpression(@{@"placementId":_placementId});
  }
}
- (void)APSSPReactNativeAdClicked:(AdPopcornSSPReactNativeAd *)reactNativeAd
{
  NSLog(@"APSSPReactNativeAdClicked : %@", reactNativeAd);
  if (_onNativeClicked) {
    (_onNativeClicked)(@{@"placementId":_placementId});
  }
  [self loadAd];
}

- (void)APSSPReactNativeAdSizeChanged:(AdPopcornSSPReactNativeAd *)reactNativeAd adSize:(CGSize)adSize
{
  NSLog(@"APSSPReactNativeAdSizeChanged : %f, %f", adSize.width, adSize.height);
  _reactNativeAdView.frame = CGRectMake(0, 0, adSize.width, adSize.height);
  [self addAlignCenterConstraint:adSize];
}
@end
