//
//  RNAdPopcornNativeAdView.h
//  AdPopcornSSPReactPlugin
//
//  Created by 김민석 on 2023/11/22.
//

#import <React/RCTViewManager.h>
#import <React/RCTUIManager.h>
#import <React/RCTLog.h>
#import <AdPopcornSSP/AdPopcornSSPReactNativeAd.h>

@class RCTEventDispatcher;

@interface RNAdPopcornNativeAdView : UIView <APSSPReactNativeAdDelegate>

@property AdPopcornSSPReactNativeAd *reactNativeAdView;

@property (nonatomic, copy) NSString *appKey;
@property (nonatomic, copy) NSString *placementId;
@property (nonatomic, copy) RCTDirectEventBlock onNativeAdLoadSuccess;
@property (nonatomic, copy) RCTDirectEventBlock onNativeAdLoadFailed;
@property (nonatomic, copy) RCTDirectEventBlock onNativeImpression;
@property (nonatomic, copy) RCTDirectEventBlock onNativeClicked;
@end
