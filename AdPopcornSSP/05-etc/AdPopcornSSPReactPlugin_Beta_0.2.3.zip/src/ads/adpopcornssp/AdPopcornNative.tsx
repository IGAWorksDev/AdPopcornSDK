import React from 'react';
import { requireNativeComponent, HostComponent, ViewStyle, NativeSyntheticEvent } from 'react-native';

interface NativeProps {
  appKey: string;
  placementId: string;
  onNativeAdLoadSuccess: PropTypes.func;
  onNativeAdLoadFailed: PropTypes.func;
  onNativeImpression: PropTypes.func;
  onNativeClicked: PropTypes.func;
}

interface AdPopcornProps extends NativeProps {
  style: ViewStyle;
}

const RNAdPopcornNativeAdView: HostComponent<AdPopcornProps> = requireNativeComponent('RNAdPopcornNativeAdView');

class AdPopcornNative extends React.Component<Props> {
      constructor(props: Props) {
        super(props);
      }

    _onNativeAdLoadSuccess = (event) => {
        console.log('onNativeAdLoadSuccess', event.nativeEvent);
        const { onNativeAdLoadSuccess } = this.props;
        onNativeAdLoadSuccess && onNativeAdLoadSuccess(event.nativeEvent);
    };
    _onNativeAdLoadFailed = (event) => {
        console.log('onNativeAdLoadFailed', event.nativeEvent);
        const { onNativeAdLoadFailed } = this.props;
        onNativeAdLoadFailed && onNativeAdLoadFailed(event.nativeEvent);
    };
    _onNativeImpression = (event) => {
        console.log('onNativeImpression', event.nativeEvent);
        const { onNativeImpression } = this.props;
        onNativeImpression && onNativeImpression(event.nativeEvent);
    };
    _onNativeClicked = (event) => {
            console.log('onNativeClicked', event.nativeEvent);
            const { onNativeClicked } = this.props;
            onNativeClicked && onNativeClicked(event.nativeEvent);
    };
      render() {
        const {
          appKey,
          placementId
        } = this.props;

        return (
          <RNAdPopcornNativeAdView
                style={{ width: '100%', height:80}}
                appKey={appKey}
                placementId={placementId}
                onNativeAdLoadSuccess={this._onNativeAdLoadSuccess}
                onNativeAdLoadFailed={this._onNativeAdLoadFailed}
                onNativeImpression={this._onNativeImpression}
                onNativeClicked={this._onNativeClicked}
          />
        );
      }
}


export default AdPopcornNative;