//
//  HMRewardVideoMediation.m
//  AdPopcornTestApp
//
//  Created by 김민석 on 2019. 1. 14..
//  Copyright © 2019년 igaworks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HMRewardVideoMediation.h"

NSString *const IGAW = @"IGAW";
NSString *const MINTEGRAL = @"MINTEGRAL";
NSString *const UNITY_ADS = @"UNITY_ADS";

@interface HMRewardVideoMediation () <AdPopcornSSPRewardVideoAdDelegate, MTGRewardAdLoadDelegate, MTGRewardAdShowDelegate, UnityMonetizationDelegate, UMONShowAdDelegate>
{
    NSString *_adPopcornAppKey;
    NSString *_adPopcornPlacementId;
    NSString *_mintegralAppId;
    NSString *_mintegralAppKey;
    NSString *_mintegralUnitId;
    NSString *_mintegralRewardId;
    
    NSString *_unityAdsPlacementId;
    NSString *_unityAdsGameId;
    BOOL _unityAdsTestMode;
    
    BOOL _isReadyRewardVideoAd;
    NSInteger _currentScheduleIndex;
    NSString *_readyMediationName;
    
    AdPopcornSSPRewardVideoAd *_sspRewardVideoAd;
    UMONShowAdPlacementContent *_unityRewardedVideo;
}

@end

@implementation HMRewardVideoMediation

@synthesize mediationScheduleList = _mediationScheduleList;
@synthesize delegate = _delegate;
@synthesize viewController = _viewController;

- (void)dealloc
{
    NSLog(@"HMRewardVideoMediation dealloc");
    _sspRewardVideoAd = nil;
    _sspRewardVideoAd.delegate = nil;
    
}

- (instancetype)init
{
    self = [super init];
    
    // 반드시 아래의 내용이 맞는지 확인해 주세요.
    _adPopcornAppKey = @"114554353";
    _adPopcornPlacementId = @"oel985g2ypygjff";
    
    _mintegralAppId = @"108971";
    _mintegralAppKey = @"2f23f5c5f0cc24455e0b5a73067c96ff";
    _mintegralUnitId = @"69379";
    _mintegralRewardId = @"1";
    
    _unityAdsPlacementId = @"roulettetv_ios";
    _unityAdsGameId = @"2964974";
    
    // 1. 테스트 종료 후, 반드시 NO 로 변경해 준다.
    _unityAdsTestMode = YES;
    
    // 2. 원하는 순서대로 미디에이션 스케쥴 설정
    _mediationScheduleList = [[NSMutableArray alloc] initWithCapacity:10];
    [_mediationScheduleList addObject:IGAW];
    [_mediationScheduleList addObject:MINTEGRAL];
    [_mediationScheduleList addObject:UNITY_ADS];
    
    _isReadyRewardVideoAd = NO;
    _currentScheduleIndex = 0;
    _readyMediationName = @"";
    return self;
}

#pragma mark - public
- (void)loadAd
{
    NSLog(@"loadAd mediation reward video");
    if(_isReadyRewardVideoAd)
    {
        if ([_delegate respondsToSelector:@selector(OnRewardVideoAdLoaded)])
        {
            [_delegate OnRewardVideoAdLoaded];
        }
        return;
    }
    _currentScheduleIndex = 0;
    _readyMediationName = @"";
    [self internalLoadRewardVideoAd];
}

- (BOOL)isReady
{
    return _isReadyRewardVideoAd;
}

- (void)showAd:(UIViewController *)viewController
{
    _viewController = viewController;
    NSLog(@"showAd mediation reward video");
    if(_isReadyRewardVideoAd)
    {
        if([_readyMediationName isEqualToString:IGAW])
        {
            [_sspRewardVideoAd presentFromViewController:_viewController];
            // IGAW 의 Show success, fail event 처리는 AdPopcornSSPRewardVideoAdDelegate 이용.
            return;
        }
        else if([_readyMediationName isEqualToString:MINTEGRAL])
        {
            if ([[MTGRewardAdManager sharedInstance] isVideoReadyToPlay:_mintegralUnitId]) {
                [[MTGRewardAdManager sharedInstance] showVideo:_mintegralUnitId withRewardId:_mintegralRewardId userId:@"" delegate:self viewController:_viewController];
                // Mintegral의 Show success, fail event 처리는 MTGRewardAdShowDelegate 이용.
                return;
            }
        }
        else if([_readyMediationName isEqualToString:UNITY_ADS])
        {
            if([UnityMonetization isReady:_unityAdsPlacementId])
            {
                if([_unityRewardedVideo isReady])
                {
                    [_unityRewardedVideo show:_viewController withDelegate:self];
                    if ([_delegate respondsToSelector:@selector(OnRewardVideoShowSuccess)])
                    {
                        [_delegate OnRewardVideoShowSuccess];
                    }
                    return;
                }
            }
        }
    }
    if ([_delegate respondsToSelector:@selector(OnRewardVideoShowFailed)])
    {
        [_delegate OnRewardVideoShowFailed];
    }
}

- (void)internalLoadRewardVideoAd
{
    if(_currentScheduleIndex >= _mediationScheduleList.count)
    {
        if ([_delegate respondsToSelector:@selector(OnRewardVideoAdLoadFailed)])
        {
            [_delegate OnRewardVideoAdLoadFailed];
        }
        return;
    }
    NSString *_mediationName = [_mediationScheduleList objectAtIndex:_currentScheduleIndex];
    if([_mediationName isEqualToString:IGAW])
    {
        if(_sspRewardVideoAd == nil)
        {
            _sspRewardVideoAd = [[AdPopcornSSPRewardVideoAd alloc] initWithKey:_adPopcornAppKey placementId:_adPopcornPlacementId viewController:_viewController];
            _sspRewardVideoAd.delegate = self;
        }
        [_sspRewardVideoAd loadRequest];
    }
    else if([_mediationName isEqualToString:MINTEGRAL])
    {
        [[MTGRewardAdManager sharedInstance] loadVideo:_mintegralUnitId delegate:self];
    }
    else if([_mediationName isEqualToString:UNITY_ADS])
    {
        if([UnityMonetization isReady:_unityAdsPlacementId])
        {
            _readyMediationName = UNITY_ADS;
            _isReadyRewardVideoAd = YES;
            if ([_delegate respondsToSelector:@selector(OnRewardVideoAdLoaded)])
            {
                [_delegate OnRewardVideoAdLoaded];
            }
        }
        else
        {
            if(_unityAdsTestMode)
            {
                [UnityMonetization initialize:_unityAdsGameId delegate:self testMode:YES];
            }
            else
            {
                [UnityMonetization initialize:_unityAdsGameId delegate:self];
            }
        }
    }
    _currentScheduleIndex++;
}

#pragma AdPopcornSSPRewardVideoAdDelegate
/*!
 @abstract
 video 광고 로드에 성공한 경우 호출된다.
 */
- (void)AdPopcornSSPLoadRewardVideoAdSuccess
{
    _readyMediationName = IGAW;
    _isReadyRewardVideoAd = YES;
    if ([_delegate respondsToSelector:@selector(OnRewardVideoAdLoaded)])
    {
        [_delegate OnRewardVideoAdLoaded];
    }
}

/*!
 @abstract
 video 광고 로드에 실패한 경우 호출된다.
 */
- (void)AdPopcornSSPLoadRewardVideoAdFailedWithError:(AdPopcornSSPError *)error
{
    [self internalLoadRewardVideoAd];
}

/*!
 @abstract
 video 광고가 열리기 전에 호출된다.
 */
- (void)AdPopcornSSPShowRewardVideoAdSuccess
{
    _isReadyRewardVideoAd = NO;
    if ([_delegate respondsToSelector:@selector(OnRewardVideoShowSuccess)])
    {
        [_delegate OnRewardVideoShowSuccess];
    }
}

/*!
 @abstract
 video 광고가 열린직 후 호출된다.
 */
- (void)AdPopcornSSPShowRewardVideoAdFailed
{
    _isReadyRewardVideoAd = NO;
    if ([_delegate respondsToSelector:@selector(OnRewardVideoShowFailed)])
    {
        [_delegate OnRewardVideoShowFailed];
    }
}

/*!
 @abstract
 video 광고가 닫히기 전에 호출된다.
 */
- (void)AdPopcornSSPRewardVideoAdClosed
{
    _isReadyRewardVideoAd = NO;
    if ([_delegate respondsToSelector:@selector(OnRewardVideoAdClose)])
    {
        [_delegate OnRewardVideoAdClose];
    }
}

/*!
 @abstract
 reward video 재생 완료 시 호출된다.
 */
- (void)AdPopcornSSPRewardVideoAdPlayCompletedWithQuantity:(long) quantity Currency:(NSString *)currency
{
    if ([_delegate respondsToSelector:@selector(OnAdPopcornSSPVideoCompleted:)])
    {
        [_delegate OnAdPopcornSSPVideoCompleted:quantity];
    }
}

#pragma MTGRewardAdLoadDelegate
/**
 *  Called when the ad is loaded , but is ready to be displayed
 completely
 *  @param unitId - the unitId string of the Ad that was loaded.
 */
- (void)onVideoAdLoadSuccess:(nullable NSString *)unitId
{
    _readyMediationName = MINTEGRAL;
    _isReadyRewardVideoAd = YES;
    if ([_delegate respondsToSelector:@selector(OnRewardVideoAdLoaded)])
    {
        [_delegate OnRewardVideoAdLoaded];
    }
}

/**
 *  Called when the ad is loaded failure
 completely
 */
- (void)onVideoAdLoadFailed:(nullable NSString *)unitId error:(nonnull NSError *)error
{
    // Mintegral 광고가 없는 경우 다음 미디에이션 광고 노출 시도
    [self internalLoadRewardVideoAd];
}

#pragma MTGRewardAdShowDelegate

/**
 *  Called when the ad display success
 *
 *  @param unitId - the unitId string of the Ad that display success.
 */
- (void)onVideoAdShowSuccess:(nullable NSString *)unitId
{
    _isReadyRewardVideoAd = NO;
    if ([_delegate respondsToSelector:@selector(OnRewardVideoShowSuccess)])
    {
        [_delegate OnRewardVideoShowSuccess];
    }
}

/**
 *  Called when the ad display is successful
 *
 *  @param unitId - the unitId string of the Ad that displayed successfully.
 */

- (void)onVideoAdShowFailed:(nullable NSString *)unitId withError:(nonnull NSError *)error
{
    _isReadyRewardVideoAd = NO;
    if ([_delegate respondsToSelector:@selector(OnRewardVideoShowFailed)])
    {
        [_delegate OnRewardVideoShowFailed];
    }
}

/**
 *  Called when the ad is clicked
 *
 *  @param unitId - the unitId string of the Ad clicked.
 */
- (void)onVideoAdClicked:(nullable NSString *)unitId
{
    
}

/**
 *  Called when the ad has been dismissed from being displayed, and control will return to your app
 *
 *  @param unitId      - the unitId string of the Ad that has been dismissed
 *  @param converted   - BOOL describing whether the ad has converted
 *  @param rewardInfo  - the rewardInfo object containing the info that should be given to your user.
 */
- (void)onVideoAdDismissed:(nullable NSString *)unitId withConverted:(BOOL)converted withRewardInfo:(nullable MTGRewardAdInfo *)rewardInfo
{
    if ([_delegate respondsToSelector:@selector(OnRewardVideoAdClose)])
    {
        [_delegate OnRewardVideoAdClose];
    }
    if(converted)
    {
        if ([_delegate respondsToSelector:@selector(OnMintegralVideoCompleted:)])
        {
            [_delegate OnMintegralVideoCompleted:rewardInfo.rewardAmount];
        }
    }
    if ([[MTGRewardAdManager sharedInstance] isVideoReadyToPlay:_mintegralUnitId])
    {
        _readyMediationName = MINTEGRAL;
        _isReadyRewardVideoAd = YES;
        if ([_delegate respondsToSelector:@selector(OnRewardVideoAdLoaded)])
        {
            [_delegate OnRewardVideoAdLoaded];
        }
    }
}

#pragma UnityMonetizationDelegate
-(void)placementContentReady:(NSString *)placementId placementContent:(UMONPlacementContent *)placementContent
{
    if([placementId isEqualToString:_unityAdsPlacementId]){
        _readyMediationName = UNITY_ADS;
        _isReadyRewardVideoAd = YES;
        if ([_delegate respondsToSelector:@selector(OnRewardVideoAdLoaded)])
        {
            [_delegate OnRewardVideoAdLoaded];
        }
        _unityRewardedVideo = placementContent;
    }
}

-(void)placementContentStateDidChange:(NSString *)placementId placementContent:(UMONPlacementContent *)placementContent previousState:(UnityMonetizationPlacementContentState)previousState newState:(UnityMonetizationPlacementContentState)newState
{
    if(newState == kPlacementContentStateNoFill || newState == kPlacementContentStateNotAvailable)
    {
        [self internalLoadRewardVideoAd];
    }
}

#pragma UMONShowAdDelegate
-(void)unityAdsDidStart:(NSString*)placementId
{
    _isReadyRewardVideoAd = NO;
}

-(void)unityAdsDidFinish:(NSString*)placementId withFinishState:(UnityAdsFinishState)finishState
{
    // If the ad played in its entirety, and the Placement is rewarded, perform reward logic:
    if (finishState == kUnityAdsFinishStateCompleted
        && [placementId isEqualToString:_unityAdsPlacementId]) {
        // Reward player for watching the entire video
        if ([_delegate respondsToSelector:@selector(OnUnityAdsVideoComplete)])
        {
            [_delegate OnUnityAdsVideoComplete];
        }
    }
}
@end
