//
//  HMRewardVideoMediation.h
//  AdPopcornTestApp
//
//  Created by 김민석 on 2019. 1. 14..
//  Copyright © 2019년 igaworks. All rights reserved.
//

#import <AdPopcornSSP/AdPopcornSSPRewardVideoAd.h>
#import <UIKit/UIKit.h>
#import <MTGSDK/MTGSDK.h>
#import <MTGSDKReward/MTGRewardAdManager.h>
#import <UnityAds/UnityMonetization.h>


@protocol HMRewardVideoMediationDelegate;

extern NSString *const IGAW;
extern NSString *const MINTEGRAL;
extern NSString *const UNITY_ADS;

@interface HMRewardVideoMediation : NSObject

@property (nonatomic, strong) NSMutableArray *mediationScheduleList;
@property (nonatomic, weak) id<HMRewardVideoMediationDelegate> delegate;
@property (nonatomic, weak) UIViewController *viewController;

/*!
 @abstract
 mediation reward video ad instance 생성.
 */
- (instancetype)init NS_DESIGNATED_INITIALIZER;

/*!
 @abstract
 reward video ad 광고 요청.
 */
- (void)loadAd;

/*!
 @abstract
 reward video ad load가 완료되면(성공하면), showAd 메소드를 호출하여 노출시킨다.
 @param viewController  reward video ad를 노출시킬 view controller
 */
- (void)showAd:(UIViewController *)viewController;

/*!
 @abstract
 reward video ad 로드 여부 확인.
 */
- (BOOL)isReady;

@end

@protocol HMRewardVideoMediationDelegate <NSObject>

- (void) OnRewardVideoAdLoaded;
- (void) OnRewardVideoAdLoadFailed;
- (void) OnRewardVideoShowSuccess;
- (void) OnRewardVideoShowFailed;
- (void) OnRewardVideoAdClose;
- (void) OnAdPopcornSSPVideoCompleted:(long) quantity;
- (void) OnMintegralVideoCompleted:(NSInteger) RewardAmount;
- (void) OnUnityAdsVideoComplete;

@end


