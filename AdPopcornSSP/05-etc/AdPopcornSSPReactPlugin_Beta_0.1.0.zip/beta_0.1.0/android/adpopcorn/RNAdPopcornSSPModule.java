package com.adpopcornsspreactplugin.adpopcorn;

import android.content.Context;
import android.util.Log;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.igaworks.ssp.AdPopcornSSP;
import com.igaworks.ssp.SdkInitListener;

public class RNAdPopcornSSPModule extends ReactContextBaseJavaModule {

    public RNAdPopcornSSPModule(ReactApplicationContext context) {
        super(context);
    }

    @Override
    public String getName(){
        return "RNAdPopcornSSPModule";
    }

    @ReactMethod
    public void init() {
        Log.d("RNAdPopcornSSPModule", "init");
        ReactApplicationContext context = getReactApplicationContext();
        AdPopcornSSP.init((Context) context, new SdkInitListener() {
            @Override
            public void onInitializationFinished() {

            }
        });
    }
}