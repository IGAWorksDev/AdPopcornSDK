import React from 'react';
import { requireNativeComponent, HostComponent, ViewStyle } from 'react-native';

interface BannerProps {
  placementId: string;
  adSize: '320x50' | '320x100' | '320x250';
  viewWidth?: number;
  viewHeight?: number;
  refreshTime?: number;
  networkScheduleTimeout?: number;
  bannerAnimType?: 'FADE_IN' | 'SLIDE_LEFT' | 'SLIDE_RIGHT' | 'TOP_SLIDE' | 'BOTTOM_SLIDE' | 'CIRCLE' | 'NONE';
  autoBgColor?: boolean;
}

interface AdPopcornProps extends BannerProps {
  style: ViewStyle;
}

const RNAdPopcornBannerView: HostComponent<AdPopcornProps> = requireNativeComponent('RNAdPopcornBannerView');

class AdPopcornBanner extends React.Component<Props> {
      constructor(props: Props) {
        super(props);
      }

      render() {
        const {
          placementId,
          adSize,
          viewWidth = 0,
          viewHeight = 0,
          refreshTime = 30,
          networkScheduleTimeout = 10,
          bannerAnimType = 'NONE',
          autoBgColor = false
        } = this.props;

        const height = adSize === '320x50' ? 50 : adSize === '320x100' ? 100 : 250;

        return (
          <RNAdPopcornBannerView
            style={{ width: '100%', height }}
            placementId={placementId}
            adSize={adSize}
            viewWidth={viewWidth}
            viewHeight={viewHeight}
            refreshTime={refreshTime}
            networkScheduleTimeout={networkScheduleTimeout}
            bannerAnimType={bannerAnimType}
            autoBgColor={autoBgColor}
          />
        );
      }
}


export default AdPopcornBanner;