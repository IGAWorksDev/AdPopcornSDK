//
//  AdPopcornSSPIMAAdapter.h
//  IgaworksDevApp
//
//  Created by 김민석 on 2018. 7. 3..
//  Copyright © 2018년 mick. All rights reserved.
//

// Using pod install / unity
//#import <AdPopcornSSP/AdPopcornSSPVastAdapter.h>
// else
#import "AdPopcornSSPVastAdapter.h"

@interface AdPopcornSSPIMAAdapter : AdPopcornSSPVastAdapter
{
}

@end
