//
//  FANAdapter.h
//  AdPopcornSSP
//
//  Created by mick on 2017. 8. 2..
//  Copyright (c) 2017년 igaworks All rights reserved.
//

#import <FBAudienceNetwork/FBAudienceNetwork.h>

// Using pod install / unity
//#import <AdPopcornSSP/AdPopcornSSPAdapter.h>
// else
#import "AdPopcornSSPAdapter.h"

@interface FANAdapter : AdPopcornSSPAdapter
{
    FBAdView *_adView;
    FBInterstitialAd *_interstitialAd;
    FBNativeAd *_nativeAd;
}
@end
