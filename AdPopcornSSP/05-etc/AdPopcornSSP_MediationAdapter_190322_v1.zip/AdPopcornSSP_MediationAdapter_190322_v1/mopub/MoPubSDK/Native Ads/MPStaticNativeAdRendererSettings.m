//
//  MPStaticNativeAdRendererSettings.m
//  MoPubSDK
//
//  Copyright (c) 2015 MoPub. All rights reserved.
//

#import "MPStaticNativeAdRendererSettings.h"

@implementation MPStaticNativeAdRendererSettings

@end
