//
//  AppNextAdapter.m
//  AdPopcornSSP
//
//  Created by mick on 2019. 3. 19..
//  Copyright (c) 2019년 igaworks All rights reserved.
//

#import "AppNextAdapter.h"

static inline NSString *SSPErrorString(SSPErrorCode code)
{
    switch (code)
    {
        case AdPopcornSSPException:
            return @"Exception";
        case AdPopcornSSPInvalidParameter:
            return @"Invalid Parameter";
        case AdPopcornSSPUnknownServerError:
            return @"Unknown Server Error";
        case AdPopcornSSPInvalidMediaKey:
            return @"Invalid Media key";
        case AdPopcornSSPInvalidPlacementId:
            return @"Invalid Placement Id";
        case AdPopcornSSPInvalidNativeAssetsConfig:
            return @"Invalid native assets config";
        case AdPopcornSSPNativePlacementDoesNotInitialized:
            return @"Native Placement Does Not Initialized";
        case AdPopcornSSPServerTimeout:
            return @"Server Timeout";
        case AdPopcornSSPLoadAdFailed:
            return @"Load Ad Failed";
        case AdPopcornSSPNoAd:
            return @"No Ad";
        case AdPopcornSSPNoInterstitialLoaded:
            return @"No Interstitial Loaded";
        case AdPopcornSSPNoRewardVideoAdLoaded:
            return @"No Reward video ad Loaded";
        case AdPopcornSSPMediationAdapterNotInitialized:
            return @"Mediation Adapter Not Initialized";
        default: {
            return @"Success";
        }
    }
}

@interface AppNextAdapter () <AppnextAdDelegate>
{
    BOOL _isCurrentRunningAdapter;
}

@end

@implementation AppNextAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;
@synthesize viewController = _viewController;
@synthesize bannerView = _bannerView;

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}

- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(AdPopcornSSPBannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = SSPAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPAdInterstitialType;
}

- (void)setRewardVideoViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPRewardVideoAdType;
}

- (BOOL)isSupportInterstitialAd
{
    return NO;
}

- (BOOL)isSupportRewardVideoAd
{
    return YES;
}

- (void)loadAd
{
    NSLog(@"AppNextAdapter %@ : loadAd", self);
    if (_adType == SSPRewardVideoAdType)
    {
        _isCurrentRunningAdapter = YES;
        _isLoadMode = YES;
        if (_integrationKey != nil)
        {
            NSString *placementId = [_integrationKey valueForKey:@"placementId"];
            if(_rewarded == nil)
                _rewarded = [[AppnextRewardedVideoAd alloc] initWithPlacementID:placementId];
            _rewarded.delegate = self;
            if(![_rewarded adIsLoaded])
            {
                NSLog(@"AppNextAdapter call loadAd");
                [_rewarded loadAd];
            }
            else
            {
                NSLog(@"AppNextAdapter already ready");
                if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadSuccess)])
                {
                    [_delegate AdPopcornSSPAdapterRewardVideoAdLoadSuccess];
                }
            }
                
        }
        else
        {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
        }
    }
}

- (void)showAd
{
    NSLog(@"AppNextAdapter %@ : showAd", self);
    if (_adType == SSPRewardVideoAdType)
    {
        _isLoadMode = NO;
        if (_rewarded.adIsLoaded)
        {
            [_rewarded showAd];
        }
        else
        {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoRewardVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoRewardVideoAdLoaded)}] adapter:self];
            }
        }
    }
}

- (void)closeAd
{
    NSLog(@"AppNextAdapter closeAd");
    _isCurrentRunningAdapter = NO;
}

- (void)loadRequest
{
    // Not used any more
}

#pragma AppnextAdDelegate
- (void) adLoaded:(AppnextAd *)ad
{
    NSLog(@"AppNextAdapter adLoaded");
    if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadSuccess)])
    {
        [_delegate AdPopcornSSPAdapterRewardVideoAdLoadSuccess];
    }
}

- (void) adOpened:(AppnextAd *)ad
{
    NSLog(@"AppNext adOpened");
    if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowSuccess)])
    {
        [_delegate AdPopcornSSPAdapterRewardVideoAdShowSuccess];
    }
}

- (void) adClosed:(AppnextAd *)ad
{
    NSLog(@"AppNextAdapter adClosed");
    
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterOnAppNextAdsVideoCompleted)])
    {
        [_delegate AdPopcornSSPAdapterOnAppNextAdsVideoCompleted];
    }
    
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdClose)])
    {
        [_delegate AdPopcornSSPAdapterRewardVideoAdClose];
    }
    _isCurrentRunningAdapter = NO;
}

- (void) adClicked:(AppnextAd *)ad
{
    NSLog(@"AppNextAdapter adClicked");
}
- (void) adUserWillLeaveApplication:(AppnextAd *)ad
{
    NSLog(@"AppNextAdapter adUserWillLeaveApplication");
}
- (void) adError:(AppnextAd *)ad error:(NSString *)error
{
    NSLog(@"AppNextAdapter adError : %@", error);
    if(_isLoadMode)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
        }
    }
    else
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoRewardVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoRewardVideoAdLoaded)}] adapter:self];
        }
    }
}
@end
