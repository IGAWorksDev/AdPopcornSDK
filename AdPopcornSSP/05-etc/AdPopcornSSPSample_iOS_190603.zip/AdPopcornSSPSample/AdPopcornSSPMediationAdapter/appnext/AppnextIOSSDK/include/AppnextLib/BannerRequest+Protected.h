//
//  BannerRequest+protected.h
//  AppnextLib
//
//  Created by shalom.b on 6/6/18.
//  Copyright © 2018 Appnext. All rights reserved.
//

@interface BannerRequest(Protected)
- (NSNumber *) getClickInAppUserChoose;
@end
