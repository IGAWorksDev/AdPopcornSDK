//
//  UnityAdsAdapter.m
//  AdPopcornSSP
//
//  Created by mick on 2019. 3. 19..
//  Copyright (c) 2019년 igaworks All rights reserved.
//

#import "UnityAdsAdapter.h"

static inline NSString *SSPErrorString(SSPErrorCode code)
{
    switch (code)
    {
        case AdPopcornSSPException:
            return @"Exception";
        case AdPopcornSSPInvalidParameter:
            return @"Invalid Parameter";
        case AdPopcornSSPUnknownServerError:
            return @"Unknown Server Error";
        case AdPopcornSSPInvalidMediaKey:
            return @"Invalid Media key";
        case AdPopcornSSPInvalidPlacementId:
            return @"Invalid Placement Id";
        case AdPopcornSSPInvalidNativeAssetsConfig:
            return @"Invalid native assets config";
        case AdPopcornSSPNativePlacementDoesNotInitialized:
            return @"Native Placement Does Not Initialized";
        case AdPopcornSSPServerTimeout:
            return @"Server Timeout";
        case AdPopcornSSPLoadAdFailed:
            return @"Load Ad Failed";
        case AdPopcornSSPNoAd:
            return @"No Ad";
        case AdPopcornSSPNoInterstitialLoaded:
            return @"No Interstitial Loaded";
        case AdPopcornSSPNoRewardVideoAdLoaded:
            return @"No Reward video ad Loaded";
        case AdPopcornSSPMediationAdapterNotInitialized:
            return @"Mediation Adapter Not Initialized";
        default: {
            return @"Success";
        }
    }
}

@interface UnityAdsAdapter () <UnityMonetizationDelegate, UMONShowAdDelegate>
{
    NSString *_unityAdsPlacementId;
    BOOL _isCurrentRunningAdapter;
}

@end

@implementation UnityAdsAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;
@synthesize viewController = _viewController;
@synthesize bannerView = _bannerView;

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}

- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(AdPopcornSSPBannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = SSPAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPAdInterstitialType;
}

- (void)setRewardVideoViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPRewardVideoAdType;
}

- (BOOL)isSupportInterstitialAd
{
    return NO;
}

- (BOOL)isSupportRewardVideoAd
{
    return YES;
}

- (void)loadAd
{
    NSLog(@"UnityAdsAdapter %@ : loadAd", self);
    if (_adType == SSPRewardVideoAdType)
    {
        _isCurrentRunningAdapter = YES;
        if (_integrationKey != nil)
        {
            NSString *_unityAdsGameId = [_integrationKey valueForKey:@"UnityGameId"];
            _unityAdsPlacementId = [_integrationKey valueForKey:@"UnityPlacementId"];
            [UnityMonetization setDelegate:self];
            
            NSLog(@"[UnityMonetization getPlacementContent:_unityAdsPlacementId].state : %ld", (long)[UnityMonetization getPlacementContent:_unityAdsPlacementId].state);
        
            if([UnityMonetization isReady:_unityAdsPlacementId])
            {
                if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadSuccess)])
                {
                    [_delegate AdPopcornSSPAdapterRewardVideoAdLoadSuccess];
                }
            }
            else if([UnityMonetization getPlacementContent:_unityAdsPlacementId].state ==
                    kPlacementContentStateNoFill){
                if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
                {
                    [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
                }
            }
            else
            {
                [UnityMonetization initialize:_unityAdsGameId delegate:self testMode:NO];
            }
        }
        else
        {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
        }
    }
}

- (void)showAd
{
    NSLog(@"UnityAdsAdapter %@ : showAd", self);
    if (_adType == SSPRewardVideoAdType)
    {
        if([UnityMonetization isReady:_unityAdsPlacementId])
        {
            if(_unityRewardedVideo != nil && [_unityRewardedVideo isReady])
            {
                [_unityRewardedVideo show:_viewController withDelegate:self];
                return;
            }
            else
            {
                if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowFailError:adapter:)])
                {
                    [_delegate AdPopcornSSPAdapterRewardVideoAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoRewardVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoRewardVideoAdLoaded)}] adapter:self];
                }
            }
        }
    }
}

- (void)closeAd
{
    NSLog(@"UnityAdsAdapter closeAd");
    _isCurrentRunningAdapter = NO;
}

- (void)loadRequest
{
    // Not used any more
}

#pragma UnityMonetizationDelegate
-(void)placementContentReady:(NSString *)placementId placementContent:(UMONPlacementContent *)placementContent
{
    if([placementId isEqualToString:_unityAdsPlacementId]){
        NSLog(@"UnityAdsAdapter : placementContentReady");
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadSuccess)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadSuccess];
        }
        _unityRewardedVideo = placementContent;
    }
}

-(void)placementContentStateDidChange:(NSString *)placementId placementContent:(UMONPlacementContent *)placementContent previousState:(UnityMonetizationPlacementContentState)previousState newState:(UnityMonetizationPlacementContentState)newState
{
    if([placementId isEqualToString:_unityAdsPlacementId]){
        NSLog(@"UnityAdapter placementContentStateDidChange : %ld", newState);
        if(newState == kPlacementContentStateNoFill)
        {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
            }
        }
    }
}

#pragma UMONShowAdDelegate
-(void)unityAdsDidStart:(NSString*)placementId
{
    NSLog(@"UnityAdapter unityAdsDidStart : %@", placementId);
    if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowSuccess)])
    {
        [_delegate AdPopcornSSPAdapterRewardVideoAdShowSuccess];
    }
}

-(void)unityAdsDidFinish:(NSString*)placementId withFinishState:(UnityAdsFinishState)finishState
{
    if (finishState == kUnityAdsFinishStateCompleted
        && [placementId isEqualToString:_unityAdsPlacementId]) {
        NSLog(@"UnityAdapter unityAdsDidFinish : %@", _unityAdsPlacementId);
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdClose)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdClose];
        }
        
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterOnUnityAdsVideoCompleted)])
        {
            [_delegate AdPopcornSSPAdapterOnUnityAdsVideoCompleted];
        }
        _isCurrentRunningAdapter = NO;
    }
}
@end
