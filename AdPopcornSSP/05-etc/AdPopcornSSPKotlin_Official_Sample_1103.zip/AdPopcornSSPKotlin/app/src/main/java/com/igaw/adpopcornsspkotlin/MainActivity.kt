package com.igaw.adpopcornsspkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast

import com.igaworks.ssp.AdSize
import com.igaworks.ssp.IgawSSP
import com.igaworks.ssp.SSPErrorCode
import com.igaworks.ssp.part.banner.IgawBannerAd
import com.igaworks.ssp.part.banner.listener.IBannerEventCallbackListener
import com.igaworks.ssp.part.interstitial.InterstitialAd
import com.igaworks.ssp.part.interstitial.listener.IInterstitialEventCallbackListener
import com.igaworks.ssp.part.nativead.IgawNativeAd
import com.igaworks.ssp.part.nativead.binder.AdMobViewBinder
import com.igaworks.ssp.part.nativead.binder.IgawViewBinder
import com.igaworks.ssp.part.nativead.binder.MintegralViewBinder
import com.igaworks.ssp.part.nativead.listener.INativeAdEventCallbackListener
import com.igaworks.ssp.part.video.IgawInterstitialVideoAd
import com.igaworks.ssp.part.video.IgawRewardVideoAd
import com.igaworks.ssp.part.video.listener.IInterstitialVideoAdEventCallbackListener
import com.igaworks.ssp.part.video.listener.IRewardVideoAdEventCallbackListener

class MainActivity : AppCompatActivity() {

    private var igawRewardVideoAd: IgawRewardVideoAd? = null
    private var igawBannerAd_320x50: IgawBannerAd? = null
    private var igawBannerAd_320x100:IgawBannerAd? = null
    private var igawBannerAd_300x250:IgawBannerAd? = null
    private var igawInterstitialAd: InterstitialAd? = null
    //private var igawNativeAd: IgawNativeAd? = null
    private var igawMediationNativeAd:IgawNativeAd? = null
    private var igawInterstitialVideoAd: IgawInterstitialVideoAd? = null

    val IGAW_320x50_BANNER_PLACEMENT_ID = "1z8ozfc8d6ue99e"
    val IGAW_320x100_BANNER_PLACEMENT_ID = "f5w8b647h3roq96"
    val IGAW_300x250_BANNER_PLACEMENT_ID = "ebbkwz53as764h3"
    val IGAW_INTERSTITIAL_AD_PLACEMENT_ID = "5jb921hjk4j2k4b"
    val IGAW_INTERSTITAL_VIDEO_AD_PLACEMENT_ID = "bgm0vw0343rzvxt"
    val IGAW_REWARD_VIDEO_AD_PLACEMENT_ID = "4h774k1f2kaw4xa"
    val IGAW_NATIVE_AD_PLACEMENT_ID = "8n12virz5gmkwqr"

    val LOG_TAG = "AdPopcornSSPSample"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        /* 주의 사항
            샘플에서 사용하고 있는 placement ID 값은 반드시 애드팝콘에서 발급받은 키로 변경하여 사용하여야 합니다.
            기타 자세한 사항 및 최신 SDK는 애드팝콘 SSP 가이드 페이지를 참고해 주시기 바랍니다
        */

        // 1. IgawSSP SDK 초기화
        IgawSSP.init(this@MainActivity)

        // 2. Banner 320x50
        igawBannerAd_320x50 = findViewById(R.id.banner_container)
        igawBannerAd_320x50?.setAdSize(AdSize.BANNER_320x50)
        igawBannerAd_320x50?.placementId = IGAW_320x50_BANNER_PLACEMENT_ID
        igawBannerAd_320x50?.setBannerEventCallbackListener(object : IBannerEventCallbackListener {
            override fun OnBannerAdReceiveSuccess() {
                Log.i(LOG_TAG, "320x50 OnBannerAdReceiveSuccess")
                Toast.makeText(
                    this@MainActivity,
                    "OnBannerAdReceiveSuccess : ${igawBannerAd_320x50?.currentNetwork}",
                    Toast.LENGTH_SHORT
                ).show()
                igawBannerAd_320x50?.visibility = View.VISIBLE
            }

            override fun OnBannerAdReceiveFailed(errorCode: SSPErrorCode) {
                Log.i(LOG_TAG, "320x50 BannerOnBannerAdReceiveFailed : $errorCode.errorMessage")
                Toast.makeText(
                    this@MainActivity,
                    "OnBannerAdReceiveFailed : $errorCode.errorCode,  $errorCode.errorMessage",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })

        val loadBanner1 = findViewById<Button>(R.id.button_banner1_load)
        loadBanner1.setOnClickListener{
            igawBannerAd_320x50?.loadAd()
        }

        val stopBanner1 = findViewById<Button>(R.id.button_banner1_stop)
        stopBanner1.setOnClickListener {
            igawBannerAd_320x50?.stopAd()
        }

        // 3. Banner 320x100
        igawBannerAd_320x100 = findViewById(R.id.banner_container_2)
        igawBannerAd_320x100?.setAdSize(AdSize.BANNER_320x100)
        igawBannerAd_320x100?.placementId = IGAW_320x100_BANNER_PLACEMENT_ID
        igawBannerAd_320x100?.setRefreshTime(50)
        igawBannerAd_320x100?.setNetworkScheduleTimeout(3)
        igawBannerAd_320x100?.setBannerEventCallbackListener(object : IBannerEventCallbackListener {
            override fun OnBannerAdReceiveSuccess() {
                Log.i(LOG_TAG, "320x100 OnBannerAdReceiveSuccess")
                Toast.makeText(
                    this@MainActivity,
                    "OnBannerAdReceiveSuccess : " + igawBannerAd_320x100?.currentNetwork,
                    Toast.LENGTH_SHORT
                ).show()
                igawBannerAd_320x100?.visibility = View.VISIBLE
            }

            override fun OnBannerAdReceiveFailed(errorCode: SSPErrorCode) {
                Log.i(LOG_TAG, "320x100 BannerOnBannerAdReceiveFailed : " + errorCode.errorMessage)
                Toast.makeText(
                    this@MainActivity,
                    "OnBannerAdReceiveFailed : " + errorCode.errorCode + ", " + errorCode.errorMessage,
                    Toast.LENGTH_SHORT
                ).show()
            }
        })

        val loadBanner2 = findViewById<Button>(R.id.button_banner2_load)
        loadBanner2.setOnClickListener{
            igawBannerAd_320x100?.loadAd()

        }

        val stopBanner2 = findViewById<Button>(R.id.button_banner2_stop)
        stopBanner2.setOnClickListener{
            igawBannerAd_320x100?.stopAd()
        }

        // 4. Banner 300x250
        igawBannerAd_300x250 = findViewById(R.id.banner_container_3)
        igawBannerAd_300x250?.setAdSize(AdSize.BANNER_300x250)
        igawBannerAd_300x250?.placementId = IGAW_300x250_BANNER_PLACEMENT_ID
        igawBannerAd_300x250?.setBannerEventCallbackListener(object : IBannerEventCallbackListener{
            override fun OnBannerAdReceiveSuccess() {
                Log.i(LOG_TAG, "300x250 OnBannerAdReceiveSuccess")
                Toast.makeText(
                    this@MainActivity,
                    "OnBannerAdReceiveSuccess : " + igawBannerAd_300x250?.currentNetwork,
                    Toast.LENGTH_SHORT
                ).show()
                igawBannerAd_300x250?.visibility = View.VISIBLE
            }

            override fun OnBannerAdReceiveFailed(errorCode: SSPErrorCode) {
                Log.i(LOG_TAG, "300x250 BannerOnBannerAdReceiveFailed : ${errorCode.errorCode} + errorMessage :  ${errorCode.errorMessage}")
                Toast.makeText(
                    this@MainActivity,
                    "OnBannerAdReceiveFailed : ${errorCode.errorCode} + errorMessage : ${errorCode.errorMessage}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })

        val loadBanner3 = findViewById<Button>(R.id.button_banner3_load)
        loadBanner3.setOnClickListener{
            igawBannerAd_300x250?.loadAd()
        }

        val stopBanner3 = findViewById<Button>(R.id.button_banner3_stop)
        stopBanner3.setOnClickListener{
            igawBannerAd_300x250?.stopAd()
        }

        // 5. interstitialAd
        igawInterstitialAd = InterstitialAd(this@MainActivity)
        igawInterstitialAd?.setPlacementId(IGAW_INTERSTITIAL_AD_PLACEMENT_ID)

        igawInterstitialAd?.setInterstitialEventCallbackListener(object : IInterstitialEventCallbackListener {
            override  fun OnInterstitialLoaded() {
                Log.i(LOG_TAG, "OnInterstitialLoaded")
                Toast.makeText(
                    this@MainActivity,
                    "OnInterstitialLoaded : " + igawInterstitialAd?.currentNetwork,
                    Toast.LENGTH_SHORT
                ).show()
            }

            override fun OnInterstitialOpened() {
                Log.i(LOG_TAG, "OnInterstitialOpened")
                Toast.makeText(this@MainActivity, "OnInterstitialOpened", Toast.LENGTH_SHORT).show()
            }

            override fun OnInterstitialReceiveFailed(errorCode: SSPErrorCode) {
                Log.i(
                    LOG_TAG,
                    "OnInterstitialReceiveFailed : ${errorCode.errorCode} + errorMessage : ${errorCode.errorMessage}"
                )
                Toast.makeText(
                    this@MainActivity,
                    "OnInterstitialReceiveFailed : ${errorCode.errorCode} + errorMessage : ${errorCode.errorMessage}",
                    Toast.LENGTH_SHORT
                ).show()
            }

            override fun OnInterstitialOpenFailed(errorCode: SSPErrorCode) {
                Log.i(
                    LOG_TAG,
                    "OnInterstitialOpenFailed : ${errorCode.errorCode} + errorMessage : ${errorCode.errorMessage}"
                )
                Toast.makeText(
                    this@MainActivity,
                    "OnInterstitialOpenFailed : ${errorCode.errorCode} + errorMessage : ${errorCode.errorMessage}", Toast.LENGTH_SHORT).show()
            }


            override fun OnInterstitialClosed(closeEvent: Int) {
                Log.i(LOG_TAG, "OnInterstitialClosed : $closeEvent")
                if (closeEvent == InterstitialAd.CloseEvent.UNKNOWN)
                    Toast.makeText(this@MainActivity, "OnInterstitialClosed : unknwon", Toast.LENGTH_SHORT).show()
                else if (closeEvent == InterstitialAd.CloseEvent.CLICK_CLOSE_BTN)
                    Toast.makeText(
                        this@MainActivity,
                        "OnInterstitialClosed : click close btn",
                        Toast.LENGTH_SHORT
                    ).show()
                else if (closeEvent == InterstitialAd.CloseEvent.PRESSED_BACK_KEY)
                    Toast.makeText(
                        this@MainActivity,
                        "OnInterstitialClosed : pressed back key",
                        Toast.LENGTH_SHORT
                    ).show()
            }
        })

        val loadInterstitial = findViewById<Button>(R.id.button_interstitial_load)
        loadInterstitial.setOnClickListener{
            igawInterstitialAd?.loadAd()
        }

        val showInterstitial = findViewById<Button>(R.id.button_interstitial_show)
        showInterstitial.setOnClickListener{
            if(igawInterstitialAd?.isLoaded == true)
                igawInterstitialAd?.showAd()
            else
                Toast.makeText(this@MainActivity, "InterstitialAd is not loaded", Toast.LENGTH_SHORT).show()
        }

        // 6.Reward Video
        igawRewardVideoAd = IgawRewardVideoAd(this@MainActivity)
        igawRewardVideoAd?.setPlacementId(IGAW_REWARD_VIDEO_AD_PLACEMENT_ID)
        igawRewardVideoAd?.setRewardVideoAdEventCallbackListener(iRewardVideoAdEventCallbackListener)
        val loadRewardVideoAd = findViewById<Button>(R.id.button_reward_video_load)
        loadRewardVideoAd.setOnClickListener{
            igawRewardVideoAd?.loadAd()
        }

        val showRewardVideoAd = findViewById<Button>(R.id.button_reward_video_show)
        showRewardVideoAd.setOnClickListener{
            if (igawRewardVideoAd?.isReady == true)
                igawRewardVideoAd?.showAd()
            else
                Toast.makeText(this@MainActivity, "RewardVideo is not loaded", Toast.LENGTH_SHORT).show()
        }


        // 7. Native Ad(SSP Mediation, 샘플로 admob, mintegral mediation만 제공)
        // admob, mintegral 이외의 업체 코드는 가이드 페이지의 샘플 코드를 참고.
        igawMediationNativeAd = findViewById<IgawNativeAd>(R.id.igaw_mediation_native_ad)
        igawMediationNativeAd?.setPlacementId(IGAW_NATIVE_AD_PLACEMENT_ID)

        val igawMediationViewBinder = IgawViewBinder.Builder(R.id.igaw_native_ad_view)
            .iconImageViewId(R.id.igaw_native_ad_icon_image1)
            .descViewId(R.id.igaw_native_ad_desc1)
            .mainImageViewId(R.id.igaw_native_ad_main_image1)
            .titleViewId(R.id.igaw_native_ad_title1)
            .callToActionId(R.id.igaw_native_ad_ctatext1)
            .build()

        igawMediationNativeAd?.igawViewBinder = igawMediationViewBinder

        val adMobViewBinder =
            AdMobViewBinder.Builder(R.id.admob_unified_native_ad_view, R.layout.admob_native_ad_unit_layout)
                .iconViewId(R.id.admob_ad_app_icon)
                .headlineViewId(R.id.admob_ad_headline)
                .bodyViewId(R.id.admob_ad_body)
                .mediaViewId(R.id.admob_ad_media)
                .callToActionId(R.id.admob_ad_call_to_action)
                .advertiserViewId(R.id.admob_ad_advertiser)
                .priceViewId(R.id.admob_ad_price)
                .starRatingViewId(R.id.admob_ad_stars)
                .storeViewId(R.id.admob_ad_store)
                .build()
        igawMediationNativeAd?.adMobViewBinder = adMobViewBinder

        val mintegralViewBinder =
            MintegralViewBinder.Builder(R.id.mintegral_native_ad_view, R.layout.mintegral_native_ad_unit_layout)
                .mainImageViewId(R.id.mintegral_native_main_image)
                .iconViewId(R.id.mintegral_native_icon_image)
                .titleViewId(R.id.mintegral_native_title)
                .descViewId(R.id.mintegral_native_text)
                .adCallViewId(R.id.mintegral_native_cta)
                .adChoiceViewId(R.id.mintegral_ad_choice_image)
                .build()
        igawMediationNativeAd?.mintegralViewBinder = mintegralViewBinder

        igawMediationNativeAd?.setNativeAdEventCallbackListener(object : INativeAdEventCallbackListener{
            override fun onNativeAdLoadSuccess() {
                Log.i(
                    LOG_TAG,
                    "Mediation NativeAd onNativeAdLoadSuccess : ${igawMediationNativeAd?.isLoaded}"
                )
                Toast.makeText(this@MainActivity, "onNativeAdLoadSuccess", Toast.LENGTH_SHORT).show()
            }

            override fun onNativeAdLoadFailed(errorCode: SSPErrorCode) {
                Log.i(
                    LOG_TAG,
                    "Mediation NativeAd onNativeAdLoadFailed : ${igawMediationNativeAd?.isLoaded} + $errorCode : $errorCode.getErrorMessage()"
                )
                Toast.makeText(
                    this@MainActivity,
                    "onNativeAdLoadFailed : ${errorCode.errorCode} + ${errorCode.errorMessage}",
                    Toast.LENGTH_SHORT
                ).show()
            }

            override fun onImpression() {
                Log.i(LOG_TAG, "Mediation NativeAd onImpression")
                Toast.makeText(this@MainActivity, "onImpression", Toast.LENGTH_SHORT).show()
            }

            override fun onClicked() {
                Log.i(LOG_TAG, "Mediation NativeAd onClicked")
                Toast.makeText(this@MainActivity, "onClicked", Toast.LENGTH_SHORT).show()
            }
        })

        val loadMediationNativeAd = findViewById<Button>(R.id.button_mediation_native_ad_load)
        loadMediationNativeAd.setOnClickListener {
            igawMediationNativeAd?.loadAd()
        }

        // 8. Interstitial Video
        igawInterstitialVideoAd = IgawInterstitialVideoAd(this)
        igawInterstitialVideoAd?.setPlacementId(IGAW_INTERSTITAL_VIDEO_AD_PLACEMENT_ID)
        igawInterstitialVideoAd?.setEventCallbackListener(interstitialVideoAdEventCallbackListener)
        val loadInterstitialVideoAd = findViewById<Button>(R.id.button_interstitial_video_load)
        loadInterstitialVideoAd.setOnClickListener{
            igawInterstitialVideoAd?.loadAd()
        }

        val showInterstitialVideoAd = findViewById<Button>(R.id.button_interstitial_video_show)
        showInterstitialVideoAd.setOnClickListener(View.OnClickListener {
            if (igawInterstitialVideoAd?.isReady == true)
                igawInterstitialVideoAd?.showAd()
            else
                Toast.makeText(this@MainActivity, "Interstitial VideoAd is not loaded", Toast.LENGTH_SHORT).show()
        })
    }


    private var iRewardVideoAdEventCallbackListener: IRewardVideoAdEventCallbackListener = object :
        IRewardVideoAdEventCallbackListener {
        override fun OnRewardVideoAdLoaded() {
            // 광고 로드 성공
            Toast.makeText(this@MainActivity, "OneButton OnRewardVideoAdLoaded", Toast.LENGTH_SHORT).show()
            Log.i("IgawSSPSample", "OnRewardVideoAdLoaded")
        }

        override fun OnRewardVideoAdLoadFailed(sspErrorCode: SSPErrorCode) {
            // 광고 로드 실패
            Toast.makeText(this@MainActivity, "OnRewardVideoAdLoadFailed", Toast.LENGTH_SHORT).show()
            Log.i("IgawSSPSample", "OnRewardVideoAdLoadFailed")
        }

        override fun OnRewardVideoAdOpened() {
            Toast.makeText(this@MainActivity, "OnRewardVideoShowSuccess", Toast.LENGTH_SHORT).show()
            Log.i("IgawSSPSample", "OnRewardVideoShowSuccess")
        }

        override fun OnRewardVideoAdOpenFalied() {
            Toast.makeText(this@MainActivity, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show()
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed")
        }

        override fun OnRewardVideoAdClosed() {
            Toast.makeText(this@MainActivity, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show()
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed")
        }

        override fun OnRewardVideoPlayCompleted(networkId: Int, completed: Boolean) {
            Toast.makeText(
                this@MainActivity, "OnRewardVideoPlayCompleted : " + networkId + ", " +
                        "completed : " + completed,
                Toast.LENGTH_SHORT
            ).show()
            Log.i(
                "IgawSSPSample", "OnRewardVideoPlayCompleted : " + networkId + ", " +
                        "completed : " + completed
            )
            onCompletedRewardVideoAd()
        }
    }

    private var interstitialVideoAdEventCallbackListener: IInterstitialVideoAdEventCallbackListener = object :
        IInterstitialVideoAdEventCallbackListener {
        override fun OnInterstitialVideoAdLoaded() {

        }

        override fun OnInterstitialVideoAdLoadFailed(sspErrorCode: SSPErrorCode) {

        }

        override fun OnInterstitialVideoAdOpened() {

        }

        override fun OnInterstitialVideoAdOpenFalied() {

        }

        override fun OnInterstitialVideoAdClosed() {

        }
    }

    private fun onCompletedRewardVideoAd() {
        // 리워드 비디오가 정상적으로 종료 되었을 때 처리.
    }

    override fun onResume() {
        super.onResume()
        // 8. Activity Life cycle에 맞춰 onResume 연동
        igawBannerAd_320x50?.onResume()
        igawBannerAd_320x100?.onResume()
        igawBannerAd_300x250?.onResume()
        igawRewardVideoAd?.onResume()
    }

    override fun onPause() {
        super.onPause()
        // 9. Activity Life cycle에 맞춰 onResume 연동
        igawBannerAd_320x50?.onPause()
        igawBannerAd_320x100?.onPause()
        igawBannerAd_300x250?.onPause()
        igawRewardVideoAd?.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        IgawSSP.destroy()
    }
}
