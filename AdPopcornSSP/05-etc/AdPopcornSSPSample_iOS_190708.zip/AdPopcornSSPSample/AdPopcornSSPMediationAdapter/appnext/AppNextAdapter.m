//
//  AppNextAdapter.m
//  AdPopcornSSP
//
//  Created by mick on 2019. 3. 19..
//  Copyright (c) 2019년 igaworks All rights reserved.
//

#import "AppNextAdapter.h"

static inline NSString *SSPErrorString(SSPErrorCode code)
{
    switch (code)
    {
        case AdPopcornSSPException:
            return @"Exception";
        case AdPopcornSSPInvalidParameter:
            return @"Invalid Parameter";
        case AdPopcornSSPUnknownServerError:
            return @"Unknown Server Error";
        case AdPopcornSSPInvalidMediaKey:
            return @"Invalid Media key";
        case AdPopcornSSPInvalidPlacementId:
            return @"Invalid Placement Id";
        case AdPopcornSSPInvalidNativeAssetsConfig:
            return @"Invalid native assets config";
        case AdPopcornSSPNativePlacementDoesNotInitialized:
            return @"Native Placement Does Not Initialized";
        case AdPopcornSSPServerTimeout:
            return @"Server Timeout";
        case AdPopcornSSPLoadAdFailed:
            return @"Load Ad Failed";
        case AdPopcornSSPNoAd:
            return @"No Ad";
        case AdPopcornSSPNoInterstitialLoaded:
            return @"No Interstitial Loaded";
        case AdPopcornSSPNoRewardVideoAdLoaded:
            return @"No Reward video ad Loaded";
        case AdPopcornSSPMediationAdapterNotInitialized:
            return @"Mediation Adapter Not Initialized";
        default: {
            return @"Success";
        }
    }
}

@interface AppNextAdapter () <AppnextBannerDelegate, AppnextAdDelegate>
{
    BOOL _isCurrentRunningAdapter;
}

@end

@implementation AppNextAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;
@synthesize viewController = _viewController;
@synthesize bannerView = _bannerView;

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}

- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(AdPopcornSSPBannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = SSPAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPAdInterstitialType;
}

- (void)setRewardVideoViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPRewardVideoAdType;
}

- (BOOL)isSupportInterstitialAd
{
    return YES;
}

- (BOOL)isSupportRewardVideoAd
{
    return YES;
}

- (void)loadAd
{
    NSLog(@"AppNextAdapter %@ : loadAd", self);
    if (_adType == SSPAdBannerType)
    {
        if (_integrationKey != nil)
        {
            NSString *placementId = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
            NSLog(@"AppNextAdapter SSPAdBannerType placementId : %@", placementId);
            
            _bannerRequest = [[BannerRequest alloc] init];
            if(_size.width == 320.0f && _size.height == 100.0f)
            {
                _bannerRequest.bannerType = LargeBanner;
            }
            else if(_size.width == 300.0f && _size.height == 250.0f)
            {
                _bannerRequest.bannerType = MediumRectangle;
            }
            else
            {
                _bannerRequest.bannerType = Banner;
            }
            
            AppnextBannerView* appNextBannerView = [[AppnextBannerView alloc] initBannerWithPlacementID:placementId];
            
            appNextBannerView.delegate = self;
            appNextBannerView.translatesAutoresizingMaskIntoConstraints = NO;
            [_bannerView addSubview: appNextBannerView];
            [_bannerView addConstraints: @[[NSLayoutConstraint constraintWithItem: appNextBannerView attribute:NSLayoutAttributeBottom relatedBy: NSLayoutRelationEqual toItem: _bannerView attribute: NSLayoutAttributeBottom multiplier: 1 constant: 0], [NSLayoutConstraint constraintWithItem: appNextBannerView attribute: NSLayoutAttributeCenterX relatedBy: NSLayoutRelationEqual toItem: _bannerView attribute: NSLayoutAttributeCenterX multiplier: 1 constant: 0]]];
            [appNextBannerView loadAd:_bannerRequest];
        }
        else
        {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
            
            [self closeAd];
        }
    }
    else if (_adType == SSPAdInterstitialType)
    {
        if (_integrationKey != nil)
        {
            NSString *placementId = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
            NSLog(@"AppNextAdapter SSPAdInterstitialType placementId : %@", placementId);
            
            _interstitial = [[AppnextInterstitialAd alloc] initWithPlacementID:placementId];
            _interstitial.delegate = self;
            [_interstitial loadAd];
        }
        else
        {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitialAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
            
            [self closeAd];
        }
    }
    else if (_adType == SSPRewardVideoAdType)
    {
        _isCurrentRunningAdapter = YES;
        _isLoadMode = YES;
        if (_integrationKey != nil)
        {
            NSString *placementId = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
            if(_rewarded == nil)
                _rewarded = [[AppnextRewardedVideoAd alloc] initWithPlacementID:placementId];
            _rewarded.delegate = self;
            if(![_rewarded adIsLoaded])
            {
                NSLog(@"AppNextAdapter call loadAd");
                [_rewarded loadAd];
            }
            else
            {
                NSLog(@"AppNextAdapter already ready");
                if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadSuccess:)])
                {
                    [_delegate AdPopcornSSPAdapterRewardVideoAdLoadSuccess:self];
                }
            }
                
        }
        else
        {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
        }
    }
}

- (void)showAd
{
    NSLog(@"AppNextAdapter : showAd");
    if (_adType == SSPAdInterstitialType)
    {
        if (_interstitial.adIsLoaded)
        {
            [_interstitial showAd];
        }
    }
    if (_adType == SSPRewardVideoAdType)
    {
        _isLoadMode = NO;
        if (_rewarded.adIsLoaded)
        {
            [_rewarded showAd];
        }
        else
        {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoRewardVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoRewardVideoAdLoaded)}] adapter:self];
            }
        }
    }
}

- (void)closeAd
{
    NSLog(@"AppNextAdapter closeAd");
    _isCurrentRunningAdapter = NO;
}

- (void)loadRequest
{
    // Not used any more
}

#pragma AppnextBannerDelegate
- (void) onAppnextBannerLoadedSuccessfully
{
    NSLog(@"AppNextAdapter onAppnextBannerLoadedSuccessfully");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadSuccess:)])
    {
        [_delegate AdPopcornSSPAdapterBannerViewLoadSuccess:self];
    }
}
- (void) onAppnextBannerError:(AppnextError) error
{
    NSLog(@"AppNextAdapter onAppnextBannerError");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
    }
    
    [self closeAd];
}
- (void) onAppnextBannerClicked
{
    NSLog(@"AppNextAdapter onAppnextBannerClicked");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewClicked:)])
    {
        [_delegate AdPopcornSSPAdapterBannerViewClicked:self];
    }
}

#pragma AppnextAdDelegate
- (void) adLoaded:(AppnextAd *)ad
{
    NSLog(@"AppNextAdapter adLoaded");
    if(_adType == SSPAdInterstitialType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialAdLoadSuccess:self];
        }
    }
    else
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadSuccess:self];
        }
    }
}

- (void) adOpened:(AppnextAd *)ad
{
    NSLog(@"AppNext adOpened");
    if(_adType == SSPAdInterstitialType)
    {
        
    }
    else
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdShowSuccess:self];
        }
    }
}

- (void) adClosed:(AppnextAd *)ad
{
    NSLog(@"AppNextAdapter adClosed");
    if(_adType == SSPAdInterstitialType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdClosed:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialAdClosed:self];
        }
    }
    else
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterOnAppNextAdsVideoCompleted)])
        {
            [_delegate AdPopcornSSPAdapterOnAppNextAdsVideoCompleted];
        }
        
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdClose:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdClose:self];
        }
        _isCurrentRunningAdapter = NO;
    }
}

- (void) adClicked:(AppnextAd *)ad
{
    NSLog(@"AppNextAdapter adClicked");
}

- (void) adError:(AppnextAd *)ad error:(NSString *)error
{
    NSLog(@"AppNextAdapter adError : %@", error);
    if(_adType == SSPAdInterstitialType)
    {
        [self closeAd];
        
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
        }
    }
    else
    {
        if(_isLoadMode)
        {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
            }
        }
        else
        {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoRewardVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoRewardVideoAdLoaded)}] adapter:self];
            }
        }
    }
}
@end
