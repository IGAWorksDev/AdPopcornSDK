//
//  AppnextFullScreenVideoAdConfiguration.h
//  AppnextLib
//
//  Created by Eran Mausner on 31/03/2016.
//  Copyright © 2016 Appnext. All rights reserved.
//

#import <AppnextLib/AppnextVideoAdConfiguration.h>

@interface AppnextFullScreenVideoAdConfiguration : AppnextVideoAdConfiguration

@end
