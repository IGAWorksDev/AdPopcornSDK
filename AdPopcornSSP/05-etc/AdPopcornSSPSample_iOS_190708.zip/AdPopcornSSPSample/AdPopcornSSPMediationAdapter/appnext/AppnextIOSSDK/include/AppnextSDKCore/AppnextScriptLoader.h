//
//  AppnextScriptLoader.h
//  AppnextSDKCore
//
//  Created by Eran Mausner on 17/01/2016.
//  Copyright © 2016 Appnext. All rights reserved.
//

#import <AppnextSDKCore/AppnextResourceLoader.h>

@interface AppnextScriptLoader : AppnextResourceLoader

@end
