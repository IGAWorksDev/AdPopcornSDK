//
//  AppNextAdapter.h
//  AdPopcornSSP
//
//  Created by mick on 2019. 3. 19..
//  Copyright (c) 2019년 igaworks All rights reserved.
//

#import <AppnextLib/AppnextLib.h>

// Using pod install / unity
#import <AdPopcornSSP/AdPopcornSSPAdapter.h>
// else
//#import "AdPopcornSSPAdapter.h"

@interface AppNextAdapter : AdPopcornSSPAdapter
{
    BannerRequest *_bannerRequest;
    AppnextInterstitialAd *_interstitial;
    AppnextRewardedVideoAd *_rewarded;
    BOOL _isLoadMode;
}
@end
