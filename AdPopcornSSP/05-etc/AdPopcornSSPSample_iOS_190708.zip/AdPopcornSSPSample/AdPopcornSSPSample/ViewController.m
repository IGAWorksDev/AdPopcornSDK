//
//  ViewController.m
//  AdPopcornTestApp
//
//  Created by 김민석 on 2016. 12. 5..
//  Copyright © 2016년 igaworks. All rights reserved.
//

#import "ViewController.h"
#import "AdPopcornSSP/AdPopcornSSPRewardVideoAd.h"

@interface ViewController () <APSSPRewardVideoAdDelegate>{
    AdPopcornSSPRewardVideoAd *_sspRewardVideoAd;
    BOOL _completeLoadAndShow; // 한 번의 load 당 한 번의 show만 동작 하도록 하는 flag
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _sspRewardVideoAd = [[AdPopcornSSPRewardVideoAd alloc] initWithKey:@"114554353" placementId:@"oel985g2ypygjff" viewController:self];
    _sspRewardVideoAd.delegate = self;
    _completeLoadAndShow = NO;
}

- (IBAction)LoadMediationVideo:(id)sender {
    if(![_sspRewardVideoAd isReady])
    {
        _completeLoadAndShow = NO;
        [_sspRewardVideoAd loadRequest];
    }
}

- (IBAction)ShowMediationVideo:(id)sender {
    if([_sspRewardVideoAd isReady] && !_completeLoadAndShow)
        [_sspRewardVideoAd presentFromViewController:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark APSSPRewardVideoAdDelegate
- (void)APSSPRewardVideoAdLoadSuccess:(AdPopcornSSPRewardVideoAd *)rewardVideoAd
{
    int networkNum = -1;
    if(_sspRewardVideoAd != nil)
    {
        networkNum = [_sspRewardVideoAd getCurrentNetwork];
    }
    NSLog(@"APSSPRewardVideoAdLoadSuccess : %ld", (long)networkNum);
}

- (void)APSSPRewardVideoAdLoadFail:(AdPopcornSSPRewardVideoAd *)rewardVideoAd error:(AdPopcornSSPError *)error
{
    NSLog(@"APSSPRewardVideoAdLoadFail : %@", error);
}

- (void)APSSPRewardVideoAdShowSuccess:(AdPopcornSSPRewardVideoAd *)rewardVideoAd
{
    NSLog(@"APSSPRewardVideoAdShowSuccess");
    _completeLoadAndShow = YES;
}

- (void)APSSPRewardVideoAdShowFail:(AdPopcornSSPRewardVideoAd *)rewardVideoAd
{
    NSLog(@"APSSPRewardVideoAdShowFail");
    _completeLoadAndShow = YES;
}

- (void)APSSPRewardVideoAdClosed:(AdPopcornSSPRewardVideoAd *)rewardVideoAd{
    NSLog(@"APSSPRewardVideoAdClosed");
    _completeLoadAndShow = YES;
}

- (void)APSSPRewardVideoAdPlayCompleted:(AdPopcornSSPRewardVideoAd *)rewardVideoAd quantity:(long) quantity currency:(NSString *)currency
{
    NSLog(@"APSSPRewardVideoAdPlayCompleted %ld, %@", quantity, currency);
    _completeLoadAndShow = YES;
}

-(void)APSSPRewardVideoAdMintegralVideoCompleted:(AdPopcornSSPRewardVideoAd *)rewardVideoAd rewardAmount:(NSInteger)rewardAmount
{
    NSLog(@"APSSPRewardVideoAdMintegralVideoCompleted %ld", rewardAmount);
    _completeLoadAndShow = YES;
}

- (void)APSSPRewardVideoAdUnityAdsVideoCompleted:(AdPopcornSSPRewardVideoAd *)rewardVideoAd
{
    NSLog(@"APSSPRewardVideoAdUnityAdsVideoCompleted");
    _completeLoadAndShow = YES;
}

- (void)APSSPRewardVideoAdAdMobVideoCompleted:(AdPopcornSSPRewardVideoAd *)rewardVideoAd rewardAmount:(double)rewardAmount
{
    NSLog(@"APSSPRewardVideoAdAdMobVideoCompleted %f", rewardAmount);
    _completeLoadAndShow = YES;
}

- (void)APSSPRewardVideoAdAppNextAdsVideoCompleted:(AdPopcornSSPRewardVideoAd *)rewardVideoAd
{
    NSLog(@"APSSPRewardVideoAdAppNextAdsVideoCompleted");
    _completeLoadAndShow = YES;
}
@end
