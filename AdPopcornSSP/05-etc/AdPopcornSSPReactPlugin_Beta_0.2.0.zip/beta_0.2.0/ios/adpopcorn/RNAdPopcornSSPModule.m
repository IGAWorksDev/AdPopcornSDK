//
//  RNAdPopcornSSPModule.m
//  AdPopcornSSPReactPlugin
//
//  Created by 김민석 on 2023/05/18.
//


#import <Foundation/Foundation.h>
#import "RNAdPopcornSSPModule.h"

@implementation RNAdPopcornSSPModule

RCT_EXPORT_MODULE(RNAdPopcornSSPModule)

- (NSArray<NSString*>*)supportedEvents
{
  return @[@"OnAdPopcornSSPSDKDidInitialize"];
}

RCT_EXPORT_METHOD(init:(NSString *)appKey)
{
  [AdPopcornSSP initializeSDK:appKey];
  [AdPopcornSSP sharedInstance].initializeDelegate = self;
}

RCT_EXPORT_METHOD(setUserId:(NSString *)userId)
{
  [AdPopcornSSP setUserId:userId];
}

#pragma mark APSSPSDKInitializeDelegate
- (void)AdPopcornSSPSDKDidInitialize
{
  NSLog(@"AdPopcornSSP AdPopcornSSPSDKDidInitialize");
  [self sendEventWithName:@"OnAdPopcornSSPSDKDidInitialize" body:nil];
}
@end
