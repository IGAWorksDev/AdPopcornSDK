//
//  RNAdPopcornBannerView.h
//  AdPopcornSSPReactPlugin
//
//  Created by 김민석 on 2023/05/17.
//

#import <React/RCTViewManager.h>
#import <React/RCTUIManager.h>
#import <React/RCTLog.h>
#import <AdPopcornSSP/AdPopcornSSPBannerView.h>
#import <AdPopcornSSP/AdPopcornSSPAdSize.h>

@class RCTEventDispatcher;

@interface RNAdPopcornBannerView : UIView <APSSPBannerViewDelegate>

@property AdPopcornSSPBannerView *bannerView;

@property (nonatomic, copy) NSString *appKey;
@property (nonatomic, copy) NSString *placementId;
@property (nonatomic, copy) NSString *adSize;
@property (nonatomic, unsafe_unretained) NSInteger refreshTime;
@property (nonatomic, unsafe_unretained) NSInteger networkScheduleTimeout;
@property (nonatomic, unsafe_unretained) NSInteger viewWidth;
@property (nonatomic, unsafe_unretained) NSInteger viewHeight;
@property (nonatomic, copy) NSString *bannerAnimType;
@property (nonatomic, unsafe_unretained) BOOL autoBgColor;
@property (nonatomic, unsafe_unretained) NSInteger originX;
@property (nonatomic, unsafe_unretained) NSInteger originY;

@property (nonatomic, copy) RCTDirectEventBlock onBannerAdReceiveSuccess;
@property (nonatomic, copy) RCTDirectEventBlock onBannerAdReceiveFailed;
@property (nonatomic, copy) RCTDirectEventBlock onBannerAdClicked;

@end
