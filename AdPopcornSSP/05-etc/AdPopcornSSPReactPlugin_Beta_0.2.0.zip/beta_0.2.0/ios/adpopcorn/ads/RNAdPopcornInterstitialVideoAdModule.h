//
//  RNAdPopcornInterstitialVideoAdModule.h
//  AdPopcornSSPReactPlugin
//
//  Created by 김민석 on 2023/05/18.
//

#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>
#import <UIKit/UIKit.h>
#import <AdPopcornSSP/AdPopcornSSPInterstitialVideoAd.h>

@interface RNAdPopcornInterstitialVideoAdModule : RCTEventEmitter<RCTBridgeModule, APSSPInterstitialVideoAdDelegate>
{
  
}

@property (retain, nonatomic) NSMutableDictionary *dictionary;

@end
