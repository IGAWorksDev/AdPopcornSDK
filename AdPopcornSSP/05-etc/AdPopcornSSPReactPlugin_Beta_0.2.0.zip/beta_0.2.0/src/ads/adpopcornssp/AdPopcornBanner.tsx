import React from 'react';
import { requireNativeComponent, HostComponent, ViewStyle, NativeSyntheticEvent } from 'react-native';

interface BannerProps {
  appKey: string;
  placementId: string;
  adSize: '320x50' | '320x100' | '320x250';
  viewWidth?: number;
  viewHeight?: number;
  refreshTime?: number;
  originX?: number;
  originY?: number;
  networkScheduleTimeout?: number;
  bannerAnimType?: 'FADE_IN' | 'SLIDE_LEFT' | 'SLIDE_RIGHT' | 'TOP_SLIDE' | 'BOTTOM_SLIDE' | 'CIRCLE' | 'NONE';
  autoBgColor?: boolean;
  onBannerAdReceiveSuccess: PropTypes.func;
  onBannerAdReceiveFailed: PropTypes.func;
  onBannerAdClicked: PropTypes.func;
}

interface AdPopcornProps extends BannerProps {
  style: ViewStyle;
}

const RNAdPopcornBannerView: HostComponent<AdPopcornProps> = requireNativeComponent('RNAdPopcornBannerView');

class AdPopcornBanner extends React.Component<Props> {
      constructor(props: Props) {
        super(props);
      }

    _onBannerAdReceiveSuccess = (event) => {
        console.log('onBannerAdReceiveSuccess', event.nativeEvent);
        const { onBannerAdReceiveSuccess } = this.props;
        onBannerAdReceiveSuccess && onBannerAdReceiveSuccess(event.nativeEvent);
    };
    _onBannerAdReceiveFailed = (event) => {
        console.log('onBannerAdReceiveFailed', event.nativeEvent);
        const { onBannerAdReceiveFailed } = this.props;
        onBannerAdReceiveFailed && onBannerAdReceiveFailed(event.nativeEvent);
    };
    _onBannerAdClicked = (event) => {
        console.log('onBannerAdClicked', event.nativeEvent);
        const { onBannerAdClicked } = this.props;
        onBannerAdClicked && onBannerAdClicked(event.nativeEvent);
    };
      render() {
        const {
          appKey,
          placementId,
          adSize,
          viewWidth = 0,
          viewHeight = 0,
          originX = 0,
          originY = 0,
          refreshTime = 30,
          networkScheduleTimeout = 10,
          bannerAnimType = 'NONE',
          autoBgColor = false
        } = this.props;

        const height = adSize === '320x50' ? 50 : adSize === '320x100' ? 100 : 250;

        return (
          <RNAdPopcornBannerView
                style={{ width: '100%', height }}
                appKey={appKey}
                placementId={placementId}
                adSize={adSize}
                viewWidth={viewWidth}
                viewHeight={viewHeight}
                originX={originX}
                originY={originY}
                refreshTime={refreshTime}
                networkScheduleTimeout={networkScheduleTimeout}
                bannerAnimType={bannerAnimType}
                autoBgColor={autoBgColor}
                onBannerAdReceiveSuccess={this._onBannerAdReceiveSuccess}
                onBannerAdReceiveFailed={this._onBannerAdReceiveFailed}
                onBannerAdClicked={this._onBannerAdClicked}
          />
        );
      }
}


export default AdPopcornBanner;