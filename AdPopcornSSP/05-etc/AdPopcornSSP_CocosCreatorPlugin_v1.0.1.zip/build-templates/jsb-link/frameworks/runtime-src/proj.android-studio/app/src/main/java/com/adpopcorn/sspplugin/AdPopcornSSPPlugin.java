package com.adpopcorn.sspplugin;

import android.app.Activity;
import android.os.Looper;

import com.igaworks.ssp.AdPopcornSSP;
import com.igaworks.ssp.SSPErrorCode;
import com.igaworks.ssp.SdkInitListener;
import com.igaworks.ssp.common.model.RewardAdPlusPlacementStatusModel;
import com.igaworks.ssp.part.interstitial.AdPopcornSSPInterstitialAd;
import com.igaworks.ssp.part.interstitial.listener.IInterstitialEventCallbackListener;
import com.igaworks.ssp.part.mix.AdPopcornSSPVideoMixAd;
import com.igaworks.ssp.part.mix.listener.IVideoMixAdEventCallbackListener;
import com.igaworks.ssp.part.popcontents.AdPopcornSSPPopContentsAd;
import com.igaworks.ssp.part.popcontents.listener.IPopContentsAdEventCallbackListener;
import com.igaworks.ssp.part.video.AdPopcornSSPInterstitialVideoAd;
import com.igaworks.ssp.part.video.AdPopcornSSPRewardVideoAd;
import com.igaworks.ssp.part.video.listener.IInterstitialVideoAdEventCallbackListener;
import com.igaworks.ssp.part.video.listener.IRewardPlusSettingEventCallbackListener;
import com.igaworks.ssp.part.video.listener.IRewardVideoAdEventCallbackListener;
import com.igaworks.ssp.rewardplus.AdPopcornSSPRewardAdPlus;
import com.igaworks.ssp.rewardplus.listener.IRewardAdEventCallbackListener;
import com.igaworks.ssp.rewardplus.listener.IRewardAdPlusUserStatusCallbackListener;

import org.cocos2dx.lib.Cocos2dxActivity;
import org.cocos2dx.lib.Cocos2dxJavascriptJavaBridge;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdPopcornSSPPlugin {
    private static Activity activityContext;
    private static Map<String, AdPopcornSSPInterstitialAd> interstitialAdMap = new HashMap<>();
    private static Map<String, AdPopcornSSPInterstitialVideoAd> interstitialVideoAdMap = new HashMap<>();
    private static Map<String, AdPopcornSSPRewardVideoAd> rewardVideoAdMap = new HashMap<>();
    private static Map<String, AdPopcornSSPPopContentsAd> popContentsAdMap = new HashMap<>();
    private static Map<String, AdPopcornSSPVideoMixAd> videoMixAdMap = new HashMap<>();

    public static void init() {
        activityContext = (Activity) Cocos2dxActivity.getContext();
        activityContext.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                AdPopcornSSP.init(activityContext, new SdkInitListener() {
                    @Override
                    public void onInitializationFinished() {
                        sendEventToJS("AdPopcornSSPSDKDidInitialize", null);
                    }
                });
            }
        });
    }

    public static void setUserId(String userId){
        activityContext = (Activity) Cocos2dxActivity.getContext();
        activityContext.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                AdPopcornSSP.setUserId(activityContext, userId);
            }
        });
    }

    public static void setLogEnable(boolean enable) {
        activityContext = (Activity) Cocos2dxActivity.getContext();
        activityContext.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                AdPopcornSSP.setLogEnable(enable);
            }
        });
    }

    public static void loadInterstitial(String appKey, String placementId){
        try {
            activityContext = (Activity) Cocos2dxActivity.getContext();
            activityContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AdPopcornSSPInterstitialAd interstitialAd;
                    if (interstitialAdMap.containsKey(placementId)) {
                        interstitialAd = interstitialAdMap.get(placementId);
                    }
                    else {
                        interstitialAd = new AdPopcornSSPInterstitialAd(activityContext);
                        interstitialAdMap.put(placementId, interstitialAd);
                    }
                    interstitialAd.setPlacementId(placementId);
                    interstitialAd.setInterstitialEventCallbackListener(new IInterstitialEventCallbackListener() {
                        @Override
                        public void OnInterstitialLoaded() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnInterstitialLoaded", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnInterstitialLoaded", null);
                            }
                        }

                        @Override
                        public void OnInterstitialReceiveFailed(SSPErrorCode sspErrorCode) {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                params.put("errorCode", sspErrorCode.getErrorCode());
                                sendEventToJS("OnInterstitialLoadFailed", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnInterstitialLoadFailed", null);
                            }
                        }

                        @Override
                        public void OnInterstitialOpened() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnInterstitialOpened", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnInterstitialOpened", null);
                            }
                        }

                        @Override
                        public void OnInterstitialOpenFailed(SSPErrorCode sspErrorCode) {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnInterstitialOpenFailed", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnInterstitialOpenFailed", null);
                            }
                        }

                        @Override
                        public void OnInterstitialClosed(int i) {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnInterstitialClosed", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnInterstitialClosed", null);
                            }
                        }

                        @Override
                        public void OnInterstitialClicked() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnInterstitialClicked", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnInterstitialClicked", null);
                            }
                        }
                    });
                    interstitialAd.loadAd();
                }
            });
        }catch (Exception e){}
    }

    public static void showInterstitial(String appKey, String placementId)
    {
        try{
            activityContext = (Activity) Cocos2dxActivity.getContext();
            activityContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AdPopcornSSPInterstitialAd interstitialAd;
                    if(interstitialAdMap.containsKey(placementId))
                    {
                        interstitialAd = interstitialAdMap.get(placementId);
                        if(activityContext != null && activityContext instanceof Activity)
                            interstitialAd.setCurrentActivity((Activity)activityContext);
                    }
                    else
                    {
                        interstitialAd = new AdPopcornSSPInterstitialAd(activityContext);
                    }
                    if(interstitialAd.isLoaded()) {
                        interstitialAd.showAd();
                    }
                    else {
                        try {
                            JSONObject params = new JSONObject();
                            params.put("placementId", placementId);
                            sendEventToJS("OnInterstitialOpenFailed", params.toString());
                        } catch (Exception e) {
                            sendEventToJS("OnInterstitialOpenFailed", null);
                        }
                    }
                }
            });
        }catch (Exception e){}
    }

    public static void loadInterstitialVideo(String appKey, String placementId)
    {
        try{
            activityContext = (Activity) Cocos2dxActivity.getContext();
            activityContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AdPopcornSSPInterstitialVideoAd interstitialVideoAd;
                    if(interstitialVideoAdMap.containsKey(placementId))
                    {
                        interstitialVideoAd = interstitialVideoAdMap.get(placementId);
                    }
                    else
                    {
                        interstitialVideoAd = new AdPopcornSSPInterstitialVideoAd(activityContext);
                        interstitialVideoAdMap.put(placementId, interstitialVideoAd);
                    }
                    interstitialVideoAd.setPlacementId(placementId);
                    interstitialVideoAd.setEventCallbackListener(new IInterstitialVideoAdEventCallbackListener() {
                        @Override
                        public void OnInterstitialVideoAdLoaded() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnInterstitialVideoAdLoaded", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnInterstitialVideoAdLoaded", null);
                            }
                        }

                        @Override
                        public void OnInterstitialVideoAdLoadFailed(SSPErrorCode sspErrorCode) {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                params.put("errorCode", sspErrorCode.getErrorCode());
                                sendEventToJS("OnInterstitialVideoAdLoadFailed", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnInterstitialVideoAdLoadFailed", null);
                            }
                        }

                        @Override
                        public void OnInterstitialVideoAdOpened() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnInterstitialVideoAdOpened", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnInterstitialVideoAdOpened", null);
                            }
                        }

                        @Override
                        public void OnInterstitialVideoAdOpenFalied() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnInterstitialVideoAdOpenFailed", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnInterstitialVideoAdOpenFailed", null);
                            }
                        }

                        @Override
                        public void OnInterstitialVideoAdClosed() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnInterstitialVideoAdClosed", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnInterstitialVideoAdClosed", null);
                            }
                        }

                        @Override
                        public void OnInterstitialVideoAdClicked() {

                        }
                    });
                    interstitialVideoAd.loadAd();
                }
            });
        }catch (Exception e){}
    }

    public static void showInterstitialVideo(String appKey, String placementId)
    {
        try{
            activityContext = (Activity) Cocos2dxActivity.getContext();
            activityContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AdPopcornSSPInterstitialVideoAd interstitialVideoAd;
                    if(interstitialVideoAdMap.containsKey(placementId))
                    {
                        interstitialVideoAd = interstitialVideoAdMap.get(placementId);
                        if(activityContext != null && activityContext instanceof Activity)
                            interstitialVideoAd.setCurrentActivity((Activity)activityContext);
                    }
                    else
                    {
                        interstitialVideoAd = new AdPopcornSSPInterstitialVideoAd(activityContext);
                    }
                    if(interstitialVideoAd.isReady()) {
                        interstitialVideoAd.showAd();
                    }
                    else {
                        try {
                            JSONObject params = new JSONObject();
                            params.put("placementId", placementId);
                            sendEventToJS("OnInterstitialVideoAdOpenFailed", params.toString());
                        } catch (Exception e) {
                            sendEventToJS("OnInterstitialVideoAdOpenFailed", null);
                        }
                    }
                }
            });
        }catch (Exception e){}
    }

    public static void loadRewardVideo(String appKey, String placementId)
    {
        try{
            activityContext = (Activity) Cocos2dxActivity.getContext();
            activityContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AdPopcornSSPRewardVideoAd rewardVideoAd;
                    if(rewardVideoAdMap.containsKey(placementId))
                    {
                        rewardVideoAd = rewardVideoAdMap.get(placementId);
                    }
                    else
                    {
                        rewardVideoAd = new AdPopcornSSPRewardVideoAd(activityContext);
                        rewardVideoAdMap.put(placementId, rewardVideoAd);
                    }
                    rewardVideoAd.setPlacementId(placementId);
                    rewardVideoAd.setRewardVideoAdEventCallbackListener(new IRewardVideoAdEventCallbackListener() {
                        @Override
                        public void OnRewardVideoAdLoaded() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnRewardVideoAdLoaded", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnRewardVideoAdLoaded", null);
                            }
                        }

                        @Override
                        public void OnRewardVideoAdLoadFailed(SSPErrorCode sspErrorCode) {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                params.put("errorCode", sspErrorCode.getErrorCode());
                                sendEventToJS("OnRewardVideoAdLoadFailed", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnRewardVideoAdLoadFailed", null);
                            }
                        }

                        @Override
                        public void OnRewardVideoAdOpened() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnRewardVideoAdOpened", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnRewardVideoAdOpened", null);
                            }
                        }

                        @Override
                        public void OnRewardVideoAdOpenFalied() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnRewardVideoAdOpenFailed", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnRewardVideoAdOpenFailed", null);
                            }
                        }

                        @Override
                        public void OnRewardVideoAdClosed() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnRewardVideoAdClosed", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnRewardVideoAdClosed", null);
                            }
                        }

                        @Override
                        public void OnRewardVideoPlayCompleted(int adNetworkNo, boolean completed) {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                params.put("adNetworkNo", adNetworkNo);
                                params.put("completed", completed);
                                sendEventToJS("OnRewardVideoPlayCompleted", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnRewardVideoPlayCompleted", null);
                            }
                        }

                        @Override
                        public void OnRewardVideoAdClicked() {

                        }

                        @Override
                        public void OnRewardPlusCompleted(boolean b, int i, int i1) {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("APSSPRewardPlusCompleteResult", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("APSSPRewardPlusCompleteResult", null);
                            }
                        }
                    });
                    rewardVideoAd.loadAd();
                }
            });
        }catch (Exception e){}
    }

    public static void showRewardVideo(String appKey, String placementId)
    {
        try{
            activityContext = (Activity) Cocos2dxActivity.getContext();
            activityContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AdPopcornSSPRewardVideoAd rewardVideoAd;
                    if(rewardVideoAdMap.containsKey(placementId))
                    {
                        rewardVideoAd = rewardVideoAdMap.get(placementId);
                        if(activityContext != null && activityContext instanceof Activity)
                            rewardVideoAd.setCurrentActivity((Activity)activityContext);
                    }
                    else
                    {
                        rewardVideoAd = new AdPopcornSSPRewardVideoAd(activityContext);
                    }
                    if(rewardVideoAd.isReady()) {
                        rewardVideoAd.showAd();
                    }
                    else {
                        try {
                            JSONObject params = new JSONObject();
                            params.put("placementId", placementId);
                            sendEventToJS("OnRewardVideoAdOpenFailed", params.toString());
                        } catch (Exception e) {
                            sendEventToJS("OnRewardVideoAdOpenFailed", null);
                        }
                    }
                }
            });
        }catch (Exception e){}
    }

    public static void loadVideoMix(String appKey, String placementId)
    {
        try{
            activityContext = (Activity) Cocos2dxActivity.getContext();
            activityContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AdPopcornSSPVideoMixAd videoMixAd;
                    if(videoMixAdMap.containsKey(placementId))
                    {
                        videoMixAd = videoMixAdMap.get(placementId);
                    }
                    else
                    {
                        videoMixAd = new AdPopcornSSPVideoMixAd(activityContext);
                        videoMixAdMap.put(placementId, videoMixAd);
                    }
                    videoMixAd.setPlacementId(placementId);
                    videoMixAd.setVideoMixAdEventCallbackListener(new IVideoMixAdEventCallbackListener() {
                        @Override
                        public void OnVideoMixAdLoaded() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnVideoMixAdLoaded", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnVideoMixAdLoaded", null);
                            }
                        }

                        @Override
                        public void OnVideoMixAdLoadFailed(SSPErrorCode sspErrorCode) {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnVideoMixAdLoadFailed", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnVideoMixAdLoadFailed", null);
                            }
                        }

                        @Override
                        public void OnVideoMixAdOpened() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnVideoMixAdOpened", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnVideoMixAdOpened", null);
                            }
                        }

                        @Override
                        public void OnVideoMixAdOpenFailed() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnVideoMixAdOpenFailed", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnVideoMixAdOpenFailed", null);
                            }
                        }

                        @Override
                        public void OnVideoMixAdClosed(int campaignType) {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                params.put("campaignType", campaignType);
                                sendEventToJS("OnVideoMixAdClosed", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnVideoMixAdClosed", null);
                            }
                        }

                        @Override
                        public void OnVideoMixPlayCompleted(int adNetworkNo, boolean completed) {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                params.put("adNetworkNo", adNetworkNo);
                                params.put("completed", completed);
                                sendEventToJS("OnVideoMixPlayCompleted", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnVideoMixPlayCompleted", null);
                            }
                        }

                        @Override
                        public void OnVideoMixAdClicked() {
                        }
                    });
                    videoMixAd.loadAd();
                }
            });
        }catch (Exception e){}
    }

    public static void showVideoMix(String appKey, String placementId)
    {
        try{
            activityContext = (Activity) Cocos2dxActivity.getContext();
            activityContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AdPopcornSSPVideoMixAd videoMixAd;
                    if(videoMixAdMap.containsKey(placementId))
                    {
                        videoMixAd = videoMixAdMap.get(placementId);
                        if(activityContext != null && activityContext instanceof Activity)
                            videoMixAd.setCurrentActivity((Activity)activityContext);
                    }
                    else
                    {
                        videoMixAd = new AdPopcornSSPVideoMixAd(activityContext);
                    }
                    if(videoMixAd.isReady()) {
                        videoMixAd.showAd();
                    }
                    else {
                        try {
                            JSONObject params = new JSONObject();
                            params.put("placementId", placementId);
                            sendEventToJS("OnVideoMixAdOpenFailed", params.toString());
                        } catch (Exception e) {
                            sendEventToJS("OnVideoMixAdOpenFailed", null);
                        }
                    }
                }
            });
        }catch (Exception e){}
    }

    public static void openPopContents(String appKey, String placementId)
    {
        try{
            activityContext = (Activity) Cocos2dxActivity.getContext();
            activityContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AdPopcornSSPPopContentsAd popContentsAd;
                    if(popContentsAdMap.containsKey(placementId))
                    {
                        popContentsAd = popContentsAdMap.get(placementId);
                    }
                    else
                    {
                        popContentsAd = new AdPopcornSSPPopContentsAd(activityContext);
                        popContentsAdMap.put(placementId, popContentsAd);
                    }
                    popContentsAd.setPlacementId(placementId);
                    popContentsAd.setPopContentsAdEventCallbackListener(new IPopContentsAdEventCallbackListener() {
                        @Override
                        public void OnPopContentsAdOpened() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnPopContentsAdOpenSuccess", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnPopContentsAdOpenSuccess", null);
                            }
                        }

                        @Override
                        public void OnPopContentsAdOpenFailed(SSPErrorCode sspErrorCode) {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnPopContentsAdOpenFail", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnPopContentsAdOpenFail", null);
                            }
                        }

                        @Override
                        public void OnPopContentsAdClosed() {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("placementId", placementId);
                                sendEventToJS("OnPopContentsAdClosed", params.toString());
                            } catch (Exception e) {
                                sendEventToJS("OnPopContentsAdClosed", null);
                            }
                        }
                    });
                    popContentsAd.openPopContents();
                }
            });
        }catch (Exception e){}
    }

    public static void openRewardAdPlusPage()
    {
        try{
            activityContext = (Activity) Cocos2dxActivity.getContext();
            activityContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AdPopcornSSPRewardAdPlus.openRewardAdPlusPage(activityContext, "1.5");
                }
            });
        }catch (Exception e){}
    }

    public static void getRewardAdPlusUserMediaStatus()
    {
        try{
            activityContext = (Activity) Cocos2dxActivity.getContext();
            activityContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AdPopcornSSPRewardAdPlus.getRewardAdPlusUserStatus(activityContext, null, new IRewardAdPlusUserStatusCallbackListener()
                    {
                        @Override
                        public void OnRewardAdPlusUserMediaStatus(boolean result, int totalBoxCount, List<RewardAdPlusPlacementStatusModel> placementStatusList) {
                            try{
                                JSONArray returnArray = new JSONArray();
                                for(RewardAdPlusPlacementStatusModel placementStatusModel : placementStatusList){
                                    JSONObject object = new JSONObject();
                                    object.put("placementId", placementStatusModel.getPlacementId());
                                    object.put("dailyUserLimit", placementStatusModel.getDailyUserLimit());
                                    object.put("dailyUserCount", placementStatusModel.getDailyUserCount());
                                    returnArray.put(object);
                                }
                                JSONObject params = new JSONObject();
                                params.put("result", result);
                                params.put("totalBoxCount", totalBoxCount);
                                params.put("placementStatusList", returnArray.toString());
                                sendEventToJS("APSSPRewardAdPlusUserMediaStatus", params.toString());
                            }catch (Exception e){}
                        }

                        @Override
                        public void OnRewardAdPlusUserPlacementStatus(boolean result, String placementId, int dailyUserLimit, int dailyUserCount) {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("result", result);
                                params.put("placementId", placementId);
                                params.put("dailyUserLimit", dailyUserLimit);
                                params.put("dailyUserCount", dailyUserCount);
                                sendEventToJS("APSSPRewardAdPlusUserPlacementStatus", params.toString());
                            }catch (Exception e){}
                        }
                    });
                }
            });
        }catch (Exception e){}
    }

    public static void getRewardAdPlusUserPlacementStatus(String placementId)
    {
        try{
            activityContext = (Activity) Cocos2dxActivity.getContext();
            activityContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AdPopcornSSPRewardAdPlus.getRewardAdPlusUserStatus(activityContext, placementId, new IRewardAdPlusUserStatusCallbackListener()
                    {
                        @Override
                        public void OnRewardAdPlusUserMediaStatus(boolean result, int totalBoxCount, List<RewardAdPlusPlacementStatusModel> placementStatusList) {
                            try{
                                JSONArray returnArray = new JSONArray();
                                for(RewardAdPlusPlacementStatusModel placementStatusModel : placementStatusList){
                                    JSONObject object = new JSONObject();
                                    object.put("placementId", placementStatusModel.getPlacementId());
                                    object.put("dailyUserLimit", placementStatusModel.getDailyUserLimit());
                                    object.put("dailyUserCount", placementStatusModel.getDailyUserCount());
                                    returnArray.put(object);
                                }
                                JSONObject params = new JSONObject();
                                params.put("result", result);
                                params.put("totalBoxCount", totalBoxCount);
                                params.put("placementStatusList", returnArray.toString());
                                sendEventToJS("APSSPRewardAdPlusUserMediaStatus", params.toString());
                            }catch (Exception e){}
                        }

                        @Override
                        public void OnRewardAdPlusUserPlacementStatus(boolean result, String placementId, int dailyUserLimit, int dailyUserCount) {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("result", result);
                                params.put("placementId", placementId);
                                params.put("dailyUserLimit", dailyUserLimit);
                                params.put("dailyUserCount", dailyUserCount);
                                sendEventToJS("APSSPRewardAdPlusUserPlacementStatus", params.toString());
                            }catch (Exception e){}
                        }
                    });
                }
            });
        }catch (Exception e){}
    }

    public static void setRewardAdPlusEventListener()
    {
        try{
            activityContext = (Activity) Cocos2dxActivity.getContext();
            activityContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AdPopcornSSPRewardAdPlus.setRewardAdPlusEventListener(new IRewardAdEventCallbackListener() {
                        @Override
                        public void OnClosedRewardAdPlusPage() {
                            try {
                                sendEventToJS("APSSPClosedRewardAdPlusPage", null);
                            }catch (Exception e){}
                        }

                        @Override
                        public void OnEventResult(int resultCode, String resultMessage) {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("resultCode", resultCode);
                                params.put("resultMessage", resultMessage);
                                sendEventToJS("APSSPRewardAdPlusEventResult", params.toString());
                            }catch (Exception e){}
                        }
                    });
                }
            });
        }catch (Exception e){}
    }

    private static void sendEventToJS(final String event, final String paramsJson) {
        if (activityContext == null) return;

        final String js = String.format("if(window.AdPopcornSSPPlugin) { window.AdPopcornSSPPlugin._onNativeEvent('%s', %s); }",
                event, paramsJson != null ? paramsJson : "{}");
        activityContext.runOnUiThread(() -> {
            Cocos2dxActivity activity = (Cocos2dxActivity) activityContext;
            activity.runOnGLThread(() -> {
                Cocos2dxJavascriptJavaBridge.evalString(js);
            });
        });
    }
}
