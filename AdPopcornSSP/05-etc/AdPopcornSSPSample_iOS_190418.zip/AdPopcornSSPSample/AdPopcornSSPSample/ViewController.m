//
//  ViewController.m
//  AdPopcornTestApp
//
//  Created by 김민석 on 2016. 12. 5..
//  Copyright © 2016년 igaworks. All rights reserved.
//

#import "ViewController.h"
#import "AdPopcornSSP/AdPopcornSSPRewardVideoAd.h"

@interface ViewController () <AdPopcornSSPRewardVideoAdDelegate>{
    AdPopcornSSPRewardVideoAd *_sspRewardVideoAd;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _sspRewardVideoAd = [[AdPopcornSSPRewardVideoAd alloc] initWithKey:@"114554353" placementId:@"oel985g2ypygjff" viewController:self];
    //[self setManualMediationSchedule];
    _sspRewardVideoAd.delegate = self;
}

/*- (void)setManualMediationSchedule{
    // 하나 멤버스 용 미디에이션 스케쥴은 아래의 순서대로 적용됨
    // IGAW -> AdMob -> Mintegral -> UnityAds
    // IGAW
    NSDictionary *igawSchedule = [NSDictionary dictionaryWithObjectsAndKeys: @"0", @"AdNetworkNo", @"", @"IntegrationKey", nil];
    
    // AdMob
    NSDictionary *admobIntegrationKeys = [NSDictionary dictionaryWithObjectsAndKeys: @"ca-app-pub-1841010496601800/1595415176", @"adUnitID", nil];
    NSDictionary *admobSchedule = [NSDictionary dictionaryWithObjectsAndKeys: @"1", @"AdNetworkNo", admobIntegrationKeys, @"IntegrationKey", nil];
    
    // Mintegral
    NSDictionary *mintegralIntegrationKeys = [NSDictionary dictionaryWithObjectsAndKeys:@"108971", @"MintegralAppId", @"2f23f5c5f0cc24455e0b5a73067c96ff", @"MintegralAppKey", @"69379", @"MintegralUnitId", @"1", @"MintegralRewardId", nil];
    NSDictionary *mintegralSchedule = [NSDictionary dictionaryWithObjectsAndKeys: @"8", @"AdNetworkNo", mintegralIntegrationKeys, @"IntegrationKey", nil];
    
    // Unity Ads
    NSDictionary *unityAdsIntegrationKeys = [NSDictionary dictionaryWithObjectsAndKeys:@"roulettetv_ios", @"UnityPlacementId", @"2964974", @"UnityGameId", nil];
    NSDictionary *unityAdsSchedule = [NSDictionary dictionaryWithObjectsAndKeys: @"7", @"AdNetworkNo", unityAdsIntegrationKeys, @"IntegrationKey", nil];
    
    NSMutableArray *manualMediationSchedule = [[NSMutableArray alloc] init];
    
    [manualMediationSchedule addObject:igawSchedule];
    [manualMediationSchedule addObject:admobSchedule];
    [manualMediationSchedule addObject:mintegralSchedule];
    [manualMediationSchedule addObject:unityAdsSchedule];
    
    [_sspRewardVideoAd setManualMediationSchedule:manualMediationSchedule];
}*/

- (IBAction)LoadMediationVideo:(id)sender {
    if(![_sspRewardVideoAd isReady])
        [_sspRewardVideoAd loadRequest];
}

- (IBAction)ShowMediationVideo:(id)sender {
    if([_sspRewardVideoAd isReady])
        [_sspRewardVideoAd presentFromViewController:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark AdPopcornSSPRewardVideoAdDelegate
- (void)AdPopcornSSPLoadRewardVideoAdSuccess
{
    NSLog(@"AdPopcornSSPLoadRewardVideoAdSuccess");
}

- (void)AdPopcornSSPLoadRewardVideoAdFailedWithError:(AdPopcornSSPError *)error
{
    NSLog(@"AdPopcornSSPLoadRewardVideoAdFailedWithError : %@", error);
}
- (void)AdPopcornSSPShowRewardVideoAdSuccess
{
    NSLog(@"AdPopcornSSPShowRewardVideoAdSuccess");
}
- (void)AdPopcornSSPShowRewardVideoAdFailed
{
    NSLog(@"AdPopcornSSPShowRewardVideoAdFailed");
}
- (void)AdPopcornSSPRewardVideoAdClosed
{
    NSLog(@"AdPopcornSSPRewardVideoAdClosed");
}

- (void)AdPopcornSSPRewardVideoAdPlayCompletedWithQuantity:(long) quantity Currency:(NSString *)currency
{
    NSLog(@"AdPopcornSSPRewardVideoAdPlayCompletedWithQuantity %ld, %@", quantity, currency);
}

- (void)AdPopcornSSPRewardVideoAdMintegralVideoCompleted:(NSInteger)RewardAmount
{
    NSLog(@"AdPopcornSSPRewardVideoAdMintegralVideoCompleted %ld", RewardAmount);
}

- (void)AdPopcornSSPRewardVideoAdUnityAdsVideoCompleted
{
    NSLog(@"AdPopcornSSPRewardVideoAdUnityAdsVideoCompleted");
}

- (void)AdPopcornSSPRewardVideoAdAdMobVideoCompleted:(double)RewardAmount
{
    NSLog(@"AdPopcornSSPRewardVideoAdAdMobVideoCompleted %f", RewardAmount);
}

@end
