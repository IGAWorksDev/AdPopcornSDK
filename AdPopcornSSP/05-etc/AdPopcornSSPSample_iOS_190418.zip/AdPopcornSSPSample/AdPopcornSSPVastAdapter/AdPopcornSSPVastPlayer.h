//
//  AdPopcornSSPVastPlayer.h
//  AdPopcornSSP
//
//  Created by 김민석 on 2018. 6. 28..
//  Copyright © 2018년 mick. All rights reserved.
//

@import GoogleInteractiveMediaAds;
#import "AdPopcornSSP/AdPopcornSSPVastAdapter.h"

@interface AdPopcornSSPVastPlayer : UIViewController
{
}

@property (nonatomic, weak) id<AdPopcornSSPVastAdapterDelegate> delegate;
@property (nonatomic, strong) NSString* vastAdData;

@end
