//
//  ViewController.m
//  AdPopcornTestApp
//
//  Created by 김민석 on 2016. 12. 5..
//  Copyright © 2016년 igaworks. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <HMRewardVideoMediationDelegate>{
    HMRewardVideoMediation *_hmRewardVideoMediation;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _hmRewardVideoMediation = [[HMRewardVideoMediation alloc] init];
    _hmRewardVideoMediation.delegate = self;
}

- (IBAction)LoadMediationVideo:(id)sender {
    if(![_hmRewardVideoMediation isReady])
        [_hmRewardVideoMediation loadAd];
}

- (IBAction)ShowMediationVideo:(id)sender {
    if([_hmRewardVideoMediation isReady])
        [_hmRewardVideoMediation showAd:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma HMRewardVideoMediationDelegate
- (void) OnRewardVideoAdLoaded
{
    NSLog(@"ViewController OnRewardVideoAdLoaded");
}

- (void) OnRewardVideoAdLoadFailed
{
    NSLog(@"ViewController OnRewardVideoAdLoadFailed");
}
- (void) OnRewardVideoShowSuccess
{
    NSLog(@"ViewController OnRewardVideoShowSuccess");
}
- (void) OnRewardVideoShowFailed
{
    NSLog(@"ViewController OnRewardVideoShowFailed");
}
- (void) OnRewardVideoAdClose
{
    NSLog(@"ViewController OnRewardVideoAdClose");
}
- (void) OnAdPopcornSSPVideoCompleted:(long) quantity
{
    NSLog(@"ViewController OnAdPopcornSSPVideoCompleted");
}
- (void) OnMintegralVideoCompleted:(NSInteger) RewardAmount
{
    NSLog(@"ViewController OnMintegralVideoCompleted");
}
- (void) OnUnityAdsVideoComplete
{
    NSLog(@"ViewController OnUnityAdsVideoComplete");
}
@end
