//
//  ViewController.h
//  AdPopcornTestApp
//
//  Created by 김민석 on 2016. 12. 5..
//  Copyright © 2016년 igaworks. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HMRewardVideoMediation/HMRewardVideoMediation.h"

@interface ViewController : UIViewController


@end

