//
//  AdPopcornSSPVastPlayer.h
//  AdPopcornSSP
//
//  Created by 김민석 on 2018. 6. 28..
//  Copyright © 2018년 mick. All rights reserved.
//

@import GoogleInteractiveMediaAds;
// Using pod install / unity
#import <AdPopcornSSP/AdPopcornSSPVastAdapter.h>
// else
//import "AdPopcornSSPVastAdapter.h"

@interface AdPopcornSSPVastPlayer : UIViewController
{
}

@property (nonatomic, weak) id<AdPopcornSSPVastAdapterDelegate> delegate;
@property (nonatomic, strong) NSString* vastAdData;

@end
