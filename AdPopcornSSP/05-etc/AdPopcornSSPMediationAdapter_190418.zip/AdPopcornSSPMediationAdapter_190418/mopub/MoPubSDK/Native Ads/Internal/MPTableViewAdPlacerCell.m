//
//  MPTableViewAdPlacerCell.m
//  MoPubSDK
//
//  Copyright (c) 2015 MoPub. All rights reserved.
//

#import "MPTableViewAdPlacerCell.h"

@implementation MPTableViewAdPlacerCell

@end
