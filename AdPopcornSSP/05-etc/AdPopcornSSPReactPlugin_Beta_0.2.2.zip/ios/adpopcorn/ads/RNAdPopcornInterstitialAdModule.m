//
//  RNAdPopcornInterstitialAdModule.m
//  AdPopcornSSPReactPlugin
//
//  Created by 김민석 on 2023/05/18.
//


#import <Foundation/Foundation.h>
#import "RNAdPopcornInterstitialAdModule.h"

@implementation RNAdPopcornInterstitialAdModule

RCT_EXPORT_MODULE(RNAdPopcornInterstitialAdModule)

@synthesize dictionary = _dictionary;
- (NSArray<NSString*>*)supportedEvents
{
  return @[@"OnInterstitialLoaded", @"OnInterstitialReceiveFailed", @"OnInterstitialOpened", @"OnInterstitialOpenFailed", @"OnInterstitialClosed", @"OnInterstitialClicked"];
}

RCT_EXPORT_METHOD(createInstance:(NSString *)appKey placementId:(NSString *)placementId)
{
  if(_dictionary == nil)
  {
    _dictionary = [[NSMutableDictionary alloc] init];
  }
  
  if([_dictionary objectForKey:placementId])
  {
    NSLog(@"createInstance already exist rewardVideoAd placementId : %@", placementId);
    [_dictionary removeObjectForKey:placementId];
  }
  else
  {
    NSLog(@"createInstance rewardVideoAd placementId : %@", placementId);
  }
  
  AdPopcornSSPInterstitialAd *interstitialAd = [[AdPopcornSSPInterstitialAd alloc] initWithKey:appKey placementId:placementId viewController:[[[[UIApplication sharedApplication] delegate] window] rootViewController]];
  interstitialAd.placementId = placementId;
  [_dictionary setObject:interstitialAd forKey:placementId];
}

RCT_EXPORT_METHOD(loadAd:(NSString *)placementId)
{
  NSLog(@"interstitialAd loadAd : %@", placementId);
  if(_dictionary == nil || [_dictionary objectForKey:placementId] == nil)
    return;
  AdPopcornSSPInterstitialAd *interstitialAd = [_dictionary objectForKey:placementId];
  if(interstitialAd)
  {
    interstitialAd.delegate = self;
    [interstitialAd loadRequest];
  }
}

RCT_EXPORT_METHOD(showAd:(NSString *)placementId)
{
  NSLog(@"interstitialAd showAd : %@", placementId);
  if(_dictionary == nil || [_dictionary objectForKey:placementId] == nil)
    return;
  AdPopcornSSPInterstitialAd *interstitialAd = [_dictionary objectForKey:placementId];
  if(interstitialAd)
  {
    // UI관련 작업을 main스레드에서 실행
    dispatch_async(dispatch_get_main_queue(), ^{
      interstitialAd.delegate = self;
      [interstitialAd presentFromViewController:[UIApplication sharedApplication].delegate.window.rootViewController];
    });
  }
}

#pragma mark APSSPInterstitialAdDelegate
/*!
 @abstract
 intersitial 광고 load 완료시(성공시), 호출된다.
 */
- (void)APSSPInterstitialAdLoadSuccess:(AdPopcornSSPInterstitialAd *)interstitialAd
{
  NSLog(@"interstitialAd APSSPInterstitialAdLoadSuccess : %@", interstitialAd.placementId);
  [self sendEventWithName:@"OnInterstitialLoaded" body:@{@"placementId": interstitialAd.placementId}];
}

/*!
 @abstract
 intersitial 광고 load 실패시, 호출된다.
 */
- (void)APSSPInterstitialAdLoadFail:(AdPopcornSSPInterstitialAd *)interstitialAd error:(AdPopcornSSPError *)error
{
  NSLog(@"interstitialAd APSSPInterstitialAdLoadFail : %@", interstitialAd.placementId);
  [self sendEventWithName:@"OnInterstitialReceiveFailed" body:(@{
    @"errorCode": @(error.code),
    @"errorMessage": error.userInfo.description,
    @"placementId": interstitialAd.placementId
  })];
}

/*!
 @abstract
 intersitial 광고 close시, 호출된다.
 */
- (void)APSSPInterstitialAdClosed:(AdPopcornSSPInterstitialAd *)interstitialAd
{
  NSLog(@"interstitialAd APSSPInterstitialAdClosed : %@", interstitialAd.placementId);
  [self sendEventWithName:@"OnInterstitialClosed" body:@{@"placementId": interstitialAd.placementId}];
}

/*!
 @abstract
 intersitial 광고 클릭시, 호출된다.
 */
- (void)APSSPInterstitialAdClicked:(AdPopcornSSPInterstitialAd *)interstitialAd
{
  NSLog(@"interstitialAd APSSPInterstitialAdClicked : %@", interstitialAd.placementId);
  [self sendEventWithName:@"OnInterstitialClicked" body:@{@"placementId": interstitialAd.placementId}];
}

/*!
 @abstract
 intersitial 광고 show 완료시(성공시), 호출된다.
 */
- (void)APSSPInterstitialAdShowSuccess:(AdPopcornSSPInterstitialAd *)interstitialAd
{
  NSLog(@"interstitialAd APSSPInterstitialAdShowSuccess : %@", interstitialAd.placementId);
  [self sendEventWithName:@"OnInterstitialOpened" body:@{@"placementId": interstitialAd.placementId}];
}

/*!
 @abstract
 intersitial 광고 show 실패시, 호출된다.
 */
- (void)APSSPInterstitialAdShowFail:(AdPopcornSSPInterstitialAd *)interstitialAd error:(AdPopcornSSPError *)error
{
  NSLog(@"interstitialAd APSSPInterstitialAdShowFail : %@", interstitialAd.placementId);
  [self sendEventWithName:@"OnInterstitialOpenFailed" body:(@{
    @"errorCode": @(error.code),
    @"errorMessage": error.userInfo.description,
    @"placementId": interstitialAd.placementId
  })];
}
@end
