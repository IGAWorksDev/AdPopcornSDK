//
//  RNAdPopcornBannerViewManager.m
//  AdPopcornSSPReactPlugin
//
//  Created by 김민석 on 2023/05/17.
//

#import <Foundation/Foundation.h>
#import "RNAdPopcornBannerView.h"

@interface RNAdPopcornBannerViewManager : RCTViewManager
@end

@implementation RNAdPopcornBannerViewManager

RCT_EXPORT_MODULE(RNAdPopcornBannerView);

- (UIView *)view
{
  RNAdPopcornBannerView *bannerView = [RNAdPopcornBannerView new];
  return bannerView;
}

RCT_EXPORT_VIEW_PROPERTY(appKey, NSString)
RCT_EXPORT_VIEW_PROPERTY(placementId, NSString)
RCT_EXPORT_VIEW_PROPERTY(adSize, NSString)
RCT_EXPORT_VIEW_PROPERTY(refreshTime, NSInteger)
RCT_EXPORT_VIEW_PROPERTY(networkScheduleTimeout, NSInteger)
RCT_EXPORT_VIEW_PROPERTY(bannerAnimType, NSString)
RCT_EXPORT_VIEW_PROPERTY(autoBgColor, BOOL)

RCT_EXPORT_VIEW_PROPERTY(onBannerAdReceiveSuccess, RCTDirectEventBlock)
RCT_EXPORT_VIEW_PROPERTY(onBannerAdReceiveFailed, RCTDirectEventBlock)
RCT_EXPORT_VIEW_PROPERTY(onBannerAdClicked, RCTDirectEventBlock)

@end
