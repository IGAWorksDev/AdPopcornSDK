//
//  RNAdPopcornRewardVideoAdModule.h
//  AdPopcornSSPReactPlugin
//
//  Created by 김민석 on 2023/05/17.
//

#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>
#import <UIKit/UIKit.h>
#import <AdPopcornSSP/AdPopcornSSPRewardVideoAd.h>

@interface RNAdPopcornRewardVideoAdModule : RCTEventEmitter<RCTBridgeModule, APSSPRewardVideoAdDelegate>
{
  
}

@property (retain, nonatomic) NSMutableDictionary *dictionary;

@end
