package com.igaworks.adpopcornhybrid;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.igaworks.ssp.AdPopcornSSP;
import com.igaworks.ssp.CustomAdType;
import com.igaworks.ssp.SSPErrorCode;
import com.igaworks.ssp.part.banner.AdPopcornSSPBannerAd;
import com.igaworks.ssp.part.banner.listener.IBannerEventCallbackListener;
import com.igaworks.ssp.part.custom.AdPopcornSSPCustomAd;
import com.igaworks.ssp.part.custom.listener.ICustomAdListener;
import com.igaworks.ssp.part.nativead.AdPopcornSSPNativeAd;
import com.igaworks.ssp.part.nativead.listener.INativeAdEventCallbackListener;
import com.igaworks.ssp.part.video.AdPopcornSSPRewardVideoAd;
import com.igaworks.ssp.part.video.listener.IRewardVideoAdEventCallbackListener;

public class AdPopcornJSBridge {
    public final static String INTERFACE_NAME = "adpopcornJSBridge";
    private Context context;
    private WebView webView;
    private Activity mainActivity;

    private AdPopcornSSPCustomAd customBannerAd, customNativeAd;
    private AdPopcornSSPRewardVideoAd rewardVideoAd;

    public AdPopcornJSBridge(Context context, Activity mainActivity, WebView webView) {
        this.context = context;
        this.mainActivity = mainActivity;
        this.webView = webView;
    }

    /* 애드팝콘 SSP 리워드 비디오 연동 시, 기본적으로 사용하는 init, destroy, load, show API 이외에 추가로 더 필요한 기능이 있다면
       아래와 동일한 방식으로 JavascriptInterface 추가하여 사용.*/

    // SSP SDK 초기화(앱 시작 시 1번)
    @JavascriptInterface
    public void init() {
        try {
            Log.d("AdPopcornJSBridge", "init");
            AdPopcornSSP.init(context);
        }catch(Exception e){}
    }

    // SSP SDK 해제 (앱 종료 시)
    @JavascriptInterface
    public void destroy() {
        try {
            Log.d("AdPopcornJSBridge", "destroy");
            AdPopcornSSP.destroy();
        }catch(Exception e){}
    }

    // custom banner
    @JavascriptInterface
    public void createCustomBanner(String placementId) {
        try {
            Log.d("AdPopcornJSBridge", "createCustomBanner");
            if(customBannerAd == null){
                customBannerAd = new AdPopcornSSPCustomAd(context);
                customBannerAd.setPlacementId(placementId);
                customBannerAd.setAdType(CustomAdType.BANNER_320x50);
                customBannerAd.setCustomAdEventCallbackListener(new ICustomAdListener() {
                    @Override
                    public void OnCustomAdReceiveSuccess(String placementId, String adData) {

                    }

                    @Override
                    public void OnCustomAdReceiveFailed(String placementId, SSPErrorCode sspErrorCode) {

                    }
                });
            }
        }catch(Exception e){}
    }

    @JavascriptInterface
    public void loadCustomBanner() {
        try {
            Log.d("AdPopcornJSBridge", "loadCustomBanner");
            if(customBannerAd != null){
                customNativeAd.loadAd();
            }
        }catch(Exception e){}
    }

    @JavascriptInterface
    public void impressionCustomBanner() {
        try {
            Log.d("AdPopcornJSBridge", "impressionCustomBanner");
            if(customBannerAd != null){
                customBannerAd.reportImpression();
            }
        }catch(Exception e){}
    }

    @JavascriptInterface
    public void clickCustomBanner() {
        try {
            Log.d("AdPopcornJSBridge", "clickCustomBanner");
            if(customBannerAd != null){
                customBannerAd.reportClick();
            }
        }catch(Exception e){}
    }

    // custom native
    @JavascriptInterface
    public void createCustomNative(String placementId) {
        try {
            Log.d("AdPopcornJSBridge", "createCustomNative");
            if(customNativeAd == null){
                customNativeAd = new AdPopcornSSPCustomAd(context);
                customNativeAd.setPlacementId(placementId);
                customNativeAd.setAdType(CustomAdType.NATIVE_AD);
                customNativeAd.setCustomAdEventCallbackListener(new ICustomAdListener() {
                    @Override
                    public void OnCustomAdReceiveSuccess(String placementId, String adData) {
                        Log.d("AdPopcornJSBridge", "OnCustomAdReceiveSuccess : " + adData);
                        webView.loadUrl("javascript:OnCustomAdReceiveSuccess('" + adData + "'" + ")");
                    }

                    @Override
                    public void OnCustomAdReceiveFailed(String placementId, SSPErrorCode sspErrorCode) {
                        webView.loadUrl("javascript:OnCustomAdReceiveSuccess('" + sspErrorCode + "'" + ")");
                    }
                });
            }
        }catch(Exception e){}
    }

    @JavascriptInterface
    public void loadCustomNative() {
        try {
            Log.d("AdPopcornJSBridge", "loadCustomNative");
            if(customNativeAd != null){
                customNativeAd.loadAd();
            }
        }catch(Exception e){}
    }

    @JavascriptInterface
    public void impressionCustomNative() {
        try {
            Log.d("AdPopcornJSBridge", "impressionCustomNative");
            if(customNativeAd != null){
                customNativeAd.reportImpression();
            }
        }catch(Exception e){}
    }

    @JavascriptInterface
    public void clickCustomNative() {
        try {
            Log.d("AdPopcornJSBridge", "clickCustomNative");
            if(customNativeAd != null){
                customNativeAd.reportClick();
            }
        }catch(Exception e){}
    }
}
