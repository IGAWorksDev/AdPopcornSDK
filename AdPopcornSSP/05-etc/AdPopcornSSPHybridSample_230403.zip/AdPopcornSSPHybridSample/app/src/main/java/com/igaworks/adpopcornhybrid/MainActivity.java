package com.igaworks.adpopcornhybrid;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

import com.igaworks.ssp.AdPopcornSSP;
import com.igaworks.ssp.AdSize;
import com.igaworks.ssp.part.banner.AdPopcornSSPBannerAd;
import com.igaworks.ssp.part.nativead.AdPopcornSSPNativeAd;
import com.igaworks.ssp.part.nativead.binder.AdFitViewBinder;
import com.igaworks.ssp.part.nativead.binder.AdPopcornSSPViewBinder;
import com.igaworks.ssp.part.nativead.binder.NAMViewBinder;

public class MainActivity extends Activity {
    private WebView hybridWebView;

    // 일반 배너, 네이티브 연동 : 앱 내 layer 형태로 광고 노출을 위한 instance
    private AdPopcornSSPNativeAd nativeAd;

    private final String NATIVE_PLACEMENT_ID = "mwme83onKgAqmwH";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AdPopcornSSP.init(this);
        hybridWebView = (WebView) findViewById(R.id.hybrid_webview);

        // Javascript 사용 여부
        hybridWebView.getSettings().setJavaScriptEnabled(true);
        // AdPopcornJSBridge 등록 : 여기서 등록한 이름을 가지고 html의 javascript에서 호출(index.html 참고)
        hybridWebView.addJavascriptInterface(new AdPopcornJSBridge(this, this, hybridWebView), AdPopcornJSBridge.INTERFACE_NAME);

        hybridWebView.loadUrl("file:///android_asset/www/index.html");

        // 일반 배너 혹은 네이티브를 layer 형태로 띄울 때에는 띄우고자 하는 Activity에 선언하여 영역을 잡아주면 됩니다.

        // 네이티브
        nativeAd = (AdPopcornSSPNativeAd) findViewById(R.id.igaw_native_ad);
        nativeAd.setPlacementId(NATIVE_PLACEMENT_ID);

        /* 미디에이션
         애드팝콘, NAM, Adfit 사용하는 지면에 따라서 아래 내용 세팅 여부가 달라집니다.
         nativeAd 지면의 미디에이션 운영 방식에 따라 아래 ViewBinder를 각각 세팅해 주시기 바랍니다.
        */

        // 애드팝콘
        AdPopcornSSPViewBinder adPopcornSSPViewBinder = new AdPopcornSSPViewBinder.Builder(R.id.adpopcornssp_native_ad_template)
                .useTemplate(true)
                .build();
        nativeAd.setAdPopcornSSPViewBinder(adPopcornSSPViewBinder);

        // NAM
        NAMViewBinder namSimpleViewBinder = new NAMViewBinder.Builder(R.id.gfp_native_simple_ad, 0)
                .useNativeSimpleView(true)
                .build();
        nativeAd.setNamViewBinder(namSimpleViewBinder);

        // Adfit
        AdFitViewBinder adFitViewBinder = new AdFitViewBinder.Builder(R.id.adFitNativeAdView)
                .bizBoardAd(true)
                .build();
        nativeAd.setAdFitViewBinder(adFitViewBinder);
        nativeAd.loadAd();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}


