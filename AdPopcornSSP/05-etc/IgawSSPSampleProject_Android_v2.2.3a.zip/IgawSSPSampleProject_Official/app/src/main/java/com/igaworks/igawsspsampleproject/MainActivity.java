package com.igaworks.igawsspsampleproject;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.igaworks.ssp.AdSize;
import com.igaworks.ssp.IgawSSP;
import com.igaworks.ssp.SSPErrorCode;
import com.igaworks.ssp.part.banner.IgawBannerAd;
import com.igaworks.ssp.part.banner.listener.IBannerEventCallbackListener;
import com.igaworks.ssp.part.interstitial.InterstitialAd;
import com.igaworks.ssp.part.interstitial.listener.IInterstitialEventCallbackListener;
import com.igaworks.ssp.part.nativead.IgawNativeAd;
import com.igaworks.ssp.part.nativead.binder.AdMobViewBinder;
import com.igaworks.ssp.part.nativead.binder.IgawViewBinder;
import com.igaworks.ssp.part.nativead.binder.MintegralViewBinder;
import com.igaworks.ssp.part.nativead.listener.INativeAdEventCallbackListener;
import com.igaworks.ssp.part.video.IgawInterstitialVideoAd;
import com.igaworks.ssp.part.video.IgawRewardVideoAd;
import com.igaworks.ssp.part.video.listener.IInterstitialVideoAdEventCallbackListener;
import com.igaworks.ssp.part.video.listener.IRewardVideoAdEventCallbackListener;


public class MainActivity extends Activity {
    private IgawRewardVideoAd igawRewardVideoAd;
    private IgawBannerAd igawBannerAd_320x50, igawBannerAd_320x100, igawBannerAd_300x250;
    private InterstitialAd igawInterstitialAd;
    private IgawNativeAd igawNativeAd, igawMediationNativeAd;
    private IgawInterstitialVideoAd igawInterstitialVideoAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* 주의 사항
            샘플에서 사용하고 있는 placement ID 값은 반드시 애드팝콘에서 발급받은 키로 변경하여 사용하여야 합니다.
            기타 자세한 사항 및 최신 SDK는 애드팝콘 SSP 가이드 페이지를 참고해 주시기 바랍니다
        */

        // 1. IgawSSP SDK 초기화
        IgawSSP.init(MainActivity.this);

        // 2. Banner 320x50
        igawBannerAd_320x50 = findViewById(R.id.banner_container);
        igawBannerAd_320x50.setAdSize(AdSize.BANNER_320x50);
        igawBannerAd_320x50.setPlacementId("1z8ozfc8d6ue99e");
        igawBannerAd_320x50.setBannerEventCallbackListener(new IBannerEventCallbackListener() {
            @Override
            public void OnBannerAdReceiveSuccess() {
                Log.i("IgawSSPTestApp", "320x50 OnBannerAdReceiveSuccess");
                Toast.makeText(MainActivity.this, "OnBannerAdReceiveSuccess : " + igawBannerAd_320x50.getCurrentNetwork(), Toast.LENGTH_SHORT).show();
                igawBannerAd_320x50.setVisibility(View.VISIBLE);
            }

            @Override
            public void OnBannerAdReceiveFailed(SSPErrorCode errorCode) {
                Log.i("IgawSSPTestApp", "320x50 BannerOnBannerAdReceiveFailed : " + errorCode.getErrorMessage());
                Toast.makeText(MainActivity.this, "OnBannerAdReceiveFailed : " + errorCode.getErrorCode() + ", " + errorCode.getErrorMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        Button button_load_banner1 = findViewById(R.id.button_banner1_load);
        button_load_banner1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(igawBannerAd_320x50 != null)
                    igawBannerAd_320x50.loadAd();
            }
        });

        Button button_stop_banner1 = findViewById(R.id.button_banner1_stop);
        button_stop_banner1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(igawBannerAd_320x50 != null)
                    igawBannerAd_320x50.stopAd();
            }
        });

        // 3. Banner 320x100
        igawBannerAd_320x100 = findViewById(R.id.banner_container_2);
        igawBannerAd_320x100.setAdSize(AdSize.BANNER_320x100);
        igawBannerAd_320x100.setPlacementId("f5w8b647h3roq96");
        igawBannerAd_320x100.setBannerEventCallbackListener(new IBannerEventCallbackListener() {
            @Override
            public void OnBannerAdReceiveSuccess() {
                Log.i("IgawSSPTestApp", "320x100 OnBannerAdReceiveSuccess");
                Toast.makeText(MainActivity.this, "OnBannerAdReceiveSuccess : " + igawBannerAd_320x100.getCurrentNetwork(), Toast.LENGTH_SHORT).show();
                igawBannerAd_320x100.setVisibility(View.VISIBLE);
            }

            @Override
            public void OnBannerAdReceiveFailed(SSPErrorCode errorCode) {
                Log.i("IgawSSPTestApp", "320x100 BannerOnBannerAdReceiveFailed : " + errorCode.getErrorMessage());
                Toast.makeText(MainActivity.this, "OnBannerAdReceiveFailed : " + errorCode.getErrorCode() + ", " + errorCode.getErrorMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        Button button_load_banner2 = findViewById(R.id.button_banner2_load);
        button_load_banner2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(igawBannerAd_320x100 != null)
                    igawBannerAd_320x100.loadAd();
            }
        });

        Button button_stop_banner2 = findViewById(R.id.button_banner2_stop);
        button_stop_banner2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(igawBannerAd_320x100 != null)
                    igawBannerAd_320x100.stopAd();
            }
        });

        // 4. Banner 300x250
        igawBannerAd_300x250 = findViewById(R.id.banner_container_3);
        igawBannerAd_300x250.setAdSize(AdSize.BANNER_300x250);
        igawBannerAd_300x250.setPlacementId("ebbkwz53as764h3");
        igawBannerAd_300x250.setBannerEventCallbackListener(new IBannerEventCallbackListener() {
            @Override
            public void OnBannerAdReceiveSuccess() {
                Log.i("IgawSSPTestApp", "300x250 OnBannerAdReceiveSuccess");
                Toast.makeText(MainActivity.this, "OnBannerAdReceiveSuccess : " + igawBannerAd_300x250.getCurrentNetwork(), Toast.LENGTH_SHORT).show();
                igawBannerAd_300x250.setVisibility(View.VISIBLE);
            }

            @Override
            public void OnBannerAdReceiveFailed(SSPErrorCode errorCode) {
                Log.i("IgawSSPTestApp", "300x250 BannerOnBannerAdReceiveFailed : " + errorCode.getErrorMessage());
                Toast.makeText(MainActivity.this, "OnBannerAdReceiveFailed : " + errorCode.getErrorCode() + ", " + errorCode.getErrorMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        Button button_load_banner3 = findViewById(R.id.button_banner3_load);
        button_load_banner3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(igawBannerAd_300x250 != null)
                    igawBannerAd_300x250.loadAd();
            }
        });

        Button button_stop_banner3 = findViewById(R.id.button_banner3_stop);
        button_stop_banner3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(igawBannerAd_300x250 != null)
                    igawBannerAd_300x250.stopAd();
            }
        });

        // 5. interstitialAd
        igawInterstitialAd = new InterstitialAd(this);
        igawInterstitialAd.setPlacementId("5jb921hjk4j2k4b"); //c7aby1utd7711vh, gas8hhq4hme18is

        igawInterstitialAd.setInterstitialEventCallbackListener(new IInterstitialEventCallbackListener() {
            @Override
            public void OnInterstitialLoaded() {
                Log.i("IgawSSPTestApp", "OnInterstitialLoaded");
                Toast.makeText(MainActivity.this, "OnInterstitialLoaded : " + igawInterstitialAd.getCurrentNetwork(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void OnInterstitialOpened() {
                Log.i("IgawSSPTestApp", "OnInterstitialOpened");
                Toast.makeText(MainActivity.this, "OnInterstitialOpened", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void OnInterstitialReceiveFailed(SSPErrorCode errorCode) {
                Log.i("IgawSSPTestApp", "OnInterstitialReceiveFailed : " + errorCode.getErrorCode() + ", errorMessage : " + errorCode.getErrorMessage());
                Toast.makeText(MainActivity.this, "OnInterstitialReceiveFailed : " + errorCode.getErrorCode() + ", errorMessage : " + errorCode.getErrorMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void OnInterstitialOpenFailed(SSPErrorCode errorCode) {
                Log.i("IgawSSPTestApp", "OnInterstitialOpenFailed : " + errorCode.getErrorCode() + ", errorMessage : " + errorCode.getErrorMessage());
                Toast.makeText(MainActivity.this, "OnInterstitialOpenFailed : " + errorCode.getErrorCode() + ", errorMessage : " + errorCode.getErrorMessage(), Toast.LENGTH_SHORT).show();
            }


            @Override
            public void OnInterstitialClosed(int closeEvent) {
                Log.i("IgawSSPTestApp", "OnInterstitialClosed : " + closeEvent);
                if(closeEvent == InterstitialAd.CloseEvent.UNKNOWN)
                    Toast.makeText(MainActivity.this, "OnInterstitialClosed : unknwon", Toast.LENGTH_SHORT).show();
                else if(closeEvent == InterstitialAd.CloseEvent.CLICK_CLOSE_BTN)
                    Toast.makeText(MainActivity.this, "OnInterstitialClosed : click close btn", Toast.LENGTH_SHORT).show();
                else if(closeEvent == InterstitialAd.CloseEvent.PRESSED_BACK_KEY)
                    Toast.makeText(MainActivity.this, "OnInterstitialClosed : pressed back key", Toast.LENGTH_SHORT).show();
            }
        });

        Button button_load_interstitial = findViewById(R.id.button_interstitial_load);
        button_load_interstitial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(igawInterstitialAd != null)
                    igawInterstitialAd.loadAd();
            }
        });

        Button button_show_interstitial = findViewById(R.id.button_interstitial_show);
        button_show_interstitial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(igawInterstitialAd != null && igawInterstitialAd.isLoaded())
                    igawInterstitialAd.showAd();
                else
                    Toast.makeText(MainActivity.this, "InterstitialAd is not loaded", Toast.LENGTH_SHORT).show();
            }
        });


        // 6.Reward Video
        igawRewardVideoAd = new IgawRewardVideoAd(this);
        igawRewardVideoAd.setPlacementId("4h774k1f2kaw4xa");
        igawRewardVideoAd.setRewardVideoAdEventCallbackListener(iRewardVideoAdEventCallbackListener);
        Button button_reward_video_load = findViewById(R.id.button_reward_video_load);
        button_reward_video_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(igawRewardVideoAd != null)
                    igawRewardVideoAd.loadAd();
            }
        });

        Button button_reward_video_show = findViewById(R.id.button_reward_video_show);
        button_reward_video_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(igawRewardVideoAd != null && igawRewardVideoAd.isReady())
                    igawRewardVideoAd.showAd();
                else
                    Toast.makeText(MainActivity.this, "RewardVideo is not loaded", Toast.LENGTH_SHORT).show();
            }
        });


        // 8. Native Ad(SSP Mediation, 샘플로 admob, mintegral mediation만 제공)
        // admob, mintegral 이외의 업체 코드는 가이드 페이지의 샘플 코드를 참고.
        igawMediationNativeAd = (IgawNativeAd) findViewById(R.id.igaw_mediation_native_ad);
        igawMediationNativeAd.setPlacementId("8n12virz5gmkwqr");

        IgawViewBinder igawMediationViewBinder = new IgawViewBinder.Builder(R.id.igaw_native_ad_view)
                .iconImageViewId(R.id.igaw_native_ad_icon_image1)
                .descViewId(R.id.igaw_native_ad_desc1)
                .mainImageViewId(R.id.igaw_native_ad_main_image1)
                .titleViewId(R.id.igaw_native_ad_title1)
                .callToActionId(R.id.igaw_native_ad_ctatext1)
                .build();

        igawMediationNativeAd.setIgawViewBinder(igawMediationViewBinder);

        AdMobViewBinder adMobViewBinder = new AdMobViewBinder.Builder(R.id.admob_unified_native_ad_view, R.layout.admob_native_ad_unit_layout)
                .iconViewId(R.id.admob_ad_app_icon)
                .headlineViewId(R.id.admob_ad_headline)
                .bodyViewId(R.id.admob_ad_body)
                .mediaViewId(R.id.admob_ad_media)
                .callToActionId(R.id.admob_ad_call_to_action)
                .advertiserViewId(R.id.admob_ad_advertiser)
                .priceViewId(R.id.admob_ad_price)
                .starRatingViewId(R.id.admob_ad_stars)
                .storeViewId(R.id.admob_ad_store)
                .build();
        igawMediationNativeAd.setAdMobViewBinder(adMobViewBinder);

        MintegralViewBinder mintegralViewBinder = new MintegralViewBinder.Builder(R.id.mintegral_native_ad_view, R.layout.mintegral_native_ad_unit_layout)
                .mainImageViewId(R.id.mintegral_native_main_image)
                .iconViewId(R.id.mintegral_native_icon_image)
                .titleViewId(R.id.mintegral_native_title)
                .descViewId(R.id.mintegral_native_text)
                .adCallViewId(R.id.mintegral_native_cta)
                .adChoiceViewId(R.id.mintegral_ad_choice_image)
                .build();
        igawMediationNativeAd.setMintegralViewBinder(mintegralViewBinder);

        igawMediationNativeAd.setNativeAdEventCallbackListener(new INativeAdEventCallbackListener() {
            @Override
            public void onNativeAdLoadSuccess() {
                Log.i("IgawSSPTestApp", "Mediation NativeAd onNativeAdLoadSuccess : " + igawMediationNativeAd.isLoaded());
                Toast.makeText(MainActivity.this, "onNativeAdLoadSuccess", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNativeAdLoadFailed(SSPErrorCode errorCode) {
                Log.i("IgawSSPTestApp", "Mediation NativeAd onNativeAdLoadFailed : " + igawMediationNativeAd.isLoaded() +  " errorCode : " + errorCode.getErrorMessage());
                Toast.makeText(MainActivity.this, "onNativeAdLoadFailed : " + errorCode.getErrorCode() + ", " + errorCode.getErrorMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onImpression() {
                Log.i("IgawSSPTestApp", "Mediation NativeAd onImpression");
                Toast.makeText(MainActivity.this, "onImpression", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onClicked() {
                Log.i("IgawSSPTestApp", "Mediation NativeAd onClicked");
                Toast.makeText(MainActivity.this, "onClicked", Toast.LENGTH_SHORT).show();
            }
        });

        Button button_mediation_native_ad_load = (Button) findViewById(R.id.button_mediation_native_ad_load);
        button_mediation_native_ad_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                igawMediationNativeAd.loadAd();
            }
        });

        // 9. Interstitial Video
        igawInterstitialVideoAd = new IgawInterstitialVideoAd(this);
        igawInterstitialVideoAd.setPlacementId("bgm0vw0343rzvxt");
        igawInterstitialVideoAd.setEventCallbackListener(interstitialVideoAdEventCallbackListener);
        Button button_interstitial_video_load = findViewById(R.id.button_interstitial_video_load);
        button_interstitial_video_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(igawInterstitialVideoAd != null)
                    igawInterstitialVideoAd.loadAd();
            }
        });

        Button button_interstitial_video_show = findViewById(R.id.button_interstitial_video_show);
        button_interstitial_video_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(igawInterstitialVideoAd != null && igawInterstitialVideoAd.isReady())
                    igawInterstitialVideoAd.showAd();
                else
                    Toast.makeText(MainActivity.this, "Interstitial VideoAd is not loaded", Toast.LENGTH_SHORT).show();
            }
        });
    }

    IRewardVideoAdEventCallbackListener iRewardVideoAdEventCallbackListener = new IRewardVideoAdEventCallbackListener() {
        @Override
        public void OnRewardVideoAdLoaded() {
            // 광고 로드 성공
            Toast.makeText(MainActivity.this, "OneButton OnRewardVideoAdLoaded", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OneButton OnRewardVideoAdLoaded");
        }

        @Override
        public void OnRewardVideoAdLoadFailed(SSPErrorCode sspErrorCode) {
            // 광고 로드 실패
            Toast.makeText(MainActivity.this, "OnRewardVideoAdLoadFailed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdLoadFailed");
        }

        @Override
        public void OnRewardVideoAdOpened() {
            Toast.makeText(MainActivity.this, "OnRewardVideoShowSuccess", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoShowSuccess");
        }

        @Override
        public void OnRewardVideoAdOpenFalied() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed");
        }

        @Override
        public void OnRewardVideoAdClosed() {
            Toast.makeText(MainActivity.this, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed");
        }

        @Override
        public void OnRewardVideoPlayCompleted(int networkId, boolean completed) {
            Toast.makeText(MainActivity.this, "OnRewardVideoPlayCompleted : " + networkId + ", " +
                            "completed : " + completed,
                    Toast.LENGTH_SHORT).show();
            Log.i("IgawSSPSample", "OnRewardVideoPlayCompleted : " + networkId + ", " +
                    "completed : " + completed);
            onCompletedRewardVideoAd();
        }
    };

    IInterstitialVideoAdEventCallbackListener interstitialVideoAdEventCallbackListener = new IInterstitialVideoAdEventCallbackListener() {
        @Override
        public void OnInterstitialVideoAdLoaded() {

        }

        @Override
        public void OnInterstitialVideoAdLoadFailed(SSPErrorCode sspErrorCode) {

        }

        @Override
        public void OnInterstitialVideoAdOpened() {

        }

        @Override
        public void OnInterstitialVideoAdOpenFalied() {

        }

        @Override
        public void OnInterstitialVideoAdClosed() {

        }
    };

    private void onCompletedRewardVideoAd(){
        // 리워드 비디오가 정상적으로 종료 되었을 때 처리.
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 8. Activity Life cycle에 맞춰 onResume 연동
        if(igawBannerAd_320x50 != null)
            igawBannerAd_320x50.onResume();
        if(igawBannerAd_320x100 != null)
            igawBannerAd_320x100.onResume();
        if(igawBannerAd_300x250 != null)
            igawBannerAd_300x250.onResume();
        if(igawRewardVideoAd != null)
            igawRewardVideoAd.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 9. Activity Life cycle에 맞춰 onResume 연동
        if(igawBannerAd_320x50 != null)
            igawBannerAd_320x50.onPause();
        if(igawBannerAd_320x100 != null)
            igawBannerAd_320x100.onPause();
        if(igawBannerAd_300x250 != null)
            igawBannerAd_300x250.onPause();
        if(igawRewardVideoAd != null)
            igawRewardVideoAd.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 9. 종료.
        if(igawRewardVideoAd != null)
            igawRewardVideoAd.destroy();
        if(igawNativeAd != null)
            igawNativeAd.destroy();
        IgawSSP.destroy();
    }
}


