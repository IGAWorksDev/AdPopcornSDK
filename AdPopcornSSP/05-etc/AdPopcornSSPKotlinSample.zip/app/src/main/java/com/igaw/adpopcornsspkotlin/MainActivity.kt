package com.igaw.adpopcornsspkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import com.igaworks.ssp.AdPopcornSSP

import com.igaworks.ssp.AdSize
import com.igaworks.ssp.SSPErrorCode
import com.igaworks.ssp.SdkInitListener
import com.igaworks.ssp.part.banner.AdPopcornSSPBannerAd
import com.igaworks.ssp.part.banner.listener.IBannerEventCallbackListener
import com.igaworks.ssp.part.interstitial.AdPopcornSSPInterstitialAd
import com.igaworks.ssp.part.interstitial.listener.IInterstitialEventCallbackListener
import com.igaworks.ssp.part.nativead.AdPopcornSSPNativeAd
import com.igaworks.ssp.part.nativead.binder.AdMobViewBinder
import com.igaworks.ssp.part.nativead.binder.AdPopcornSSPViewBinder
import com.igaworks.ssp.part.nativead.listener.INativeAdEventCallbackListener
import com.igaworks.ssp.part.video.AdPopcornSSPInterstitialVideoAd
import com.igaworks.ssp.part.video.AdPopcornSSPRewardVideoAd
import com.igaworks.ssp.part.video.listener.IInterstitialVideoAdEventCallbackListener
import com.igaworks.ssp.part.video.listener.IRewardVideoAdEventCallbackListener

class MainActivity : AppCompatActivity() {

    private var adpopcornSSPRewardVideoAd: AdPopcornSSPRewardVideoAd? = null
    private var adpopcornSSPBannerAd_320x50: AdPopcornSSPBannerAd? = null
    private var adpopcornSSPBannerAd_320x100:AdPopcornSSPBannerAd? = null
    private var adpopcornSSPBannerAd_300x250: AdPopcornSSPBannerAd? = null
    private var adpopcornSSPInterstitialAd: AdPopcornSSPInterstitialAd? = null
    private var adpopcornSSPNativeAd: AdPopcornSSPNativeAd? = null
    private var adpopcornSSPMediationNativeAd: AdPopcornSSPNativeAd? = null
    private var adpopcornSSPInterstitialVideoAd: AdPopcornSSPInterstitialVideoAd? = null

    val APSSP_320x50_BANNER_PLACEMENT_ID = "BANNER_320x50"
    val APSSP_320x100_BANNER_PLACEMENT_ID = "BANNER_320x100"
    val APSSP_300x250_BANNER_PLACEMENT_ID = "BANNER_300x25090jk "
    val APSSP_INTERSTITIAL_AD_PLACEMENT_ID = "INTERSTITIAL"
    val APSSP_INTERSTITAL_VIDEO_AD_PLACEMENT_ID = "VIDEO"
    val APSSP_REWARD_VIDEO_AD_PLACEMENT_ID = "REWARD_VIDEO"
    val APSSP_NATIVE_AD_PLACEMENT_ID = "NATIVE"

    val LOG_TAG = "AdPopcornSSPSample"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        /* 주의 사항
            샘플에서 사용하고 있는 placement ID 값은 반드시 애드팝콘에서 발급받은 키로 변경하여 사용하여야 합니다.
            기타 자세한 사항 및 최신 SDK는 애드팝콘 SSP 가이드 페이지를 참고해 주시기 바랍니다
        */

        // 1. AdpopcornSSP SDK 초기화
        AdPopcornSSP.init(this@MainActivity)

        // 1-1. 인앱 비딩 사용 시에는 아래 API를 통해 초기화를 진행해 주어야 하며, 초기화 완료 이벤트를 받은 뒤 광고
        //    요청을 해주어야 인앱 비딩이 정상적으로 동작합니다.
        /*AdPopcornSSP.init(this@MainActivity, object : SdkInitListener{
            override fun onInitializationFinished() {

            }
        });*/

        // 2. Banner 320x50
        adpopcornSSPBannerAd_320x50 = findViewById(R.id.banner_container)
        adpopcornSSPBannerAd_320x50?.setAdSize(AdSize.BANNER_320x50)
        adpopcornSSPBannerAd_320x50?.placementId = APSSP_320x50_BANNER_PLACEMENT_ID
        adpopcornSSPBannerAd_320x50?.setBannerEventCallbackListener(object : IBannerEventCallbackListener {
            override fun OnBannerAdReceiveSuccess() {
                Log.i(LOG_TAG, "320x50 OnBannerAdReceiveSuccess")
                Toast.makeText(
                    this@MainActivity,
                    "OnBannerAdReceiveSuccess : ${adpopcornSSPBannerAd_320x50?.currentNetwork}",
                    Toast.LENGTH_SHORT
                ).show()
                adpopcornSSPBannerAd_320x50?.visibility = View.VISIBLE
            }

            override fun OnBannerAdReceiveFailed(errorCode: SSPErrorCode) {
                Log.i(LOG_TAG, "320x50 BannerOnBannerAdReceiveFailed : $errorCode.errorMessage")
                Toast.makeText(
                    this@MainActivity,
                    "OnBannerAdReceiveFailed : $errorCode.errorCode,  $errorCode.errorMessage",
                    Toast.LENGTH_SHORT
                ).show()
            }

            override fun OnBannerAdClicked() {

            }
        })

        val loadBanner1 = findViewById<Button>(R.id.button_banner1_load)
        loadBanner1.setOnClickListener{
            adpopcornSSPBannerAd_320x50?.loadAd()
        }

        val stopBanner1 = findViewById<Button>(R.id.button_banner1_stop)
        stopBanner1.setOnClickListener {
            adpopcornSSPBannerAd_320x50?.stopAd()
        }

        // 3. Banner 320x100
        adpopcornSSPBannerAd_320x100 = findViewById(R.id.banner_container_2)
        adpopcornSSPBannerAd_320x100?.setAdSize(AdSize.BANNER_320x100)
        adpopcornSSPBannerAd_320x100?.placementId = APSSP_320x100_BANNER_PLACEMENT_ID
        adpopcornSSPBannerAd_320x100?.setRefreshTime(50)
        adpopcornSSPBannerAd_320x100?.setNetworkScheduleTimeout(3)
        adpopcornSSPBannerAd_320x100?.setBannerEventCallbackListener(object : IBannerEventCallbackListener {
            override fun OnBannerAdReceiveSuccess() {
                Log.i(LOG_TAG, "320x100 OnBannerAdReceiveSuccess")
                Toast.makeText(
                    this@MainActivity,
                    "OnBannerAdReceiveSuccess : " + adpopcornSSPBannerAd_320x100?.currentNetwork,
                    Toast.LENGTH_SHORT
                ).show()
                adpopcornSSPBannerAd_320x100?.visibility = View.VISIBLE
            }

            override fun OnBannerAdReceiveFailed(errorCode: SSPErrorCode) {
                Log.i(LOG_TAG, "320x100 BannerOnBannerAdReceiveFailed : " + errorCode.errorMessage)
                Toast.makeText(
                    this@MainActivity,
                    "OnBannerAdReceiveFailed : " + errorCode.errorCode + ", " + errorCode.errorMessage,
                    Toast.LENGTH_SHORT
                ).show()
            }

            override fun OnBannerAdClicked() {

            }
        })

        val loadBanner2 = findViewById<Button>(R.id.button_banner2_load)
        loadBanner2.setOnClickListener{
            adpopcornSSPBannerAd_320x100?.loadAd()

        }

        val stopBanner2 = findViewById<Button>(R.id.button_banner2_stop)
        stopBanner2.setOnClickListener{
            adpopcornSSPBannerAd_320x100?.stopAd()
        }

        // 4. Banner 300x250
        adpopcornSSPBannerAd_300x250 = findViewById(R.id.banner_container_3)
        adpopcornSSPBannerAd_300x250?.setAdSize(AdSize.BANNER_300x250)
        adpopcornSSPBannerAd_300x250?.placementId = APSSP_300x250_BANNER_PLACEMENT_ID
        adpopcornSSPBannerAd_300x250?.setBannerEventCallbackListener(object : IBannerEventCallbackListener{
            override fun OnBannerAdReceiveSuccess() {
                Log.i(LOG_TAG, "300x250 OnBannerAdReceiveSuccess")
                Toast.makeText(
                    this@MainActivity,
                    "OnBannerAdReceiveSuccess : " + adpopcornSSPBannerAd_300x250?.currentNetwork,
                    Toast.LENGTH_SHORT
                ).show()
                adpopcornSSPBannerAd_300x250?.visibility = View.VISIBLE
            }

            override fun OnBannerAdReceiveFailed(errorCode: SSPErrorCode) {
                Log.i(LOG_TAG, "300x250 BannerOnBannerAdReceiveFailed : ${errorCode.errorCode} + errorMessage :  ${errorCode.errorMessage}")
                Toast.makeText(
                    this@MainActivity,
                    "OnBannerAdReceiveFailed : ${errorCode.errorCode} + errorMessage : ${errorCode.errorMessage}",
                    Toast.LENGTH_SHORT
                ).show()
            }

            override fun OnBannerAdClicked() {
            }
        })

        val loadBanner3 = findViewById<Button>(R.id.button_banner3_load)
        loadBanner3.setOnClickListener{
            adpopcornSSPBannerAd_300x250?.loadAd()
        }

        val stopBanner3 = findViewById<Button>(R.id.button_banner3_stop)
        stopBanner3.setOnClickListener{
            adpopcornSSPBannerAd_300x250?.stopAd()
        }

        // 5. interstitialAd
        adpopcornSSPInterstitialAd = AdPopcornSSPInterstitialAd(this@MainActivity)
        adpopcornSSPInterstitialAd?.setPlacementId(APSSP_INTERSTITIAL_AD_PLACEMENT_ID)

        adpopcornSSPInterstitialAd?.setInterstitialEventCallbackListener(object : IInterstitialEventCallbackListener {
            override  fun OnInterstitialLoaded() {
                Log.i(LOG_TAG, "OnInterstitialLoaded")
                Toast.makeText(
                    this@MainActivity,
                    "OnInterstitialLoaded : " + adpopcornSSPInterstitialAd?.currentNetwork,
                    Toast.LENGTH_SHORT
                ).show()
            }

            override fun OnInterstitialOpened() {
                Log.i(LOG_TAG, "OnInterstitialOpened")
                Toast.makeText(this@MainActivity, "OnInterstitialOpened", Toast.LENGTH_SHORT).show()
            }

            override fun OnInterstitialReceiveFailed(errorCode: SSPErrorCode) {
                Log.i(
                    LOG_TAG,
                    "OnInterstitialReceiveFailed : ${errorCode.errorCode} + errorMessage : ${errorCode.errorMessage}"
                )
                Toast.makeText(
                    this@MainActivity,
                    "OnInterstitialReceiveFailed : ${errorCode.errorCode} + errorMessage : ${errorCode.errorMessage}",
                    Toast.LENGTH_SHORT
                ).show()
            }

            override fun OnInterstitialOpenFailed(errorCode: SSPErrorCode) {
                Log.i(
                    LOG_TAG,
                    "OnInterstitialOpenFailed : ${errorCode.errorCode} + errorMessage : ${errorCode.errorMessage}"
                )
                Toast.makeText(
                    this@MainActivity,
                    "OnInterstitialOpenFailed : ${errorCode.errorCode} + errorMessage : ${errorCode.errorMessage}", Toast.LENGTH_SHORT).show()
            }


            override fun OnInterstitialClosed(closeEvent: Int) {
                Log.i(LOG_TAG, "OnInterstitialClosed : $closeEvent")
                if (closeEvent == AdPopcornSSPInterstitialAd.CloseEvent.UNKNOWN)
                    Toast.makeText(this@MainActivity, "OnInterstitialClosed : unknwon", Toast.LENGTH_SHORT).show()
                else if (closeEvent == AdPopcornSSPInterstitialAd.CloseEvent.CLICK_CLOSE_BTN)
                    Toast.makeText(
                        this@MainActivity,
                        "OnInterstitialClosed : click close btn",
                        Toast.LENGTH_SHORT
                    ).show()
                else if (closeEvent == AdPopcornSSPInterstitialAd.CloseEvent.PRESSED_BACK_KEY)
                    Toast.makeText(
                        this@MainActivity,
                        "OnInterstitialClosed : pressed back key",
                        Toast.LENGTH_SHORT
                    ).show()
            }

            override fun OnInterstitialClicked() {

            }
        })

        val loadInterstitial = findViewById<Button>(R.id.button_interstitial_load)
        loadInterstitial.setOnClickListener{
            adpopcornSSPInterstitialAd?.loadAd()
        }

        val showInterstitial = findViewById<Button>(R.id.button_interstitial_show)
        showInterstitial.setOnClickListener{
            if(adpopcornSSPInterstitialAd?.isLoaded == true)
                adpopcornSSPInterstitialAd?.showAd()
            else
                Toast.makeText(this@MainActivity, "InterstitialAd is not loaded", Toast.LENGTH_SHORT).show()
        }

        // 6.Reward Video
        adpopcornSSPRewardVideoAd = AdPopcornSSPRewardVideoAd(this@MainActivity)
        adpopcornSSPRewardVideoAd?.setPlacementId(APSSP_REWARD_VIDEO_AD_PLACEMENT_ID)
        adpopcornSSPRewardVideoAd?.setRewardVideoAdEventCallbackListener(iRewardVideoAdEventCallbackListener)
        val loadRewardVideoAd = findViewById<Button>(R.id.button_reward_video_load)
        loadRewardVideoAd.setOnClickListener{
            adpopcornSSPRewardVideoAd?.loadAd()
        }

        val showRewardVideoAd = findViewById<Button>(R.id.button_reward_video_show)
        showRewardVideoAd.setOnClickListener{
            if (adpopcornSSPRewardVideoAd?.isReady == true)
                adpopcornSSPRewardVideoAd?.showAd()
            else
                Toast.makeText(this@MainActivity, "RewardVideo is not loaded", Toast.LENGTH_SHORT).show()
        }


        // 7. Native Ad(SSP Mediation, 샘플로 admob mediation만 제공)
        // admob 이외의 업체 코드는 가이드 페이지의 샘플 코드를 참고.
        adpopcornSSPMediationNativeAd = findViewById<AdPopcornSSPNativeAd>(R.id.apssp_mediation_native_ad)
        adpopcornSSPMediationNativeAd?.setPlacementId(APSSP_NATIVE_AD_PLACEMENT_ID)

        val apsspMediationViewBinder = AdPopcornSSPViewBinder.Builder(R.id.apssp_native_ad_view)
            .iconImageViewId(R.id.apssp_native_ad_icon_image1)
            .descViewId(R.id.apssp_native_ad_desc1)
            .mainImageViewId(R.id.apssp_native_ad_main_image1)
            .titleViewId(R.id.apssp_native_ad_title1)
            .callToActionId(R.id.apssp_native_ad_ctatext1)
            .build()

        adpopcornSSPMediationNativeAd?.adPopcornSSPViewBinder = apsspMediationViewBinder

        val adMobViewBinder =
            AdMobViewBinder.Builder(R.id.admob_unified_native_ad_view, R.layout.admob_native_ad_unit_layout)
                .iconViewId(R.id.admob_ad_app_icon)
                .headlineViewId(R.id.admob_ad_headline)
                .bodyViewId(R.id.admob_ad_body)
                .mediaViewId(R.id.admob_ad_media)
                .callToActionId(R.id.admob_ad_call_to_action)
                .advertiserViewId(R.id.admob_ad_advertiser)
                .priceViewId(R.id.admob_ad_price)
                .starRatingViewId(R.id.admob_ad_stars)
                .storeViewId(R.id.admob_ad_store)
                .build()
        adpopcornSSPMediationNativeAd?.adMobViewBinder = adMobViewBinder

        adpopcornSSPMediationNativeAd?.setNativeAdEventCallbackListener(object : INativeAdEventCallbackListener{
            override fun onNativeAdLoadSuccess() {
                Log.i(
                    LOG_TAG,
                    "Mediation NativeAd onNativeAdLoadSuccess : ${adpopcornSSPMediationNativeAd?.isLoaded}"
                )
                Toast.makeText(this@MainActivity, "onNativeAdLoadSuccess", Toast.LENGTH_SHORT).show()
            }

            override fun onNativeAdLoadFailed(errorCode: SSPErrorCode) {
                Log.i(
                    LOG_TAG,
                    "Mediation NativeAd onNativeAdLoadFailed : ${adpopcornSSPMediationNativeAd?.isLoaded} + $errorCode : $errorCode.getErrorMessage()"
                )
                Toast.makeText(
                    this@MainActivity,
                    "onNativeAdLoadFailed : ${errorCode.errorCode} + ${errorCode.errorMessage}",
                    Toast.LENGTH_SHORT
                ).show()
            }

            override fun onImpression() {
                Log.i(LOG_TAG, "Mediation NativeAd onImpression")
                Toast.makeText(this@MainActivity, "onImpression", Toast.LENGTH_SHORT).show()
            }

            override fun onClicked() {
                Log.i(LOG_TAG, "Mediation NativeAd onClicked")
                Toast.makeText(this@MainActivity, "onClicked", Toast.LENGTH_SHORT).show()
            }
        })

        val loadMediationNativeAd = findViewById<Button>(R.id.button_mediation_native_ad_load)
        loadMediationNativeAd.setOnClickListener {
            adpopcornSSPMediationNativeAd?.loadAd()
        }

        // 8. Interstitial Video
        adpopcornSSPInterstitialVideoAd = AdPopcornSSPInterstitialVideoAd(this)
        adpopcornSSPInterstitialVideoAd?.setPlacementId(APSSP_INTERSTITAL_VIDEO_AD_PLACEMENT_ID)
        adpopcornSSPInterstitialVideoAd?.setEventCallbackListener(interstitialVideoAdEventCallbackListener)
        val loadInterstitialVideoAd = findViewById<Button>(R.id.button_interstitial_video_load)
        loadInterstitialVideoAd.setOnClickListener{
            adpopcornSSPInterstitialVideoAd?.loadAd()
        }

        val showInterstitialVideoAd = findViewById<Button>(R.id.button_interstitial_video_show)
        showInterstitialVideoAd.setOnClickListener(View.OnClickListener {
            if (adpopcornSSPInterstitialVideoAd?.isReady == true)
                adpopcornSSPInterstitialVideoAd?.showAd()
            else
                Toast.makeText(this@MainActivity, "Interstitial VideoAd is not loaded", Toast.LENGTH_SHORT).show()
        })
    }


    private var iRewardVideoAdEventCallbackListener: IRewardVideoAdEventCallbackListener = object :
        IRewardVideoAdEventCallbackListener {
        override fun OnRewardVideoAdLoaded() {
            // 광고 로드 성공
            Toast.makeText(this@MainActivity, "OneButton OnRewardVideoAdLoaded", Toast.LENGTH_SHORT).show()
            Log.i("IgawSSPSample", "OnRewardVideoAdLoaded")
        }

        override fun OnRewardVideoAdLoadFailed(sspErrorCode: SSPErrorCode) {
            // 광고 로드 실패
            Toast.makeText(this@MainActivity, "OnRewardVideoAdLoadFailed", Toast.LENGTH_SHORT).show()
            Log.i("IgawSSPSample", "OnRewardVideoAdLoadFailed")
        }

        override fun OnRewardVideoAdOpened() {
            Toast.makeText(this@MainActivity, "OnRewardVideoShowSuccess", Toast.LENGTH_SHORT).show()
            Log.i("IgawSSPSample", "OnRewardVideoShowSuccess")
        }

        override fun OnRewardVideoAdOpenFalied() {
            Toast.makeText(this@MainActivity, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show()
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed")
        }

        override fun OnRewardVideoAdClosed() {
            Toast.makeText(this@MainActivity, "OnRewardVideoAdClosed", Toast.LENGTH_SHORT).show()
            Log.i("IgawSSPSample", "OnRewardVideoAdClosed")
        }

        override fun OnRewardVideoPlayCompleted(networkId: Int, completed: Boolean) {
            Toast.makeText(
                this@MainActivity, "OnRewardVideoPlayCompleted : " + networkId + ", " +
                        "completed : " + completed,
                Toast.LENGTH_SHORT
            ).show()
            Log.i(
                "IgawSSPSample", "OnRewardVideoPlayCompleted : " + networkId + ", " +
                        "completed : " + completed
            )
            onCompletedRewardVideoAd()
        }

        override fun OnRewardVideoAdClicked() {

        }
    }

    private var interstitialVideoAdEventCallbackListener: IInterstitialVideoAdEventCallbackListener = object :
        IInterstitialVideoAdEventCallbackListener {
        override fun OnInterstitialVideoAdLoaded() {

        }

        override fun OnInterstitialVideoAdLoadFailed(sspErrorCode: SSPErrorCode) {

        }

        override fun OnInterstitialVideoAdOpened() {

        }

        override fun OnInterstitialVideoAdOpenFalied() {

        }

        override fun OnInterstitialVideoAdClosed() {

        }

        override fun OnInterstitialVideoAdClicked() {

        }
    }

    private fun onCompletedRewardVideoAd() {
        // 리워드 비디오가 정상적으로 종료 되었을 때 처리.
    }

    override fun onResume() {
        super.onResume()
        // 8. Activity Life cycle에 맞춰 onResume 연동
        adpopcornSSPBannerAd_320x50?.onResume()
        adpopcornSSPBannerAd_320x100?.onResume()
        adpopcornSSPBannerAd_300x250?.onResume()
        adpopcornSSPRewardVideoAd?.onResume()
    }

    override fun onPause() {
        super.onPause()
        // 9. Activity Life cycle에 맞춰 onResume 연동
        adpopcornSSPBannerAd_320x50?.onPause()
        adpopcornSSPBannerAd_320x100?.onPause()
        adpopcornSSPBannerAd_300x250?.onPause()
        adpopcornSSPRewardVideoAd?.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        AdPopcornSSP.destroy()
    }
}
