//
//  ViewController.m
//  AdPopcornTestApp
//
//  Created by mick on 2023. 4. 4..
//  Copyright © 2023년 adpopcorn. All rights reserved.
//

#import "ViewController.h"
#import <AdPopcornSSP/AdPopcornSSP.h>
#import <AdPopcornSSP/AdPopcornSSPCustomAd.h>
#import <AdPopcornSSP/AdPopcornSSPNativeAd.h>
#import "AdFitAdapter.h"
#import "NAMAdapter.h"

@interface ViewController () <APSSPNativeAdDelegate, APSSPCustomAdDelegate, WKUIDelegate, WKNavigationDelegate, WKScriptMessageHandler>
{
    WKWebView *webView;
    WKWebViewConfiguration *webViewConfiguration;
    WKUserContentController *wkContentController;
    AdPopcornSSPCustomAd *_customAd;
    AdPopcornSSPNativeAd *_adPopcornSSPNativeAd;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    webViewConfiguration = [[WKWebViewConfiguration alloc] init];
    wkContentController = [[WKUserContentController alloc] init];
    
    [wkContentController addScriptMessageHandler:self name:@"adpopcornssp"];
    [webViewConfiguration setUserContentController:wkContentController];
    
    
    webView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) configuration:webViewConfiguration];
    webView.UIDelegate = self;
    webView.navigationDelegate = self;
    
    [self.view addSubview:webView];
    [self loadUrl];
    
    /* 일반 네이티브 미디에이션
      애드팝콘, NAM, Adfit 사용하는 지면에 따라서 아래 내용 세팅 여부가 달라집니다.
      nativeAd 지면의 미디에이션 운영 방식에 따라 아래 ViewBinder를 각각 세팅해 주시기 바랍니다.
     */
    
    _adPopcornSSPNativeAd = [[AdPopcornSSPNativeAd alloc] init];
    _adPopcornSSPNativeAd.frame = CGRectMake(0, self.view.frame.size.height - 200, self.view.frame.size.width, 200);
    [_adPopcornSSPNativeAd setPlacementInfoWithAppKey:@"470421542" placementId:@"vpBMYcVGjpW94ae" viewController:self];
    _adPopcornSSPNativeAd.delegate = self;
    
    GFPNativeSimpleAdView *namNativeSimpleAdView =
    [[NSBundle mainBundle] loadNibNamed:@"GFPNativeSimpleAdView" owner:nil options:nil].firstObject;
    
    namNativeSimpleAdView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 120);
    APNAMNativeAdRenderer *apNAMNativeAdRenderer = [[APNAMNativeAdRenderer alloc] init];
    apNAMNativeAdRenderer.namNativeSimpleAdView = namNativeSimpleAdView;
    [_adPopcornSSPNativeAd setNAMRenderer:apNAMNativeAdRenderer superView:namNativeSimpleAdView];
    
    // adfit bizboard
    APAdFitNativeAdRenderer *apAdFitNativeAdRenderer = [[APAdFitNativeAdRenderer alloc] init];
    BizBoardTemplate *bizBoardTemplate = [[BizBoardTemplate alloc] init];
    apAdFitNativeAdRenderer.adfitBizBoardTemplate = bizBoardTemplate;
    apAdFitNativeAdRenderer.bizBoardInfoIconTopConstant = 10;
    apAdFitNativeAdRenderer.bizBoardInfoIconRightConstant = -16;
    [_adPopcornSSPNativeAd setAdFitRenderer:apAdFitNativeAdRenderer superView:bizBoardTemplate];
    
    [self.view addSubview:_adPopcornSSPNativeAd];
    
    [_adPopcornSSPNativeAd loadRequest];
}

-(void) loadUrl{
    NSString *urlStr =  [[NSBundle mainBundle] pathForResource:@"index" ofType:@"html"];

    //WKWebView 특정 주소로 로딩 시키기
    NSURL * url = [NSURL fileURLWithPath:urlStr];
    NSMutableURLRequest *request =
    [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10.0];

  
    //html,js 파일 로드하기
    [webView loadRequest:request];

    // 웹뷰의 딜리게이트들을 새로 초기화해줍니다.
    [webView setUIDelegate:self];
    [webView setNavigationDelegate:self];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - delegate method
- (void)userContentController:(WKUserContentController *)userContentController
        didReceiveScriptMessage:(WKScriptMessage *)message{
    
    if([message.name isEqualToString:@"adpopcornssp"]){
        NSString *body = [message body];
        NSLog(@"didReceiveScriptMessage body : %@", body);
        if([body isEqualToString:@"createCustomNative"])
        {
            _customAd = [[AdPopcornSSPCustomAd alloc] initWithAppKey:@"470421542"
                             placementId:@"fXpDCzVHPBVktEY" adType:SSPCustomAdNativeAd];
            _customAd.delegate = self;
        }
        else if([body isEqualToString:@"loadCustomNative"])
        {
            [_customAd loadAd];
        }
        if([body isEqualToString:@"impressionCustomNative"])
        {
            [_customAd reportImpression];
        }
        if([body isEqualToString:@"clickCustomNative"])
        {
            [_customAd reportClick];
        }
    }
}

#pragma mark - WKNavigationDelegate
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
{
    NSString *requestString = navigationAction.request.URL.absoluteString;

    if(navigationAction.navigationType == UIWebViewNavigationTypeLinkClicked)
    {
        decisionHandler(WKNavigationActionPolicyCancel);
        NSURL *requestURL = [NSURL URLWithString:requestString];
        if(@available(iOS 10, *))
        {
            [[UIApplication sharedApplication] openURL:requestURL options:@{} completionHandler:^(BOOL success) {
                if (success) {
                    [webView stopLoading];
                }
            }];
        }
        return;
    }
    decisionHandler(WKNavigationActionPolicyAllow);
}

#pragma mark - APSSPCustomAdDelegate
- (void)APSSPCustomAdLoadSuccess:(AdPopcornSSPCustomAd *)customAd adData:(NSString *)adData
{
      NSLog(@"APSSPCustomAdLoadSuccess : %@", adData);
      if(_customAd != nil)
      {
          NSString *funcName = [[NSString alloc]initWithFormat:@"OnCustomAdReceiveSuccess(%@)", adData];
          
          [webView evaluateJavaScript:funcName completionHandler:^(NSString * result, NSError * _Nullable error) {
              NSLog(@"error : %@", error);
          }];
      }
}

- (void)APSSPCustomAdLoadFail:(AdPopcornSSPCustomAd *)customAd error:(AdPopcornSSPError *)error
{
    NSLog(@"APSSPCustomAdLoadFail : %@", error);
}
@end
