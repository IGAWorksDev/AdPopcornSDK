//
//  AppDelegate.h
//  AdPopcornTestApp
//
//  Created by mick on 2023. 4. 4..
//  Copyright © 2023년 adpopcorn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

