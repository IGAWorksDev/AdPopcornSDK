//
//  main.m
//  AdPopcornTestApp
//
//  Created by 김민석 on 2016. 12. 5..
//  Copyright © 2016년 igaworks. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
