//
//  RNAdPopcornBannerView.m
//  AdPopcornSSPReactPlugin
//
//  Created by 김민석 on 2023/05/17.
//

#import <Foundation/Foundation.h>
#import "RNAdPopcornBannerView.h"

@implementation RNAdPopcornBannerView

- (void)setAppKey:(NSString *)appKey
{
  NSLog(@"setAppKey : %@", appKey);
  _appKey = appKey;
  [self loadAd];
}

- (void)setPlacementId:(NSString *)placementId
{
  NSLog(@"setPlacementId : %@", placementId);
  _placementId = placementId;
  [self loadAd];
}

- (void)setAdSize:(NSString *)adSize
{
  NSLog(@"setAdSize : %@", adSize);
  _adSize = adSize;
  [self loadAd];
}

- (void)setRefreshTime:(NSInteger)refreshTime
{
  NSLog(@"setRefreshTime : %ld", refreshTime);
  _refreshTime = refreshTime;
}

- (void)setNetworkScheduleTimeout:(NSInteger)networkScheduleTimeout
{
  NSLog(@"setNetworkScheduleTimeout : %ld", networkScheduleTimeout);
  _networkScheduleTimeout = networkScheduleTimeout;
}

- (void)setOriginX:(NSInteger)originX
{
  NSLog(@"setOriginX : %ld", originX);
  _originX = originX;
  [self loadAd];
}

- (void)setOriginY:(NSInteger)originY
{
  NSLog(@"setOriginY : %ld", originY);
  _originY = originY;
  [self loadAd];
}

- (void)setBannerAnimType:(NSString *)bannerAnimType
{
  _bannerAnimType = bannerAnimType;
}

- (void)setAutoBgColor:(BOOL)autoBgColor
{
  _autoBgColor = autoBgColor;
}

- (void)loadAd
{
  if (_appKey == nil || _adSize == nil || _placementId == nil) {
      return;
  }
  if(_originX < 0 || _originY < 0){
    return;
  }
  
  SSPBannerViewSizeType bannerSize = SSPBannerViewSize320x50;
  if([_adSize isEqualToString:@"320x50"])
  {
    bannerSize = SSPBannerViewSize320x50;
  }
  else if([_adSize isEqualToString:@"300x250"])
  {
    bannerSize = SSPBannerViewSize300x250;
  }
  else if([_adSize isEqualToString:@"320x100"])
  {
    bannerSize = SSPBannerViewSize320x100;
  }
  else if([_adSize isEqualToString:@"AdaptiveSize"])
  {
      bannerSize = SSPBannerViewSizeAdaptive;
  }
  else
  {
    return;
  }
  
  SSPBannerViewAnimationType bannerAnimationType = SSPBannerViewAnimNone;
  if([_bannerAnimType isEqualToString:@"BOTTOM_SLIDE"])
  {
    bannerAnimationType = SSPBannerViewAnimCurlDown;
  }
  else if([_bannerAnimType isEqualToString:@"TOP_SLIDE"])
  {
    bannerAnimationType = SSPBannerViewAnimCurlUp;
  }
  else if([_bannerAnimType isEqualToString:@"SLIDE_LEFT"])
  {
    bannerAnimationType = SSPBannerViewAnimFlipFromLeft;
  }
  else if([_bannerAnimType isEqualToString:@"SLIDE_RIGHT"])
  {
    bannerAnimationType = SSPBannerViewAnimFlipFromRight;
  }
  else if([_bannerAnimType isEqualToString:@"FADE_IN"])
  {
    bannerAnimationType = SSPBannerViewAnimFadeIn;
  }

  if (!_bannerView) {
      _bannerView = [[AdPopcornSSPBannerView alloc] initWithBannerViewSize:bannerSize origin:CGPointMake(_originX, _originY) appKey:_appKey placementId:_placementId view:self rootViewController:RCTPresentedViewController()];
      [self addSubview:_bannerView];
  }
  _bannerView.delegate = self;
  [_bannerView setAnimType:bannerAnimationType];
  [_bannerView loadRequest];
}

# pragma mark APSSPBannerViewDelegate
- (void)APSSPBannerViewLoadFail:(AdPopcornSSPBannerView *)bannerView error:(AdPopcornSSPError *)error
{
  NSLog(@"APSSPBannerViewLoadFail : %@, error : %@", bannerView, error);
  if (_onBannerAdReceiveFailed) {
    (_onBannerAdReceiveFailed)(@{
      @"errorCode": @(error.code),
      @"errorMessage": error.userInfo.description,
      @"placementId": _placementId
    });
  }
}

- (void)APSSPBannerViewLoadSuccess:(AdPopcornSSPBannerView *)bannerView
{
  NSLog(@"APSSPBannerViewLoadSuccess : %@", bannerView);
  if (_onBannerAdReceiveSuccess) {
    _onBannerAdReceiveSuccess(@{@"placementId":_placementId});
  }
}

- (void)APSSPBannerViewClicked:(AdPopcornSSPBannerView *)bannerView
{
  NSLog(@"APSSPBannerViewClicked : %@", bannerView);
  if (_onBannerAdClicked) {
    (_onBannerAdClicked)(@{@"placementId":_placementId});
  }
}
@end
