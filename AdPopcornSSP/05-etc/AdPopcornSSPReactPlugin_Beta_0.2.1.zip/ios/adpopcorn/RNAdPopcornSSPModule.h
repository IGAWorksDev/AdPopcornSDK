//
//  RNAdPopcornSSPModule.h
//  AdPopcornSSPReactPlugin
//
//  Created by 김민석 on 2023/05/18.
//
#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>
#import <UIKit/UIKit.h>
#import <AdPopcornSSP/AdPopcornSSP.h>

@interface RNAdPopcornSSPModule : RCTEventEmitter<RCTBridgeModule, APSSPSDKInitializeDelegate>
{
  
}

@end
