package com.adpopcornsspreactplugin.adpopcorn.ads;

import android.content.Context;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;

import androidx.annotation.Nullable;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.events.RCTEventEmitter;
import com.facebook.react.views.view.ReactViewGroup;
import com.igaworks.ssp.AdSize;
import com.igaworks.ssp.BannerAnimType;
import com.igaworks.ssp.SSPErrorCode;
import com.igaworks.ssp.part.banner.AdPopcornSSPBannerAd;
import com.igaworks.ssp.part.banner.listener.IBannerEventCallbackListener;

import static com.adpopcornsspreactplugin.adpopcorn.ads.RNAdPopcornBannerViewManager.EVENT_BANNER_CLICKED;
import static com.adpopcornsspreactplugin.adpopcorn.ads.RNAdPopcornBannerViewManager.EVENT_BANNER_LOAD_FAILED;
import static com.adpopcornsspreactplugin.adpopcorn.ads.RNAdPopcornBannerViewManager.EVENT_BANNER_LOAD_SUCCESS;

public class RNAdPopcornBannerView extends ReactViewGroup implements IBannerEventCallbackListener {

    private AdPopcornSSPBannerAd adPopcornSSPBannerAd;
    private String mAdSize;

    private String appKey;
    private int viewWidth = 0;
    private int viewHeight = 0;
    private String placementId;

    public RNAdPopcornBannerView(Context context) {
        super(context);
        initBannerView();
    }

    private void initBannerView() {
        adPopcornSSPBannerAd = new AdPopcornSSPBannerAd(getContext());
        adPopcornSSPBannerAd.setBannerEventCallbackListener(this);
        addView(adPopcornSSPBannerAd);
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
        if(adPopcornSSPBannerAd != null)
            adPopcornSSPBannerAd.setPlacementAppKey(appKey);
        loadAd();
    }

    public void setAdSize(String mAdSize) {
        this.mAdSize = mAdSize;
        loadAd();
    }

    public void setWidth(int width) {
        this.viewWidth = width;
    }

    public void setHeight(int height) {
        this.viewHeight = height;
    }

    public void setPlacementId(String placementId) {
        this.placementId = placementId;
        loadAd();
    }

    public void setRefreshTime(int refreshTime) {
        if(adPopcornSSPBannerAd != null)
            adPopcornSSPBannerAd.setRefreshTime(refreshTime);
    }

    public void setNetworkScheduleTimeout(int timeout){
        if(adPopcornSSPBannerAd != null)
            adPopcornSSPBannerAd.setNetworkScheduleTimeout(timeout);
    }

    public void setAutoBgColor(boolean flag){
        if(adPopcornSSPBannerAd != null)
            adPopcornSSPBannerAd.setAutoBgColor(flag);
    }

    public void setBannerAnimType(String type){
        if(adPopcornSSPBannerAd != null && type != null) {
            if(type.contentEquals("FADE_IN"))
                adPopcornSSPBannerAd.setBannerAnimType(BannerAnimType.FADE_IN);
            else if(type.contentEquals("SLIDE_LEFT"))
                adPopcornSSPBannerAd.setBannerAnimType(BannerAnimType.SLIDE_LEFT);
            else if(type.contentEquals("SLIDE_RIGHT"))
                adPopcornSSPBannerAd.setBannerAnimType(BannerAnimType.SLIDE_RIGHT);
            else if(type.contentEquals("TOP_SLIDE"))
                adPopcornSSPBannerAd.setBannerAnimType(BannerAnimType.TOP_SLIDE);
            else if(type.contentEquals("BOTTOM_SLIDE"))
                adPopcornSSPBannerAd.setBannerAnimType(BannerAnimType.BOTTOM_SLIDE);
            else if(type.contentEquals("CIRCLE"))
                adPopcornSSPBannerAd.setBannerAnimType(BannerAnimType.CIRCLE);
            else
                adPopcornSSPBannerAd.setBannerAnimType(BannerAnimType.NONE);
        }
    }

    public void loadAd() {
        if (mAdSize == null || placementId == null) {
            return;
        }

        adPopcornSSPBannerAd.setPlacementId(placementId);
        if (mAdSize != null) {
            if(mAdSize.contentEquals("320x50"))
                adPopcornSSPBannerAd.setAdSize(AdSize.BANNER_320x50);
            else if(mAdSize.contentEquals("300x250"))
                adPopcornSSPBannerAd.setAdSize(AdSize.BANNER_300x250);
            else if(mAdSize.contentEquals("320x100"))
                adPopcornSSPBannerAd.setAdSize(AdSize.BANNER_320x100);
            else if(mAdSize.contentEquals("AdaptiveSize"))
                adPopcornSSPBannerAd.setAdSize(AdSize.BANNER_ADAPTIVE_SIZE);
        }
        adPopcornSSPBannerAd.loadAd();
    }

    public void stopAd(){
        if(adPopcornSSPBannerAd != null)
            adPopcornSSPBannerAd.stopAd();
    }

    public void onResume(){
        if(adPopcornSSPBannerAd != null)
            adPopcornSSPBannerAd.onResume();
    }

    public void onPause(){
        if(adPopcornSSPBannerAd != null)
            adPopcornSSPBannerAd.onPause();
    }

    private void sendEvent(String eventName, @Nullable WritableMap params) {
        /*((ThemedReactContext) getContext())
                //.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                //.emit(eventName, params);*/
        ((ThemedReactContext) getContext())
                .getJSModule(RCTEventEmitter.class)
                .receiveEvent(getId(), eventName, params);
    }

    @Override
    public void OnBannerAdReceiveSuccess() {
        Log.d("AdPopcornSSP", "OnBannerAdReceiveSuccess");
        int bannerWidth = 0;
        int bannerHeight = 0;

        if(mAdSize.contentEquals("320x50")) {
            bannerWidth = DpToPxInt(getContext(), 320);
            bannerHeight = DpToPxInt(getContext(), 50);
        }
        else if(mAdSize.contentEquals("300x250")) {
            bannerWidth = DpToPxInt(getContext(), 300);
            bannerHeight = DpToPxInt(getContext(), 250);
        }
        else if(mAdSize.contentEquals("320x100")) {
            bannerWidth = DpToPxInt(getContext(), 320);
            bannerHeight = DpToPxInt(getContext(), 100);
        }
        else if(mAdSize.contentEquals("AdaptiveSize")) {
            bannerWidth = DpToPxInt(getContext(), 360);
            bannerHeight = DpToPxInt(getContext(), 185);
        }
        Log.d("AdPopcornSSP", "viewWidth : " + viewWidth);

        if(this.viewWidth > 0)
            bannerWidth = viewWidth;
        if(this.viewHeight > 0)
            bannerHeight = viewHeight;

        Log.d("AdPopcornSSP", "bannerWidth : " + bannerWidth);
        Log.d("AdPopcornSSP", "bannerHeight : " + bannerHeight);

        adPopcornSSPBannerAd.measure(
                View.MeasureSpec.makeMeasureSpec(bannerWidth, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(bannerHeight, View.MeasureSpec.EXACTLY));

        adPopcornSSPBannerAd.layout(adPopcornSSPBannerAd.getLeft(), adPopcornSSPBannerAd.getTop(), bannerWidth, bannerHeight);
        WritableMap event = Arguments.createMap();
        event.putString("placementId", placementId);
        sendEvent(EVENT_BANNER_LOAD_SUCCESS, event);
    }

    @Override
    public void OnBannerAdReceiveFailed(SSPErrorCode sspErrorCode) {
        Log.d("AdPopcornSSP", "OnBannerAdReceiveFailed : " + sspErrorCode.getErrorMessage());
        WritableMap event = Arguments.createMap();
        event.putInt("errorCode", sspErrorCode.getErrorCode());
        event.putString("errorMessage", sspErrorCode.getErrorMessage());
        event.putString("placementId", placementId);
        sendEvent(EVENT_BANNER_LOAD_FAILED, event);
    }

    @Override
    public void OnBannerAdClicked() {
        Log.d("AdPopcornSSP", "OnBannerAdClicked");
        WritableMap event = Arguments.createMap();
        event.putString("placementId", placementId);
        sendEvent(EVENT_BANNER_CLICKED, event);
    }

    public int DpToPxInt(Context context, int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
    }
}
