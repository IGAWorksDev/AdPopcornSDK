//
//  FANAdapter.m
//  AdPopcornSSP
//
//  Created by mick on 2017. 8. 2..
//  Copyright (c) 2017년 igaworks All rights reserved.
//

// compatible with FAN v6.14.0
#import "FANAdapter.h"

static inline NSError *fanError(SSPErrorCode code, NSString *desc) {
    return [NSError errorWithDomain:kAdPopcornSSPErrorDomain
                               code:code
                           userInfo:@{NSLocalizedDescriptionKey: desc}];
}

@interface FANAdapter () <FBAdViewDelegate, FBInterstitialAdDelegate, FBNativeAdDelegate, FBNativeBannerAdDelegate, FBRewardedVideoAdDelegate>
{
    NSInteger        _adNetworkNo;
    BOOL             _isCurrentRunningAdapter;
    NSTimer         *_networkTimer;
    VideoMixAdType   _videoMixAdType;
    APFANNativeAdRenderer *fanNativeAdRenderer;
    APFANNativeBannerAdRenderer *fanNativeBannerAdRenderer;
    BOOL isFANNativeBannerAd;
    NSMutableArray *_impTrackersListArray, *_clickTrackersListArray;
    NSString *_biddingData;
    BOOL _isInAppBidding;
}

@property (strong, nonatomic) FBNativeAd *nativeAd;
@property (strong, nonatomic) FBNativeBannerAd *nativeBannerAd;

@end

@implementation FANAdapter

@synthesize delegate       = _delegate;
@synthesize integrationKey = _integrationKey;
@synthesize viewController = _viewController;
@synthesize bannerView     = _bannerView;
@synthesize adpopcornSSPNativeAd = _adpopcornSSPNativeAd;

static const NSTimeInterval kFANNetworkTimeout = 10.0;

#pragma mark - Init

- (instancetype)init {
    self = [super init];
    if (self) {
        _adNetworkNo = 2;
        _isInAppBidding = NO;
    }
    return self;
}

#pragma mark - Setup methods

- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(AdPopcornSSPBannerView *)bannerView {
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = SSPAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController {
    _viewController = viewController;
    _adType = SSPAdInterstitialType;
}

- (void)setRewardVideoViewController:(UIViewController *)viewController {
    _viewController = viewController;
    _adType = SSPRewardVideoAdType;
}

- (void)setInterstitialVideoViewController:(UIViewController *)viewController {
    _viewController = viewController;
    _adType = SSPInterstitialVideoAdType;
}

- (void)setVideoMixAdViewController:(UIViewController *)viewController {
    _viewController = viewController;
    _adType = SSPVideoMixAdType;
}

- (void)setNativeAdViewController:(UIViewController *)viewController nativeAdRenderer:(id)nativeAdRenderer rootNativeAdView:(AdPopcornSSPNativeAd *)adpopcornSSPNativeAd {
    _viewController = viewController;
    _adType = SSPNativeAdType;
    if ([nativeAdRenderer isKindOfClass:[APFANNativeAdRenderer class]]) {
        fanNativeAdRenderer = nativeAdRenderer;
        isFANNativeBannerAd = NO;
    } else if ([nativeAdRenderer isKindOfClass:[APFANNativeBannerAdRenderer class]]) {
        fanNativeBannerAdRenderer = nativeAdRenderer;
        isFANNativeBannerAd = YES;
    }
    _adpopcornSSPNativeAd = adpopcornSSPNativeAd;
}

#pragma mark - Support flags

- (BOOL)isSupportInterstitialAd      { return YES; }
- (BOOL)isSupportRewardVideoAd       { return YES; }
- (BOOL)isSupportNativeAd            { return YES; }
- (BOOL)isSupportInterstitialVideoAd { return YES; }
- (BOOL)isSupportVideoMixAd          { return YES; }

#pragma mark - Bidding

- (void)setBiddingData:(NSString *)biddingData impressionList:(NSMutableArray *)impTrackersListArray clickList:(NSMutableArray *)clickTrackersListArray {
    _biddingData = biddingData;
    _impTrackersListArray = impTrackersListArray;
    _clickTrackersListArray = clickTrackersListArray;
}

- (void)setInAppBiddingMode:(bool)isInAppBiddingMode {
    _isInAppBidding = isInAppBiddingMode;
}

- (NSString *)getBiddingToken {
    return [FBAdSettings bidderToken];
}

#pragma mark - loadAd

- (void)loadAd {
    switch (_adType) {
        case SSPAdBannerType:
            [self _loadBanner];
            break;
        case SSPAdInterstitialType:
            [self _loadInterstitial];
            break;
        case SSPRewardVideoAdType:
            [self _loadRewardVideo];
            break;
        case SSPNativeAdType:
            [self _loadNative];
            break;
        case SSPInterstitialVideoAdType:
            [self _loadInterstitialVideo];
            break;
        case SSPVideoMixAdType: {
            NSNumber *campaignType = [_integrationKey valueForKey:@"CampaignType"];
            _videoMixAdType = SSPVideoMixAdTypeFromInteger([campaignType integerValue]);
            switch (_videoMixAdType) {
                case VideoMix_InterstitialVideoType: [self _loadInterstitialVideo]; break;
                case VideoMix_RewardVideoType:       [self _loadRewardVideo];       break;
                default:
                    [self _fireLoadFail:fanError(AdPopcornSSPLoadAdFailed, @"Not supported VideoMix type")];
                    break;
            }
            break;
        }
        default:
            NSLog(@"FANAdapter: adType %d not supported", _adType);
            break;
    }
}

#pragma mark - showAd

- (void)showAd {
    NSLog(@"FANAdapter showAd");
    switch (_adType) {
        case SSPAdInterstitialType:
            [_interstitialAd showAdFromRootViewController:_viewController];
            break;

        case SSPRewardVideoAdType:
            if (_rewardedVideoAd && _rewardedVideoAd.isAdValid) {
                [_rewardedVideoAd showAdFromRootViewController:_viewController];
            } else {
                if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowFailError:adapter:)])
                    [_delegate AdPopcornSSPAdapterRewardVideoAdShowFailError:fanError(AdPopcornSSPNoRewardVideoAdLoaded, @"No RewardVideo Loaded") adapter:self];
            }
            break;

        case SSPInterstitialVideoAdType:
            if (_interstitialVideoAd && [_interstitialVideoAd isAdValid]) {
                [_interstitialVideoAd showAdFromRootViewController:_viewController];
            } else {
                if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdShowFailError:adapter:)])
                    [_delegate AdPopcornSSPAdapterInterstitialVideoAdShowFailError:fanError(AdPopcornSSPNoInterstitialVideoAdLoaded, @"No InterstitialVideo Loaded") adapter:self];
            }
            break;

        case SSPVideoMixAdType:
            switch (_videoMixAdType) {
                case VideoMix_InterstitialVideoType:
                    if (_interstitialVideoAd && [_interstitialVideoAd isAdValid]) {
                        [_interstitialVideoAd showAdFromRootViewController:_viewController];
                    } else {
                        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowFailError:adapter:videoMixType:)])
                            [_delegate AdPopcornSSPAdapterVideoMixAdShowFailError:fanError(AdPopcornSSPNoVideoMixAdLoaded, @"No VideoMix Ad Loaded") adapter:self videoMixType:_videoMixAdType];
                    }
                    break;
                case VideoMix_RewardVideoType:
                    if (_rewardedVideoAd && _rewardedVideoAd.isAdValid) {
                        [_rewardedVideoAd showAdFromRootViewController:_viewController];
                    } else {
                        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowFailError:adapter:videoMixType:)])
                            [_delegate AdPopcornSSPAdapterVideoMixAdShowFailError:fanError(AdPopcornSSPNoVideoMixAdLoaded, @"No VideoMix Ad Loaded") adapter:self videoMixType:_videoMixAdType];
                    }
                    break;
                default: break;
            }
            break;

        default: break;
    }
}

#pragma mark - closeAd

- (void)closeAd {
    switch (_adType) {
        case SSPAdBannerType:
            if (_adView) {
                [_adView removeFromSuperview];
                _adView.delegate = nil;
                _adView = nil;
            }
            break;
        case SSPAdInterstitialType:
            if (_interstitialAd) {
                _interstitialAd.delegate = nil;
                _interstitialAd = nil;
            }
            break;
        case SSPRewardVideoAdType:
            [self _invalidateTimer];
            _isCurrentRunningAdapter = NO;
            if (_rewardedVideoAd) {
                _rewardedVideoAd.delegate = nil;
                _rewardedVideoAd = nil;
            }
            break;
        case SSPInterstitialVideoAdType:
            [self _invalidateTimer];
            _isCurrentRunningAdapter = NO;
            if (_interstitialVideoAd) {
                _interstitialVideoAd.delegate = nil;
                _interstitialVideoAd = nil;
            }
            break;
        case SSPVideoMixAdType:
            [self _invalidateTimer];
            _isCurrentRunningAdapter = NO;
            if (_interstitialVideoAd) {
                _interstitialVideoAd.delegate = nil;
                _interstitialVideoAd = nil;
            }
            if (_rewardedVideoAd) {
                _rewardedVideoAd.delegate = nil;
                _rewardedVideoAd = nil;
            }
            break;
        default:
            break;
    }
}

- (void)loadRequest { /* not used */ }

#pragma mark - Private load helpers

- (NSString *)_placementID { return [_integrationKey valueForKey:@"fb_placement_id"]; }

- (void)_loadBanner {
    if (_adView.superview != nil) return;
    if (!_integrationKey) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:fanError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey") adapter:self];
        [self closeAd];
        return;
    }
    NSString *placementID = [self _placementID];
    if (_size.width == 320.0f && _size.height == 100.0f) {
        NSLog(@"%@ : FAN can not load 320x100", self);
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:fanError(AdPopcornSSPLoadAdFailed, @"Load Ad Failed") adapter:self];
        [self closeAd];
        return;
    } else if (_size.width == 300.0f && _size.height == 250.0f) {
        _adView = [[FBAdView alloc] initWithPlacementID:placementID adSize:kFBAdSizeHeight250Rectangle rootViewController:_viewController];
    } else {
        _adView = [[FBAdView alloc] initWithPlacementID:placementID adSize:kFBAdSizeHeight50Banner rootViewController:_viewController];
    }
    _adView.frame = CGRectMake(0.0f, 0.0f, _size.width, _size.height);
    _adView.delegate = self;
    _adView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [_bannerView addSubview:_adView];
    [self _addAlignCenterConstraint];
    [_adView loadAd];
}

- (void)_loadInterstitial {
    if (!_integrationKey) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterInterstitialAdLoadFailError:fanError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey") adapter:self];
        [self closeAd];
        return;
    }
    _interstitialAd = [[FBInterstitialAd alloc] initWithPlacementID:[self _placementID]];
    _interstitialAd.delegate = self;
    [_interstitialAd loadAdWithBidPayload:_biddingData];
}

- (void)_loadNative {
    NSString *placementID = [self _placementID];
    if (!placementID) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterNativeAdLoadFailError:fanError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey") adapter:self];
        [self closeAd];
        return;
    }
    if (isFANNativeBannerAd) {
        NSLog(@"FANNativeBannerAd loadAd");
        _nativeBannerAd = [[FBNativeBannerAd alloc] initWithPlacementID:placementID];
        _nativeBannerAd.delegate = self;
        [_nativeBannerAd loadAd];
    } else {
        NSLog(@"FBNativeAd loadAd");
        _nativeAd = [[FBNativeAd alloc] initWithPlacementID:placementID];
        _nativeAd.delegate = self;
        [_nativeAd loadAd];
    }
}

- (void)_loadInterstitialVideo {
    _isCurrentRunningAdapter = YES;
    [self _startTimer];
    if (!_integrationKey) {
        [self _fireLoadFail:fanError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey")];
        [self _invalidateTimer];
        return;
    }
    NSLog(@"FANAdapter InterstitialVideo placementID: %@", [self _placementID]);
    _interstitialVideoAd = [[FBInterstitialAd alloc] initWithPlacementID:[self _placementID]];
    _interstitialVideoAd.delegate = self;
    [_interstitialVideoAd loadAdWithBidPayload:_biddingData];
}

- (void)_loadRewardVideo {
    _isCurrentRunningAdapter = YES;
    [self _startTimer];
    if (!_integrationKey) {
        [self _fireLoadFail:fanError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey")];
        [self _invalidateTimer];
        return;
    }
    NSLog(@"FANAdapter RewardVideo placementID: %@", [self _placementID]);
    _rewardedVideoAd = [[FBRewardedVideoAd alloc] initWithPlacementID:[self _placementID]];
    _rewardedVideoAd.delegate = self;
    [_rewardedVideoAd loadAdWithBidPayload:_biddingData];
}

#pragma mark - Load fail dispatcher

- (void)_fireLoadFail:(NSError *)error {
    switch (_adType) {
        case SSPAdBannerType:
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
                [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:error adapter:self];
            break;
        case SSPNativeAdType:
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadFailError:adapter:)])
                [_delegate AdPopcornSSPAdapterNativeAdLoadFailError:error adapter:self];
            break;
        case SSPAdInterstitialType:
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadFailError:adapter:)])
                [_delegate AdPopcornSSPAdapterInterstitialAdLoadFailError:error adapter:self];
            break;
        case SSPInterstitialVideoAdType:
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
                [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:error adapter:self];
            break;
        case SSPRewardVideoAdType:
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
                [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:error adapter:self];
            break;
        case SSPVideoMixAdType:
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
                [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:error adapter:self videoMixType:_videoMixAdType];
            break;
        default:
            break;
    }
}

#pragma mark - Timer

- (void)_startTimer {
    [self _invalidateTimer];
    _networkTimer = [NSTimer scheduledTimerWithTimeInterval:kFANNetworkTimeout
                                                     target:self
                                                   selector:@selector(_onTimeout:)
                                                   userInfo:nil
                                                    repeats:NO];
}

- (void)_invalidateTimer {
    [_networkTimer invalidate];
    _networkTimer = nil;
}

- (void)_onTimeout:(NSTimer *)timer {
    NSLog(@"FANAdapter load timeout adType:%d", _adType);
    if (_isCurrentRunningAdapter)
        [self _fireLoadFail:fanError(AdPopcornSSPLoadAdFailed, @"Load Ad Failed")];
    [self _invalidateTimer];
}

- (void)_addAlignCenterConstraint {
    if (!_adView) return;
    [_adView setTranslatesAutoresizingMaskIntoConstraints:NO];
    UIView *superview = _bannerView;
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:superview attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:superview attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:superview attribute:NSLayoutAttributeHeight multiplier:0.0 constant:_size.height]];
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:superview attribute:NSLayoutAttributeWidth multiplier:0.0 constant:_size.width]];
}

#pragma mark - FBAdViewDelegate

- (void)adView:(FBAdView *)adView didFailWithError:(NSError *)error {
    NSLog(@"adViewDidLoad didFailWithError : %@", error);
    adView.hidden = YES;
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
        [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:error adapter:self];
}

- (void)adViewDidLoad:(FBAdView *)adView {
    NSLog(@"FANAdapter adViewDidLoad");
    adView.hidden = NO;
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadSuccess:)])
        [_delegate AdPopcornSSPAdapterBannerViewLoadSuccess:self];
}

- (void)adViewDidClick:(FBAdView *)adView {
    NSLog(@"FANAdapter adViewDidClick");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewClicked:)])
        [_delegate AdPopcornSSPAdapterBannerViewClicked:self];
}

#pragma mark - FBInterstitialAdDelegate

- (void)interstitialAdDidLoad:(FBInterstitialAd *)interstitialAd {
    NSLog(@"FANAdapter interstitialAdDidLoad");
    if (_adType == SSPAdInterstitialType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadSuccess:)])
            [_delegate AdPopcornSSPAdapterInterstitialAdLoadSuccess:self];
    } else if (_adType == SSPInterstitialVideoAdType) {
        [self _invalidateTimer];
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:)])
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:self];
    } else if (_adType == SSPVideoMixAdType) {
        [self _invalidateTimer];
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadSuccess:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdLoadSuccess:self videoMixType:_videoMixAdType];
    }
}

- (void)interstitialAd:(FBInterstitialAd *)interstitialAd didFailWithError:(NSError *)error {
    NSLog(@"FANAdapter didFailWithError : %@", error);
    if (_adType == SSPAdInterstitialType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterInterstitialAdLoadFailError:error adapter:self];
    } else if (_adType == SSPInterstitialVideoAdType || _adType == SSPVideoMixAdType) {
        [self _invalidateTimer];
        [self _fireLoadFail:fanError(AdPopcornSSPLoadAdFailed, error.description ?: @"Load Ad Failed")];
    }
    [self closeAd];
}

- (void)interstitialAdWillLogImpression:(FBInterstitialAd *)interstitialAd {
    NSLog(@"FANAdapter interstitialAdWillLogImpression");
    if (_adType == SSPAdInterstitialType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdShowSuccess:)])
            [_delegate AdPopcornSSPAdapterInterstitialAdShowSuccess:self];
    } else if (_adType == SSPInterstitialVideoAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdShowSuccess:)])
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdShowSuccess:self];
    } else if (_adType == SSPVideoMixAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowSuccess:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdShowSuccess:self videoMixType:_videoMixAdType];
    }
    for (NSString *url in _impTrackersListArray) {
        if ([_delegate respondsToSelector:@selector(impClickTracking:)])
            [_delegate impClickTracking:url];
    }
}

- (void)interstitialAdDidClose:(FBInterstitialAd *)interstitialAd {
    NSLog(@"FANAdapter interstitialAdDidClose");
    if (_adType == SSPAdInterstitialType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdClosed:)])
            [_delegate AdPopcornSSPAdapterInterstitialAdClosed:self];
    } else if (_adType == SSPInterstitialVideoAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdClose:)])
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdClose:self];
        _isCurrentRunningAdapter = NO;
    } else if (_adType == SSPVideoMixAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdClose:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdClose:self videoMixType:_videoMixAdType];
        _isCurrentRunningAdapter = NO;
    }
}

- (void)interstitialAdDidClick:(FBInterstitialAd *)interstitialAd {
    NSLog(@"FANAdapter interstitialAdDidClick");
    for (NSString *url in _clickTrackersListArray) {
        if ([_delegate respondsToSelector:@selector(impClickTracking:)])
            [_delegate impClickTracking:url];
    }
}

#pragma mark - Native Ad display helpers

- (void)showNativeAd {
    if (self.nativeAd && self.nativeAd.isAdValid) {
        [self.nativeAd unregisterView];
        NSMutableArray *clickableViewArray = [[NSMutableArray alloc] init];
        if (fanNativeAdRenderer.adTitleLable)
            [clickableViewArray addObject:fanNativeAdRenderer.adTitleLable];
        if (fanNativeAdRenderer.adBodyLabel)
            [clickableViewArray addObject:fanNativeAdRenderer.adBodyLabel];
        if (fanNativeAdRenderer.adIconImageView)
            [clickableViewArray addObject:fanNativeAdRenderer.adIconImageView];
        if (fanNativeAdRenderer.adCoverMediaView)
            [clickableViewArray addObject:fanNativeAdRenderer.adCoverMediaView];
        if (fanNativeAdRenderer.adSocialContextLabel)
            [clickableViewArray addObject:fanNativeAdRenderer.adSocialContextLabel];
        if (fanNativeAdRenderer.adSponsoredLabel)
            [clickableViewArray addObject:fanNativeAdRenderer.adSponsoredLabel];
        if (fanNativeAdRenderer.adCallToActionButton)
            [clickableViewArray addObject:fanNativeAdRenderer.adCallToActionButton];
        [self.nativeAd registerViewForInteraction:fanNativeAdRenderer.adUIView mediaView:fanNativeAdRenderer.adCoverMediaView iconView:fanNativeAdRenderer.adIconImageView viewController:_viewController clickableViews:clickableViewArray];
        if (fanNativeAdRenderer.adTitleLable)
            fanNativeAdRenderer.adTitleLable.text = self.nativeAd.advertiserName;
        if (fanNativeAdRenderer.adBodyLabel)
            fanNativeAdRenderer.adBodyLabel.text = self.nativeAd.bodyText;
        if (fanNativeAdRenderer.adSocialContextLabel)
            fanNativeAdRenderer.adSocialContextLabel.text = self.nativeAd.socialContext;
        if (fanNativeAdRenderer.adSponsoredLabel)
            fanNativeAdRenderer.adSponsoredLabel.text = self.nativeAd.sponsoredTranslation;
        if (fanNativeAdRenderer.adCallToActionButton)
            [fanNativeAdRenderer.adCallToActionButton setTitle:self.nativeAd.callToAction forState:UIControlStateNormal];
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadSuccess:)])
            [_delegate AdPopcornSSPAdapterNativeAdLoadSuccess:self];
    } else {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterNativeAdLoadFailError:fanError(AdPopcornSSPInvalidNativeAssetsConfig, @"Invalid native assets config") adapter:self];
    }
}

- (void)showNativeBannerAd {
    if (self.nativeBannerAd && self.nativeBannerAd.isAdValid) {
        [self.nativeBannerAd unregisterView];
        NSMutableArray *clickableViewArray = [[NSMutableArray alloc] init];
        if (fanNativeBannerAdRenderer.adAdvertiserNameLabel) {
            fanNativeBannerAdRenderer.adAdvertiserNameLabel.text = self.nativeBannerAd.advertiserName;
            [clickableViewArray addObject:fanNativeBannerAdRenderer.adAdvertiserNameLabel];
        }
        if (fanNativeBannerAdRenderer.adSponsoredLabel) {
            fanNativeBannerAdRenderer.adSponsoredLabel.text = self.nativeBannerAd.sponsoredTranslation;
            [clickableViewArray addObject:fanNativeBannerAdRenderer.adSponsoredLabel];
        }
        if (self.nativeBannerAd.callToAction && fanNativeBannerAdRenderer.adCallToActionButton) {
            [fanNativeBannerAdRenderer.adCallToActionButton setHidden:NO];
            [fanNativeBannerAdRenderer.adCallToActionButton setTitle:self.nativeBannerAd.callToAction forState:UIControlStateNormal];
            [clickableViewArray addObject:fanNativeBannerAdRenderer.adCallToActionButton];
        } else {
            if (fanNativeBannerAdRenderer.adCallToActionButton)
                [fanNativeBannerAdRenderer.adCallToActionButton setHidden:YES];
        }
        if (fanNativeBannerAdRenderer.adAdvertiserNameLabel)
            fanNativeBannerAdRenderer.adAdvertiserNameLabel.nativeAdViewTag = FBNativeAdViewTagTitle;
        if (fanNativeBannerAdRenderer.adCallToActionButton)
            fanNativeBannerAdRenderer.adCallToActionButton.nativeAdViewTag = FBNativeAdViewTagCallToAction;
        [self.nativeBannerAd registerViewForInteraction:fanNativeBannerAdRenderer.adUIView iconView:fanNativeBannerAdRenderer.adIconImageView viewController:_viewController clickableViews:clickableViewArray];
        if (fanNativeBannerAdRenderer.adChoicesView) {
            fanNativeBannerAdRenderer.adChoicesView.corner = UIRectCornerTopLeft;
            fanNativeBannerAdRenderer.adChoicesView.nativeAd = self.nativeBannerAd;
        }
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadSuccess:)])
            [_delegate AdPopcornSSPAdapterNativeAdLoadSuccess:self];
    } else {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterNativeAdLoadFailError:fanError(AdPopcornSSPInvalidNativeAssetsConfig, @"Invalid native assets config") adapter:self];
    }
}

#pragma mark - FBNativeAdDelegate

- (void)nativeAdDidLoad:(FBNativeAd *)nativeAd {
    NSLog(@"FANAdapter nativeAdDidLoad...%@", nativeAd);
    self.nativeAd = nativeAd;
    [self showNativeAd];
}

- (void)nativeAd:(FBNativeAd *)nativeAd didFailWithError:(NSError *)error {
    NSLog(@"FANAdapter Native ad failed to load with error: %@", error);
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadFailError:adapter:)])
        [_delegate AdPopcornSSPAdapterNativeAdLoadFailError:error adapter:self];
}

- (void)nativeAdDidClick:(FBNativeAd *)nativeAd {
    NSLog(@"FANAdapter Native ad was clicked.");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdClicked:)])
        [_delegate AdPopcornSSPAdapterNativeAdClicked:self];
}

- (void)nativeAdWillLogImpression:(FBNativeAd *)nativeAd {
    NSLog(@"FANAdapter Native ad impression is being captured.");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdImpression:)])
        [_delegate AdPopcornSSPAdapterNativeAdImpression:self];
}

#pragma mark - FBNativeBannerAdDelegate

- (void)nativeBannerAdDidLoad:(FBNativeBannerAd *)nativeBannerAd {
    NSLog(@"FANAdapter nativeBannerAdDidLoad...%@", nativeBannerAd);
    self.nativeBannerAd = nativeBannerAd;
    [self showNativeBannerAd];
}

- (void)nativeBannerAd:(FBNativeBannerAd *)nativeBannerAd didFailWithError:(NSError *)error {
    NSLog(@"FANAdapter Native banner ad failed to load with error: %@", error);
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadFailError:adapter:)])
        [_delegate AdPopcornSSPAdapterNativeAdLoadFailError:error adapter:self];
}

- (void)nativeBannerAdDidClick:(FBNativeBannerAd *)nativeBannerAd {
    NSLog(@"FANAdapter Native banner ad was clicked.");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdClicked:)])
        [_delegate AdPopcornSSPAdapterNativeAdClicked:self];
}

- (void)nativeBannerAdDidFinishHandlingClick:(FBNativeBannerAd *)nativeBannerAd {
    NSLog(@"Native banner ad did finish click handling.");
}

- (void)nativeBannerAdWillLogImpression:(FBNativeBannerAd *)nativeBannerAd {
    NSLog(@"FANAdapter Native banner ad impression is being captured.");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdImpression:)])
        [_delegate AdPopcornSSPAdapterNativeAdImpression:self];
}

#pragma mark - FBRewardedVideoAdDelegate

- (void)rewardedVideoAd:(FBRewardedVideoAd *)rewardedVideoAd didFailWithError:(NSError *)error {
    NSLog(@"FANAdapter didFailWithError : %@", error);
    [self _invalidateTimer];
    [self _fireLoadFail:fanError(AdPopcornSSPLoadAdFailed, error.description ?: @"Load Ad Failed")];
}

- (void)rewardedVideoAdDidLoad:(FBRewardedVideoAd *)rewardedVideoAd {
    NSLog(@"FANAdapter rewardedVideoAdDidLoad");
    [self _invalidateTimer];
    if (_adType == SSPVideoMixAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadSuccess:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdLoadSuccess:self videoMixType:_videoMixAdType];
    } else {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadSuccess:)])
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadSuccess:self];
    }
}

- (void)rewardedVideoAdDidClick:(FBRewardedVideoAd *)rewardedVideoAd {
    NSLog(@"FANAdapter rewardedVideoAdDidClick");
    for (NSString *url in _clickTrackersListArray) {
        if ([_delegate respondsToSelector:@selector(impClickTracking:)])
            [_delegate impClickTracking:url];
    }
}

- (void)rewardedVideoAdVideoComplete:(FBRewardedVideoAd *)rewardedVideoAd {
    NSLog(@"FANAdapter rewardedVideoAdVideoComplete");
    if (_adType == SSPVideoMixAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdCompleteTrackingEvent:isCompleted:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdCompleteTrackingEvent:_adNetworkNo isCompleted:YES videoMixType:_videoMixAdType];
    } else {
        if ([_delegate respondsToSelector:@selector(onCompleteTrackingEvent:isCompleted:)])
            [_delegate onCompleteTrackingEvent:_adNetworkNo isCompleted:YES];
    }
}

- (void)rewardedVideoAdWillLogImpression:(FBRewardedVideoAd *)rewardedVideoAd {
    NSLog(@"FANAdapter rewardedVideoAdWillLogImpression");
    if (_adType == SSPVideoMixAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowSuccess:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdShowSuccess:self videoMixType:_videoMixAdType];
    } else {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowSuccess:)])
            [_delegate AdPopcornSSPAdapterRewardVideoAdShowSuccess:self];
    }
    for (NSString *url in _impTrackersListArray) {
        if ([_delegate respondsToSelector:@selector(impClickTracking:)])
            [_delegate impClickTracking:url];
    }
}

- (void)rewardedVideoAdDidClose:(FBRewardedVideoAd *)rewardedVideoAd {
    NSLog(@"FANAdapter rewardedVideoAdDidClose");
    if (_adType == SSPVideoMixAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdClose:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdClose:self videoMixType:_videoMixAdType];
    } else {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdClose:)])
            [_delegate AdPopcornSSPAdapterRewardVideoAdClose:self];
    }
    _isCurrentRunningAdapter = NO;
}

@end

@implementation APFANNativeAdRenderer

- (instancetype)init {
    self = [super init];
    return self;
}

@end

@implementation APFANNativeBannerAdRenderer

- (instancetype)init {
    self = [super init];
    return self;
}

@end
