//
//  FyberAdapter.m
//  AdPopcornSSP
//
//  Created by mick on 2020. 10. 28..
//  Copyright (c) 2019년 igaworks All rights reserved.
//

// compatible with Fyber v8.3.6 (FairBid SDK 3.47.0)
#import "FyberAdapter.h"

static inline NSString *SSPErrorString(SSPErrorCode code)
{
    switch (code)
    {
        case AdPopcornSSPException:
            return @"Exception";
        case AdPopcornSSPInvalidParameter:
            return @"Invalid Parameter";
        case AdPopcornSSPUnknownServerError:
            return @"Unknown Server Error";
        case AdPopcornSSPInvalidMediaKey:
            return @"Invalid Media key";
        case AdPopcornSSPInvalidPlacementId:
            return @"Invalid Placement Id";
        case AdPopcornSSPInvalidNativeAssetsConfig:
            return @"Invalid native assets config";
        case AdPopcornSSPNativePlacementDoesNotInitialized:
            return @"Native Placement Does Not Initialized";
        case AdPopcornSSPServerTimeout:
            return @"Server Timeout";
        case AdPopcornSSPLoadAdFailed:
            return @"Load Ad Failed";
        case AdPopcornSSPNoAd:
            return @"No Ad";
        case AdPopcornSSPNoInterstitialLoaded:
            return @"No Interstitial Loaded";
        case AdPopcornSSPNoRewardVideoAdLoaded:
            return @"No Reward video ad Loaded";
        case AdPopcornSSPMediationAdapterNotInitialized:
            return @"Mediation Adapter Not Initialized";
        case AdPopcornSSPNoInterstitialVideoAdLoaded:
            return @"No Interstitial video ad Loaded";
        default: {
            return @"Success";
        }
    }
}

@interface FyberAdapter () <IAUnitDelegate, IAVideoContentDelegate, IANativeAdDelegate, IAMRAIDContentDelegate>
{
    BOOL _isCurrentRunningAdapter;
    NSString *fyberAppId, *fyberSpotId;
    NSTimer *networkScheduleTimer;
    NSInteger adNetworkNo;
    
    NSMutableArray *_impTrackersListArray, *_clickTrackersListArray;
    NSString *_biddingData;
    BOOL _isInAppBidding;
    VideoMixAdType videoMixAdType;
    APFyberAdapterNativeAdRenderer *fyberNativeAdRenderer;
}

@end

@implementation FyberAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;
@synthesize viewController = _viewController;
@synthesize bannerView = _bannerView;
@synthesize adpopcornSSPNativeAd = _adpopcornSSPNativeAd;

- (instancetype)init
{
    self = [super init];
    if (self){}
    adNetworkNo = 16;
    return self;
}

- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(AdPopcornSSPBannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = SSPAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPAdInterstitialType;
}

- (void)setRewardVideoViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPRewardVideoAdType;
}

- (void)setInterstitialVideoViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPInterstitialVideoAdType;
}

- (void)setVideoMixAdViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPVideoMixAdType;
}

- (void)setNativeAdViewController:(UIViewController *)viewController nativeAdRenderer:(id)nativeAdRenderer rootNativeAdView:(AdPopcornSSPNativeAd *)adpopcornSSPNativeAd
{
    _viewController = viewController;
    _adType = SSPNativeAdType;
    if([nativeAdRenderer isKindOfClass:[APFyberAdapterNativeAdRenderer class]])
        fyberNativeAdRenderer = nativeAdRenderer;
    _adpopcornSSPNativeAd = adpopcornSSPNativeAd;
}

- (BOOL)isSupportInterstitialAd
{
    return YES;
}

- (BOOL)isSupportRewardVideoAd
{
    return YES;
}

- (BOOL)isSupportInterstitialVideoAd
{
    return YES;
}

- (BOOL)isSupportVideoMixAd
{
    return YES;
}

- (void)setBiddingData:(NSString *)biddingData impressionList:(NSMutableArray *)impTrackersListArray clickList: (NSMutableArray *)clickTrackersListArray
{
    _biddingData = biddingData;
    _impTrackersListArray = impTrackersListArray;
    _clickTrackersListArray =  clickTrackersListArray;
}

- (NSString *)getBiddingToken
{
    return FMPBiddingManager.sharedInstance.biddingToken;
}

- (void)setInAppBiddingMode:(bool)isInAppBiddingMode
{
    _isInAppBidding = isInAppBiddingMode;
    NSLog(@"FyberAdapter setInAppBiddingMode : %d", _isInAppBidding);
}

- (void)loadAd
{
    if(networkScheduleTimer == nil)
    {
        networkScheduleTimer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(networkScheduleTimeoutHandler:) userInfo:nil repeats:NO];
    }
    else{
        [self invalidateNetworkTimer];
        networkScheduleTimer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(networkScheduleTimeoutHandler:) userInfo:nil repeats:NO];
    }
    
    if (_adType == SSPAdBannerType) {
        [self setupBanner:@"Banner"];
    }
    else if (_adType == SSPNativeAdType) {
        [self setupNativeAd:@"Native"]; // only Bidding 제공
    }
    else if (_adType == SSPAdInterstitialType) {
        [self setupInterstitial:@"Interstitial"];
    }
    else if (_adType == SSPInterstitialVideoAdType) {
        [self setupInterstitialVideo:@"InterstitialVideo"];
    }
    else if (_adType == SSPRewardVideoAdType) {
        [self setupRewardVideo:@"RewardVideo"];
    }
    else if (_adType == SSPVideoMixAdType) {
        if(_isInAppBidding) {
            // inApp Bidding 일 경우에는 Reward Video만 호출
            videoMixAdType = VideoMix_RewardVideoType;
            [self setupRewardVideo:@"VideoMix_RewardVideo"];
        }
        else {
            NSNumber *campaignType = [_integrationKey valueForKey:@"CampaignType"];
            NSInteger campaignValue = [campaignType integerValue];
            videoMixAdType = SSPVideoMixAdTypeFromInteger(campaignValue);
            
            switch (videoMixAdType) {
                case VideoMix_InterstitialType:
                    [self setupInterstitial:@"VideoMix_Interstitial"];
                    break;
                    
                case VideoMix_InterstitialVideoType:
                    [self setupInterstitialVideo:@"VideoMix_InterstitialVideo"];
                    break;
                    
                case VideoMix_RewardVideoType:
                    [self setupRewardVideo:@"VideoMix_RewardVideo"];
                    break;
            }
        }
        
    }
}

-(void)isNotSupport:(SSPAdType) adType {
    switch (adType) {
        case SSPAdBannerType:
            NSLog(@"FyberAdapter is not support :%u", _adType);
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
            }
            break;
        case SSPNativeAdType:
            NSLog(@"FyberAdapter is not support :%u", _adType);
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterNativeAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
            }
            break;
        case SSPAdInterstitialType:
            NSLog(@"FyberAdapter is not support :%u", _adType);
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitialAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
            }
            break;
        case SSPInterstitialVideoAdType:
            NSLog(@"FyberAdapter is not support :%u", _adType);
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
            }
            break;
        case SSPRewardVideoAdType:
            NSLog(@"FyberAdapter is not support :%u", _adType);
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
            }
            break;
        case SSPVideoMixAdType:
            NSLog(@"FyberAdapter is not support :%u , videomix: %d", _adType, videoMixAdType);
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter: videoMixType:)])
            {
                [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self videoMixType:videoMixAdType];
            }
            break;
        default:
            break;
    }
}

- (void)addAlignCenterConstraint
{
    UIView *adView = _bannerViewController.adView;
    UIView *superview = _bannerView;

    adView.translatesAutoresizingMaskIntoConstraints = NO;

    [NSLayoutConstraint activateConstraints:@[
        [adView.centerXAnchor constraintEqualToAnchor:superview.centerXAnchor],
        [adView.centerYAnchor constraintEqualToAnchor:superview.centerYAnchor],
        [adView.widthAnchor constraintEqualToConstant:_size.width],
        [adView.heightAnchor constraintEqualToConstant:_size.height]
    ]];
}

-(void)setupBanner:(NSString*) typeName {
    NSLog(@"FyberAdapter : %@ loadAd", typeName);
    _isCurrentRunningAdapter = YES;
    if (_integrationKey != nil)
    {
        if(_isInAppBidding) {
            fyberAppId = [_integrationKey valueForKey:@"thirdparty_id"];
            fyberSpotId = [_integrationKey valueForKey:@"fyber_placement_id"];
        }
        else {
            fyberAppId = [_integrationKey valueForKey:@"FyberAppId"];
            fyberSpotId = [_integrationKey valueForKey:@"FyberSpotId"];
        }
        
        IAAdRequest *adRequest =
        [IAAdRequest build:^(id<IAAdRequestBuilder>  _Nonnull builder) {
            builder.useSecureConnections = YES;
            builder.spotID = fyberSpotId;
            builder.timeout = 10;
        }];
        
        IAMRAIDContentController *mraidContentController =
        [IAMRAIDContentController build: ^(id<IAMRAIDContentControllerBuilder>  _Nonnull builder) {
            builder.MRAIDContentDelegate = self;
        }];
        _mraidContentController = mraidContentController;
        
        IAViewUnitController *viewUnitController =
        [IAViewUnitController build:^(id<IAViewUnitControllerBuilder>  _Nonnull builder) {
            builder.unitDelegate = self;
            [builder addSupportedContentController: _mraidContentController];
        }];
        
        _bannerViewController = viewUnitController;
        
        IAAdSpot *adSpot = [IAAdSpot build:^(id<IAAdSpotBuilder>  _Nonnull builder) {
            builder.adRequest = adRequest;
            [builder addSupportedUnitController:_bannerViewController];
        }];
        
        _adSpot = adSpot;
        
        
        
        if(_isInAppBidding) {
            [_adSpot loadAdWithMarkup: _biddingData withCompletion:^(IAAdSpot * _Nullable adSpot, IAAdModel * _Nullable adModel, NSError * _Nullable error) {
                if (error) {
                    NSLog(@"FyberAdapter anner Error : %@", error);
                    if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
                    {
                        [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
                    }
                }
                else {
                    NSLog(@"FyberAdapter anner Success");
                    [_bannerView addSubview:_bannerViewController.adView];
                    
                    if(_bannerView != nil) {
                        [self addAlignCenterConstraint];
                    }
                    
                    if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadSuccess:)])
                    {
                        [_delegate AdPopcornSSPAdapterBannerViewLoadSuccess:self];
                    }
                }
                [self invalidateNetworkTimer];
            }];
            
        }
        else {
            [_adSpot fetchAdWithCompletion:^(IAAdSpot * _Nullable adSpot, IAAdModel * _Nullable adModel, NSError * _Nullable error) {
                if (error)
                {
                    NSLog(@"FyberAdapter fetchAdWithCompletion Error : %@", error);
                    if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
                    {
                        [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
                    }
                }
                else
                {
                    NSLog(@"FyberAdapter fetchAdWithCompletion Success");
                    if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadSuccess:)])
                    {
                        [_delegate AdPopcornSSPAdapterBannerViewLoadSuccess:self];
                    }
                }
                [self invalidateNetworkTimer];
            }];
        }
    }
    else
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
        }
        [self closeAd];
    }
}

-(void)setupNativeAd:(NSString*) typeName {
    NSLog(@"FyberAdapter : %@ loadAd", typeName);
    _isCurrentRunningAdapter = YES;
    // fyber 는 Inappbidding 만 지원
    if(!_isInAppBidding) {
        NSLog(@"Fyber only provides bidding");
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
        }
        
        [self closeAd];
        return;
    }
    
    if (_integrationKey != nil)
    {
        if(_isInAppBidding) {
            fyberAppId = [_integrationKey valueForKey:@"thirdparty_id"];
            fyberSpotId = [_integrationKey valueForKey:@"fyber_placement_id"];
        }
        else { // 제공 안함
//            fyberAppId = [_integrationKey valueForKey:@"FyberAppId"];
//            fyberSpotId = [_integrationKey valueForKey:@"FyberSpotId"];
        }
        
        IAAdRequest *adRequest =
        [IAAdRequest build:^(id<IAAdRequestBuilder>  _Nonnull builder) {
//            builder.useSecureConnections = YES;   // 8.3.5 ver 이후 지원 중단
            builder.spotID = fyberSpotId;
            builder.timeout = 10;
        }];
        
        IANativeAdSpot *nativeAdSpot = [IANativeAdSpot build:^(id<IANativeAdSpotBuilder> _Nonnull builder) {
            builder.adRequest = adRequest;
            builder.delegate = self;
//            builder.userInfo = @{@"placementIdentifier": parameters.thirdPartyAdPlacementIdentifier}; // Optional
        }];
        
        
        _nativeAdSpot = nativeAdSpot;
        [_nativeAdSpot loadAdWithMarkup:_biddingData withCompletion:^(IANativeAdAssets *nativeAdAssets, NSError *error) {
            
            if (error) {
                NSLog(@"FyberAdapter NatievAd Error : %@", error);
                if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadFailError:adapter:)])
                {
                    [_delegate AdPopcornSSPAdapterNativeAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
                }
            }
            else {
                if (nativeAdAssets != nil) {
                    if(fyberNativeAdRenderer.adUIView == nil) {
                        NSLog(@"please connect NatievAd adUIView");
                        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
                        {
                            [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
                        }
                        
                        [self closeAd];
                        return;
                    }
                    if(fyberNativeAdRenderer.adTitle != nil) {
                        fyberNativeAdRenderer.adTitle.text = nativeAdAssets.adTitle;
                    }
                    if(fyberNativeAdRenderer.adDescription != nil) {
                        fyberNativeAdRenderer.adDescription.text = nativeAdAssets.adDescription;
                    }
                    if(fyberNativeAdRenderer.callToActionText != nil) {
                        fyberNativeAdRenderer.callToActionText.text = nativeAdAssets.callToActionText;
                    }
                    if(fyberNativeAdRenderer.appIcon != nil) {
                        fyberNativeAdRenderer.appIcon = nativeAdAssets.appIcon;
                    }
                    if(fyberNativeAdRenderer.mediaView != nil) {
                        fyberNativeAdRenderer.mediaView = nativeAdAssets.mediaView;
                    }
                    fyberNativeAdRenderer.rating = [nativeAdAssets.rating doubleValue];
                    fyberNativeAdRenderer.mediaAspectRatio = [nativeAdAssets.mediaAspectRatio doubleValue];
//                    NSString *advertiserName = nativeAdAssets.advertiserName;
                }
                

                
                NSLog(@"FyberAdapter NatievAd Success");
                if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadSuccess:)])
                {
                    [_delegate AdPopcornSSPAdapterNativeAdLoadSuccess:self];
                }
                [self invalidateNetworkTimer];
            }
        }];
    }
    else
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
        }
        
        [self closeAd];
    }
}

-(void)setupInterstitial:(NSString*) typeName {
    NSLog(@"FyberAdapter : %@ loadAd", typeName);
    _isCurrentRunningAdapter = YES;
    if (_integrationKey != nil)
    {
        
        fyberAppId = [_integrationKey valueForKey:@"FyberAppId"];
        fyberSpotId = [_integrationKey valueForKey:@"FyberSpotId"];
        
        IAAdRequest *adRequest =
        [IAAdRequest build:^(id<IAAdRequestBuilder>  _Nonnull builder) {
            builder.useSecureConnections = YES;
            builder.spotID = fyberSpotId;
            builder.timeout = 10;
        }];
        
        IAVideoContentController *videoContentController =
        [IAVideoContentController build:
         ^(id<IAVideoContentControllerBuilder>  _Nonnull builder) {
            builder.videoContentDelegate = self; // a delegate should be passed in order to get video content related callbacks;
        }];
        
        _videoContentController = videoContentController;
        
        IAFullscreenUnitController *fullscreenUnitController =
        [IAFullscreenUnitController build:^(id<IAFullscreenUnitControllerBuilder> _Nonnull builder)
         {
            builder.unitDelegate = self;
            // all the needed content controllers should be added to the desired unit controller:
            [builder addSupportedContentController:_videoContentController];
        }];
        
        _fullscreenUnitController = fullscreenUnitController;
        
        IAAdSpot *adSpot = [IAAdSpot build:^(id<IAAdSpotBuilder>  _Nonnull builder) {
            builder.adRequest = adRequest; // pass here the ad request object;
            // all the supported (by a client side) unit controllers,
            // (in this case - view unit controller) should be added to the desired ad spot:
            [builder addSupportedUnitController:_fullscreenUnitController];
        }];
        
        _adSpot = adSpot;
        
        [_adSpot fetchAdWithCompletion:^(IAAdSpot * _Nullable adSpot, IAAdModel * _Nullable adModel, NSError * _Nullable error) {
            if (error)
            {
                NSLog(@"FyberAdapter fetchAdWithCompletion Error : %@", error);
                if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadFailError:adapter:)])
                {
                    [_delegate AdPopcornSSPAdapterInterstitialAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
                }
                
            }
            else
            {
                NSLog(@"FyberAdapter fetchAdWithCompletion Success");
                if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadSuccess:)])
                {
                    [_delegate AdPopcornSSPAdapterInterstitialAdLoadSuccess:self];
                }
            }
            [self invalidateNetworkTimer];
        }];
    }
    else
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
        }
        [self closeAd];
    }
}



-(void)setupInterstitialVideo:(NSString*) typeName {
    NSLog(@"FyberAdapter : %@ loadAd", typeName);
    _isCurrentRunningAdapter = YES;
    if (_integrationKey != nil)
    {
        
        if(_isInAppBidding) {
            fyberAppId = [_integrationKey valueForKey:@"thirdparty_id"];
            fyberSpotId = [_integrationKey valueForKey:@"fyber_placement_id"];
        }
        else {
            fyberAppId = [_integrationKey valueForKey:@"FyberAppId"];
            fyberSpotId = [_integrationKey valueForKey:@"FyberSpotId"];
        }

        
        IAAdRequest *adRequest =
        [IAAdRequest build:^(id<IAAdRequestBuilder>  _Nonnull builder) {
//            builder.useSecureConnections = YES;
            builder.spotID = fyberSpotId;
            builder.timeout = 10;
        }];
        
        IAVideoContentController *videoContentController =
        [IAVideoContentController build:
         ^(id<IAVideoContentControllerBuilder>  _Nonnull builder) {
            builder.videoContentDelegate = self; // a delegate should be passed in order to get video content related callbacks;
        }];
        
        _videoContentController = videoContentController;
        
        IAFullscreenUnitController *fullscreenUnitController =
        [IAFullscreenUnitController build:^(id<IAFullscreenUnitControllerBuilder> _Nonnull builder)
         {
            builder.unitDelegate = self;
            // all the needed content controllers should be added to the desired unit controller:
            [builder addSupportedContentController:_videoContentController];
        }];
        
        _fullscreenUnitController = fullscreenUnitController;
        
        IAAdSpot *adSpot = [IAAdSpot build:^(id<IAAdSpotBuilder>  _Nonnull builder) {
            builder.adRequest = adRequest; // pass here the ad request object;
            // all the supported (by a client side) unit controllers,
            // (in this case - view unit controller) should be added to the desired ad spot:
            [builder addSupportedUnitController:_fullscreenUnitController];
        }];
        
        _adSpot = adSpot;
        
        if(_isInAppBidding) {
            [_adSpot loadAdWithMarkup: _biddingData withCompletion:^(IAAdSpot * _Nullable adSpot, IAAdModel * _Nullable adModel, NSError * _Nullable error) {
                if (error) {
                    NSLog(@"FyberAdapter InterstitialViideo Error : %@", error);
                    if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
                    {
                        [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
                    }
                }
                else {
                    NSLog(@"FyberAdapter InterstitialViideo Success");
                    if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:)])
                    {
                        [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:self];
                    }
                
                }
                [self invalidateNetworkTimer];
            }];
            
        }
        else {
            [_adSpot fetchAdWithCompletion:^(IAAdSpot * _Nullable adSpot, IAAdModel * _Nullable adModel, NSError * _Nullable error) {
                if (error)
                {
                    if (videoMixAdType == VideoMix_InterstitialVideoType) {
                        NSLog(@"FyberAdapter InterstitialViideo Error : %@", error);
                        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
                        {
                            [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self videoMixType: videoMixAdType];
                        }
                    }
                    else {
                        NSLog(@"FyberAdapter InterstitialViideo Error : %@", error);
                        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
                        {
                            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
                        }
                    }
                }
                else
                {
                    if (videoMixAdType == VideoMix_InterstitialVideoType) {
                        NSLog(@"FyberAdapter InterstitialViideo Success");
                        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadSuccess:videoMixType:)])
                        {
                            [_delegate AdPopcornSSPAdapterVideoMixAdLoadSuccess:self videoMixType:videoMixAdType];
                        }
                    }
                    else {
                        NSLog(@"FyberAdapter InterstitialViideo Success");
                        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:)])
                        {
                            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:self];
                        }
                    }
                }
                [self invalidateNetworkTimer];
            }];
        }
    }
    else
    {
        if (videoMixAdType == VideoMix_InterstitialVideoType) {
            NSLog(@"FyberAdapter rv no integrationKey");
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
            {
                [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self videoMixType:videoMixAdType];
            }
        }
        else {
            NSLog(@"FyberAdapter rv no integrationKey");
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
        }
        [self closeAd];
    }
}

-(void)setupRewardVideo:(NSString*) typeName {
    NSLog(@"FyberAdapter %@ : %@ loadAd", self, typeName);
    _isCurrentRunningAdapter = YES;
    if (_integrationKey != nil)
    {
        if(_isInAppBidding) {
            fyberAppId = [_integrationKey valueForKey:@"thirdparty_id"];
            fyberSpotId = [_integrationKey valueForKey:@"fyber_placement_id"];
        }
        else {
            fyberAppId = [_integrationKey valueForKey:@"FyberAppId"];
            fyberSpotId = [_integrationKey valueForKey:@"FyberSpotId"];
        }
        
        IAAdRequest *adRequest =
        [IAAdRequest build:^(id<IAAdRequestBuilder>  _Nonnull builder) {
            builder.useSecureConnections = YES;
            builder.spotID = fyberSpotId;
            builder.timeout = 10;
        }];
        
        IAVideoContentController *videoContentController =
        [IAVideoContentController build:
         ^(id<IAVideoContentControllerBuilder>  _Nonnull builder) {
            builder.videoContentDelegate = self; // a delegate should be passed in order to get video content related callbacks;
        }];
        
        _videoContentController = videoContentController;
        
        IAFullscreenUnitController *fullscreenUnitController =
        [IAFullscreenUnitController build:^(id<IAFullscreenUnitControllerBuilder> _Nonnull builder)
         {
            builder.unitDelegate = self;
            // all the needed content controllers should be added to the desired unit controller:
            [builder addSupportedContentController:_videoContentController];
        }];
        
        _fullscreenUnitController = fullscreenUnitController;
        
        IAAdSpot *adSpot = [IAAdSpot build:^(id<IAAdSpotBuilder>  _Nonnull builder) {
            builder.adRequest = adRequest; // pass here the ad request object;
            // all the supported (by a client side) unit controllers,
            // (in this case - view unit controller) should be added to the desired ad spot:
            [builder addSupportedUnitController:_fullscreenUnitController];
        }];
        
        _adSpot = adSpot;
        
        if(_isInAppBidding) {
            [_adSpot loadAdWithMarkup: _biddingData withCompletion:^(IAAdSpot * _Nullable adSpot, IAAdModel * _Nullable adModel, NSError * _Nullable error) {
                if (error) {
                    if (videoMixAdType == VideoMix_RewardVideoType) {
                        NSLog(@"FyberAdapter  %@ interstitial video error %@", typeName, error);
                        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
                        {
                            [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self videoMixType: videoMixAdType];
                        }
                    }
                    else {
                        NSLog(@"FyberAdapter  %@ interstitial video error %@", typeName, error);
                        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
                        {
                            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
                        }
                    }
                }
                else {
                    if (videoMixAdType == VideoMix_RewardVideoType) {
                        NSLog(@"FyberAdapter %@ load success", typeName);
                        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadSuccess:videoMixType:)])
                        {
                            [_delegate AdPopcornSSPAdapterVideoMixAdLoadSuccess:self videoMixType:videoMixAdType];
                        }
                    }
                    else {
                        NSLog(@"FyberAdapter %@ load success", typeName);
                        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadSuccess:)])
                        {
                            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadSuccess:self];
                        }
                    }
                }
                [self invalidateNetworkTimer];
            }];
        }
        else {
            [_adSpot fetchAdWithCompletion:^(IAAdSpot * _Nullable adSpot, IAAdModel * _Nullable adModel, NSError * _Nullable error) {
                if (error)
                {
                    NSLog(@"FyberAdapter fetchAdWithCompletion Error : %@", error);
                    if (videoMixAdType == VideoMix_RewardVideoType) {
                        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
                        {
                            [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self videoMixType:videoMixAdType];
                        }
                    }
                    else {
                        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
                        {
                            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
                        }
                    }
                }
                else
                {
                    NSLog(@"FyberAdapter fetchAdWithCompletion Success");
                    if (videoMixAdType == VideoMix_RewardVideoType) {
                        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadSuccess:videoMixType:)])
                        {
                            [_delegate AdPopcornSSPAdapterVideoMixAdLoadSuccess:self videoMixType:videoMixAdType];
                        }
                    }
                    else {
                        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadSuccess:)])
                        {
                            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadSuccess:self];
                        }
                    }
                }
                [self invalidateNetworkTimer];
            }];
        }
    }
    else
    {
        NSLog(@"FyberAdapter %@ no integrationKey", typeName);
        if (videoMixAdType == VideoMix_RewardVideoType) {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
            {
                [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self videoMixType:videoMixAdType];
            }
        }
        else {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
        }
        [self closeAd];
        
    }
}

- (void)showAd
{
    NSLog(@"FyberAdapter : showAd : %d", _adType);
    
    if (_adType == SSPAdInterstitialType) {
        if(_adSpot.activeUnitController == _fullscreenUnitController) {
            [_fullscreenUnitController showAdAnimated:YES completion:nil];
        }
        else {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdShowFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitialAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoInterstitialLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoInterstitialLoaded)}] adapter:self];
            }
        }
    }
    else if (_adType == SSPInterstitialVideoAdType)
    {
        if (_adSpot.activeUnitController == _fullscreenUnitController) {
            [_fullscreenUnitController showAdAnimated:YES completion:nil];
        }
        else
        {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdShowFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitialVideoAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoInterstitialVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoInterstitialVideoAdLoaded)}] adapter:self];
            }
        }
    }
    if (_adType == SSPRewardVideoAdType)
    {
        if (_adSpot.activeUnitController == _fullscreenUnitController)
        {
            [_fullscreenUnitController showAdAnimated:YES completion:nil];
        }
        else
        {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoRewardVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoRewardVideoAdLoaded)}] adapter:self];
            }
        }
    }
    else if (_adType == SSPVideoMixAdType){
        switch (videoMixAdType) {
            case VideoMix_InterstitialType:
                break;
                
            case VideoMix_InterstitialVideoType:
                if (_adSpot.activeUnitController == _fullscreenUnitController) {
                    [_fullscreenUnitController showAdAnimated:YES completion:nil];
                }
                else
                {
                    if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowFailError:adapter:videoMixType:)])
                    {
                        [_delegate AdPopcornSSPAdapterVideoMixAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoRewardVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoRewardVideoAdLoaded)}] adapter:self videoMixType:videoMixAdType];
                    }
                }
                break;
                
            case VideoMix_RewardVideoType:
                if (_adSpot.activeUnitController == _fullscreenUnitController)
                {
                    [_fullscreenUnitController showAdAnimated:YES completion:nil];
                }
                else
                {
                    if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowFailError:adapter:videoMixType:)])
                    {
                        [_delegate AdPopcornSSPAdapterVideoMixAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoRewardVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoRewardVideoAdLoaded)}] adapter:self videoMixType:videoMixAdType];
                    }
                }
                break;
        }
    }
}

- (void)closeAd
{
    NSLog(@"FyberAdapter closeAd");
    _isCurrentRunningAdapter = NO;
    [self invalidateNetworkTimer];
}

- (void)loadRequest
{
    // Not used any more
}

-(void)networkScheduleTimeoutHandler:(NSTimer*) timer
{
    if(_adType == SSPRewardVideoAdType)
    {
        NSLog(@"FyberAdapter rv load timeout");
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
        }
    }
    
    if(_adType == SSPInterstitialVideoAdType)
    {
        NSLog(@"FyberAdapter rv load timeout");
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
        }
    }
    if (_adType == SSPVideoMixAdType) {
        switch (videoMixAdType) {
            case VideoMix_InterstitialType:
                break;
                
            default:
                NSLog(@"FyberAdapter VideoMix_RewarVideo load timeout");
                if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
                {
                    [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self videoMixType:videoMixAdType];
                }
                break;
        }
    }
    
    [self invalidateNetworkTimer];
}

-(void)invalidateNetworkTimer
{
    if(networkScheduleTimer != nil)
        [networkScheduleTimer invalidate];
}

#pragma IAUnitDelegate

- (UIViewController * _Nonnull)IAParentViewControllerForUnitController:(IAUnitController * _Nullable)unitController
{
    NSLog(@"FyberAdapter IAParentViewControllerForUnitController");
    return _viewController;
}

- (void)IAAdDidReward:(IAUnitController * _Nullable)unitController
{
    NSLog(@"FyberAdapter IAAdDidReward");
    if (_adType == SSPVideoMixAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdCompleteTrackingEvent:isCompleted:videoMixType:)])
        {
            [_delegate AdPopcornSSPAdapterVideoMixAdCompleteTrackingEvent:adNetworkNo isCompleted:YES videoMixType:videoMixAdType];
        }
    } else {
        if ([_delegate respondsToSelector:@selector(onCompleteTrackingEvent:isCompleted:)])
        {
            [_delegate onCompleteTrackingEvent:adNetworkNo isCompleted:YES];
        }
    }
}

- (void)IAUnitControllerDidPresentFullscreen:(IAUnitController * _Nullable)unitController
{
    NSLog(@"FyberAdapter IAUnitControllerDidPresentFullscreen");

    if (_adType == SSPInterstitialVideoAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdShowSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdShowSuccess:self];
        }
    } else if (_adType == SSPRewardVideoAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdShowSuccess:self];
        }
    } else if (_adType == SSPVideoMixAdType) {
        switch (videoMixAdType) {
            case VideoMix_InterstitialType:
                break;
                
            default:
                if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowSuccess:videoMixType:)])
                {
                    [_delegate AdPopcornSSPAdapterVideoMixAdShowSuccess:self videoMixType:videoMixAdType];
                }
                break;
        }
        
    }
}

- (void)IAUnitControllerDidDismissFullscreen:(IAUnitController * _Nullable)unitController
{
    NSLog(@"FyberAdapter IAUnitControllerDidDismissFullscreen");
    
    if (_adType == SSPInterstitialVideoAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdClose:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdClose:self];
        }
    } else if (_adType == SSPRewardVideoAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdClose:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdClose:self];
        }
    } else if (_adType == SSPVideoMixAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdClose:videoMixType:)])
        {
            [_delegate AdPopcornSSPAdapterVideoMixAdClose:self videoMixType:videoMixAdType];
        }
    }

    _isCurrentRunningAdapter = NO;
}

#pragma IAVideoContentDelegate
@end


@implementation APFyberAdapterNativeAdRenderer
{
}

- (instancetype)init
{
    self = [super init];
    if(self)
    {
    }
    return self;
}
@end
