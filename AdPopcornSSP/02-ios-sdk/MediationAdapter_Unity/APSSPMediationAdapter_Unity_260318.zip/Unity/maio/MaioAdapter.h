//
//  MaioAdapter.h
//  AdPopcornSSP
//
//  compatible with MaioSDK v2
//

// MaioSDK v2 is a Swift framework; import via generated header

#import <Maio/Maio-Swift.h>

// Using pod install / unity
#import <AdPopcornSSP/AdPopcornSSPAdapter.h>
// else
//#import "AdPopcornSSPAdapter.h"

@interface MaioAdapter : AdPopcornSSPAdapter
{
    MaioInterstitial *_interstitialVideoAd;
    MaioRewarded   *_rewardedAd;
}

@end
