//
//  MaioAdapter.m
//  AdPopcornSSP
//
//  compatible with MaioSDK v2
//

#import "MaioAdapter.h"

static inline NSError *maioError(SSPErrorCode code, NSString *desc) {
    return [NSError errorWithDomain:kAdPopcornSSPErrorDomain
                               code:code
                           userInfo:@{NSLocalizedDescriptionKey: desc}];
}

@interface MaioAdapter () <MaioInterstitialLoadCallback, MaioInterstitialShowCallback, MaioRewardedLoadCallback, MaioRewardedShowCallback>
{
    NSInteger        _adNetworkNo;
    BOOL             _isCurrentRunningAdapter;
    NSTimer         *_networkTimer;
    VideoMixAdType   _videoMixAdType;

}
@end

@implementation MaioAdapter

@synthesize delegate       = _delegate;
@synthesize integrationKey = _integrationKey;
@synthesize viewController = _viewController;
@synthesize bannerView     = _bannerView;

static const NSTimeInterval kMaioNetworkTimeout = 10.0;

#pragma mark - Init

- (instancetype)init {
    self = [super init];
    if (self) {
        _adNetworkNo = 39; // Maio 실제 네트워크 번호로 교체 필요
    }
    return self;
}

#pragma mark - Setup methods

- (void)setRewardVideoViewController:(UIViewController *)vc {
    _viewController = vc;
    _adType = SSPRewardVideoAdType;
}

- (void)setInterstitialVideoViewController:(UIViewController *)vc {
    _viewController = vc;
    _adType = SSPInterstitialVideoAdType;
}

- (void)setVideoMixAdViewController:(UIViewController *)vc {
    _viewController = vc;
    _adType = SSPVideoMixAdType;
}

#pragma mark - Support flags

- (BOOL)isSupportRewardVideoAd       { return YES; }
- (BOOL)isSupportInterstitialVideoAd { return YES; }
- (BOOL)isSupportVideoMixAd          { return NO; }
- (BOOL)isSupportInterstitialAd      { return NO; }
- (BOOL)isSupportNativeAd            { return NO; }

#pragma mark - Public

- (void)loadAd {
    switch (_adType) {
        case SSPRewardVideoAdType:
            [self _loadRewardVideo];
            break;

        case SSPInterstitialVideoAdType:
            [self _loadInterstitialVideo];
            break;

//        case SSPVideoMixAdType: {
//            NSNumber *campaignType = [_integrationKey valueForKey:@"CampaignType"];
//            _videoMixAdType = SSPVideoMixAdTypeFromInteger([campaignType integerValue]);
//            switch (_videoMixAdType) {
//                case VideoMix_InterstitialVideoType:
//                    [self _loadInterstitialVideo];
//                    break;
//                case VideoMix_RewardVideoType:
//                    [self _loadRewardVideo];
//                    break;
//                default:
//                    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)]) {
//                        [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:maioError(AdPopcornSSPLoadAdFailed, @"Not supported VideoMix type")
//                                                                      adapter:self
//                                                                 videoMixType:_videoMixAdType];
//                    }
//                    break;
//            }
//            break;
//        }

        default:
            NSLog(@"MaioAdapter: unsupported adType = %d", _adType);
            break;
    }
}

- (void)showAd {
    switch (_adType) {
        case SSPInterstitialVideoAdType:
            if (_interstitialVideoAd) {
                [_interstitialVideoAd showWithViewContext:_viewController callback:self];
            } else {
                if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdShowFailError:adapter:)]) {
                    [_delegate AdPopcornSSPAdapterInterstitialVideoAdShowFailError:maioError(AdPopcornSSPNoInterstitialVideoAdLoaded, @"No InterstitialVideo Loaded")
                                                                          adapter:self];
                }
            }
            break;

        case SSPRewardVideoAdType:
            if (_rewardedAd) {
                [_rewardedAd showWithViewContext:_viewController callback:self];
            } else {
                if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowFailError:adapter:)]) {
                    [_delegate AdPopcornSSPAdapterRewardVideoAdShowFailError:maioError(AdPopcornSSPNoRewardVideoAdLoaded, @"No RewardVideo Loaded")
                                                                     adapter:self];
                }
            }
            break;

//        case SSPVideoMixAdType:
//            switch (_videoMixAdType) {
//                case VideoMix_InterstitialVideoType:
//                    if (_interstitialVideoAd) {
//                        [_interstitialVideoAd showWithViewContext:_viewController callback:self];
//                    } else if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowFailError:adapter:videoMixType:)]) {
//                        [_delegate AdPopcornSSPAdapterVideoMixAdShowFailError:maioError(AdPopcornSSPNoVideoMixAdLoaded, @"No VideoMix Ad Loaded")
//                                                                      adapter:self
//                                                                 videoMixType:_videoMixAdType];
//                    }
//                    break;
//
//                case VideoMix_RewardVideoType:
//                    if (_rewardedAd) {
//                        [_rewardedAd showWithViewContext:_viewController callback:self];
//                    } else if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowFailError:adapter:videoMixType:)]) {
//                        [_delegate AdPopcornSSPAdapterVideoMixAdShowFailError:maioError(AdPopcornSSPNoVideoMixAdLoaded, @"No VideoMix Ad Loaded")
//                                                                      adapter:self
//                                                                 videoMixType:_videoMixAdType];
//                    }
//                    break;
//
//                default:
//                    break;
//            }
//            break;

        default:
            break;
    }
}

- (void)closeAd {
    _isCurrentRunningAdapter = NO;
    [self _invalidateTimer];
    _interstitialVideoAd = nil;
    _rewardedAd = nil;
}

- (void)loadRequest {
    /* not used */
}

#pragma mark - Private

- (NSString *)_mediaID {
    return [_integrationKey valueForKey:@"MaioMediaId"];
}

- (NSString *)_zoneId {
    return [_integrationKey valueForKey:@"MaioZoneId"];
}

- (void)_loadInterstitialVideo {
    _isCurrentRunningAdapter = YES;
    [self _startTimer];

    if (!_integrationKey || ![self _zoneId].length) {
        [self _invalidateTimer];
        [self _fireLoadFail:maioError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey")];
        return;
    }

    NSLog(@"MaioAdapter InterstitialVideo zoneId: %@", [self _zoneId]);

    MaioRequest *request = [[MaioRequest alloc] initWithZoneId:[self _zoneId]
                                                      testMode:YES];
    _interstitialVideoAd = [MaioInterstitial loadAdWithRequest:request callback:self];
}

- (void)_loadRewardVideo {
    _isCurrentRunningAdapter = YES;
    [self _startTimer];

    if (!_integrationKey || ![self _zoneId].length) {
        [self _invalidateTimer];
        [self _fireLoadFail:maioError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey")];
        return;
    }

    NSLog(@"MaioAdapter RewardVideo zoneId: %@", [self _zoneId]);

    MaioRequest *request = [[MaioRequest alloc] initWithZoneId:[self _zoneId]
                                                      testMode:YES];
    _rewardedAd = [MaioRewarded loadAdWithRequest:request callback:self];
}

- (void)_fireLoadFail:(NSError *)error {
    if (_adType == SSPInterstitialVideoAdType) {
        if (_isCurrentRunningAdapter &&
            [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)]) {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:error adapter:self];
        }
    } else if (_adType == SSPRewardVideoAdType) {
        if (_isCurrentRunningAdapter &&
            [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)]) {
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:error adapter:self];
        }
    }
//    else if (_adType == SSPVideoMixAdType) {
//        if (_isCurrentRunningAdapter &&
//            [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)]) {
//            [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:error adapter:self videoMixType:_videoMixAdType];
//        }
//    }
}

#pragma mark - Timer

- (void)_startTimer {
    [self _invalidateTimer];
    _networkTimer = [NSTimer scheduledTimerWithTimeInterval:kMaioNetworkTimeout
                                                     target:self
                                                   selector:@selector(_onTimeout:)
                                                   userInfo:nil
                                                    repeats:NO];
}

- (void)_invalidateTimer {
    [_networkTimer invalidate];
    _networkTimer = nil;
}

- (void)_onTimeout:(NSTimer *)timer {
    NSLog(@"MaioAdapter load timeout adType:%d", _adType);
    if (_isCurrentRunningAdapter) {
        [self _fireLoadFail:maioError(AdPopcornSSPLoadAdFailed, @"Load Ad Failed")];
    }
    [self _invalidateTimer];
}

#pragma mark - Maio Common Callback
#pragma mark selector 중복 방지용 통합 구현

- (void)didLoad:(id)ad {
    [self _invalidateTimer];

    if ([ad isKindOfClass:[MaioInterstitial class]]) {
        NSLog(@"MaioAdapter interstitialVideo didLoad");

        if (_adType == SSPVideoMixAdType) {
            if (_isCurrentRunningAdapter &&
                [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadSuccess:videoMixType:)]) {
                [_delegate AdPopcornSSPAdapterVideoMixAdLoadSuccess:self videoMixType:_videoMixAdType];
            }
        } else {
            if (_isCurrentRunningAdapter &&
                [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:)]) {
                [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:self];
            }
        }
        return;
    }

    if ([ad isKindOfClass:[MaioRewarded class]]) {
        NSLog(@"MaioAdapter rewardVideo didLoad");

        if (_adType == SSPVideoMixAdType) {
            if (_isCurrentRunningAdapter &&
                [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadSuccess:videoMixType:)]) {
                [_delegate AdPopcornSSPAdapterVideoMixAdLoadSuccess:self videoMixType:_videoMixAdType];
            }
        } else {
            if (_isCurrentRunningAdapter &&
                [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadSuccess:)]) {
                [_delegate AdPopcornSSPAdapterRewardVideoAdLoadSuccess:self];
            }
        }
    }
}

- (void)didFail:(id)ad errorCode:(NSInteger)errorCode {
    [self _invalidateTimer];

    NSString *errorString = [NSString stringWithFormat:@"%ld", (long)errorCode];

    if ([ad isKindOfClass:[MaioInterstitial class]]) {
        NSLog(@"MaioAdapter interstitialVideo didFail: %ld", (long)errorCode);
    } else if ([ad isKindOfClass:[MaioRewarded class]]) {
        NSLog(@"MaioAdapter rewardVideo didFail: %ld", (long)errorCode);
    } else {
        NSLog(@"MaioAdapter unknown ad didFail: %ld", (long)errorCode);
    }

    [self _fireLoadFail:maioError(AdPopcornSSPLoadAdFailed, errorString)];
}

- (void)didOpen:(id)ad {
    if ([ad isKindOfClass:[MaioInterstitial class]]) {
        NSLog(@"MaioAdapter interstitialVideo didOpen");

        if (_adType == SSPVideoMixAdType) {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowSuccess:videoMixType:)]) {
                [_delegate AdPopcornSSPAdapterVideoMixAdShowSuccess:self videoMixType:_videoMixAdType];
            }
        } else {
            if (_isCurrentRunningAdapter &&
                [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdShowSuccess:)]) {
                [_delegate AdPopcornSSPAdapterInterstitialVideoAdShowSuccess:self];
            }
        }
        return;
    }

    if ([ad isKindOfClass:[MaioRewarded class]]) {
        NSLog(@"MaioAdapter rewardVideo didOpen");

        if (_adType == SSPVideoMixAdType) {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowSuccess:videoMixType:)]) {
                [_delegate AdPopcornSSPAdapterVideoMixAdShowSuccess:self videoMixType:_videoMixAdType];
            }
        } else {
            if (_isCurrentRunningAdapter &&
                [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowSuccess:)]) {
                [_delegate AdPopcornSSPAdapterRewardVideoAdShowSuccess:self];
            }
        }
    }
}

- (void)didClose:(id)ad {
    if ([ad isKindOfClass:[MaioInterstitial class]]) {
        NSLog(@"MaioAdapter interstitialVideo didClose");

        if (_adType == SSPVideoMixAdType) {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdClose:videoMixType:)]) {
                [_delegate AdPopcornSSPAdapterVideoMixAdClose:self videoMixType:_videoMixAdType];
            }
        } else {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdClose:)]) {
                [_delegate AdPopcornSSPAdapterInterstitialVideoAdClose:self];
            }
        }
        _isCurrentRunningAdapter = NO;
        return;
    }

    if ([ad isKindOfClass:[MaioRewarded class]]) {
        NSLog(@"MaioAdapter rewardVideo didClose");

        if (_adType == SSPVideoMixAdType) {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdClose:videoMixType:)]) {
                [_delegate AdPopcornSSPAdapterVideoMixAdClose:self videoMixType:_videoMixAdType];
            }
        } else {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdClose:)]) {
                [_delegate AdPopcornSSPAdapterRewardVideoAdClose:self];
            }
        }
        _isCurrentRunningAdapter = NO;
    }
}

#pragma mark - MaioRewarded only

- (void)didReward:(MaioRewarded *)ad reward:(RewardData *)reward {
    NSLog(@"MaioAdapter rewardVideo didReward");

    if (_adType == SSPVideoMixAdType) {
        if (_isCurrentRunningAdapter &&
            [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdCompleteTrackingEvent:isCompleted:videoMixType:)]) {
            [_delegate AdPopcornSSPAdapterVideoMixAdCompleteTrackingEvent:_adNetworkNo
                                                              isCompleted:YES
                                                             videoMixType:_videoMixAdType];
        }
    } else {
        if (_isCurrentRunningAdapter &&
            [_delegate respondsToSelector:@selector(onCompleteTrackingEvent:isCompleted:)]) {
            [_delegate onCompleteTrackingEvent:_adNetworkNo isCompleted:YES];
        }
    }

    _isCurrentRunningAdapter = NO;
}

@end
