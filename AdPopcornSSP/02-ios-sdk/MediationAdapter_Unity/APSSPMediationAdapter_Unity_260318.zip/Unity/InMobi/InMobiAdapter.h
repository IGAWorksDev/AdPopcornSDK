//
//  InMobiAdapter.h
//  IgaworksDevApp
//
//  Created by Odin on 3/3/26.
//  Copyright © 2026 AdPopcorn. All rights reserved.
//

#import <InMobiSDK/InMobiSDK.h>

// Using pod install / unity
#import <AdPopcornSSP/AdPopcornSSPAdapter.h>
// else
//#import "AdPopcornSSPAdapter.h"


@interface InMobiAdapter : AdPopcornSSPAdapter
{
    IMBanner *_bannerAd;
    IMNative *_nativeAd;
    IMInterstitial *_interstitialAd;
    IMInterstitial *_interstitialVideoAd;
    IMInterstitial *_rewardedAd;
}


@end

@interface APInMobiNativeAdRenderer : NSObject
@property (strong, nonatomic) UIView *inMobiNativeAdView;
@property (strong, nonatomic) UILabel *adTitleLabel;
@property (strong, nonatomic) UILabel *adDescriptionLabel;
@property (strong, nonatomic) UIImageView *adIcon;
@property (strong, nonatomic) UILabel *adCtaTextLabel;
@property (strong, nonatomic) UILabel *adRatingLabel;        // (optional)
@property (strong, nonatomic) UILabel *advertiserNameLabel;  // (optional)
@property (strong, nonatomic) UIImageView *adChoice;         // (optional)
@end
