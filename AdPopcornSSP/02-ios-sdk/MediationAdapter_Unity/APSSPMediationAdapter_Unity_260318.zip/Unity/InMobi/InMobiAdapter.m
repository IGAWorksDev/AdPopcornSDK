//
//  InMobiAdapter.m
//  IgaworksDevApp
//
//  Created by Odin on 3/3/26.
//  Copyright © 2026 AdPopcorn. All rights reserved.
//


#import "InMobiAdapter.h"

static inline NSError *sspError(SSPErrorCode code, NSString *desc) {
    return [NSError errorWithDomain:kAdPopcornSSPErrorDomain
                               code:code
                           userInfo:@{NSLocalizedDescriptionKey: desc}];
}

@interface InMobiAdapter () <IMBannerDelegate, IMInterstitialDelegate, IMNativeDelegate>
{
    NSInteger           _adNetworkNo;
    BOOL                _isCurrentRunningAdapter;
    NSTimer             *_networkTimer;
    VideoMixAdType          _videoMixAdType;
    APInMobiNativeAdRenderer   *_inMobiNativeAdRenderer;
}


@end

@implementation InMobiAdapter

@synthesize delegate        = _delegate;
@synthesize integrationKey  = _integrationKey;
@synthesize viewController  = _viewController;
@synthesize bannerView              = _bannerView;
@synthesize adpopcornSSPNativeAd    = _adpopcornSSPNativeAd;

static const NSTimeInterval kNetworkTimeout = 10.0;

#pragma mark - Init

- (instancetype)init {
    self = [super init];
    if (self) {
        _adNetworkNo = 37;
    }
    return self;
}

#pragma mark - AdPopcornSSPAdapter setup methods

- (void)setViewController:(UIViewController *)vc
                   origin:(CGPoint)origin
                     size:(CGSize)size
               bannerView:(AdPopcornSSPBannerView *)bannerView {
    _viewController = vc;
    _origin         = origin;
    _size           = size;
    _bannerView     = bannerView;
    _adType         = SSPAdBannerType;
}

- (void)setViewController:(UIViewController *)vc {
    _viewController = vc;
    _adType         = SSPAdInterstitialType;
}

- (void)setRewardVideoViewController:(UIViewController *)vc {
    _viewController = vc;
    _adType         = SSPRewardVideoAdType;
}

- (void)setInterstitialVideoViewController:(UIViewController *)vc {
    _viewController = vc;
    _adType         = SSPInterstitialVideoAdType;
}


- (void)setNativeAdViewController:(UIViewController *)vc nativeAdRenderer:(id)nativeAdRenderer rootNativeAdView:(AdPopcornSSPNativeAd *)adpopcornSSPNativeAd {
    _viewController = vc;
    _adType         = SSPNativeAdType;
    if ([nativeAdRenderer isKindOfClass:[APInMobiNativeAdRenderer class]])
        _inMobiNativeAdRenderer = nativeAdRenderer;
    _adpopcornSSPNativeAd = adpopcornSSPNativeAd;
}

- (void)setVideoMixAdViewController:(UIViewController *)vc {
    _viewController = vc;
    _adType         = SSPVideoMixAdType;
}

#pragma mark - Support flags

- (BOOL)isSupportInterstitialAd      { return YES; }
- (BOOL)isSupportRewardVideoAd       { return YES; }
- (BOOL)isSupportInterstitialVideoAd { return YES; }
- (BOOL)isSupportVideoMixAd          { return YES; }
- (BOOL)isSupportNativeAd            { return YES; }

#pragma mark - loadAd

- (void)loadAd {
    switch (_adType) {
        case SSPAdBannerType:
            [self _loadBanner];
            break;
        case SSPAdInterstitialType:
            [self _loadInterstitial];
            break;
        case SSPNativeAdType:
            [self _loadNative];
            break;
        case SSPInterstitialVideoAdType:
            [self _loadInterstitialVideo];
            break;
        case SSPRewardVideoAdType:
            [self _loadRewardVideo];
            break;
        case SSPVideoMixAdType: {
            NSNumber *campaignType = [_integrationKey valueForKey:@"CampaignType"];
            _videoMixAdType = SSPVideoMixAdTypeFromInteger([campaignType integerValue]);
            switch (_videoMixAdType) {
                case VideoMix_InterstitialType:     [self _loadInterstitial];      break;
                case VideoMix_InterstitialVideoType:[self _loadInterstitialVideo]; break;
                case VideoMix_RewardVideoType:      [self _loadRewardVideo];       break;
            }
            break;
        }
        default:
            [self _notSupported];
            break;
    }
}

#pragma mark - showAd

- (void)showAd {
    switch (_adType) {
        case SSPAdInterstitialType:
            if (_interstitialAd) {
                [_interstitialAd showFrom:_viewController];
            } else {
                if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdShowFailError:adapter:)])
                    [_delegate AdPopcornSSPAdapterInterstitialAdShowFailError:sspError(AdPopcornSSPNoInterstitialLoaded, @"No Interstitial Loaded") adapter:self];
            }
            break;

        case SSPInterstitialVideoAdType:
            if (_interstitialVideoAd) {
                [_interstitialVideoAd showFrom: _viewController];
            } else {
                if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdShowFailError:adapter:)])
                    [_delegate AdPopcornSSPAdapterInterstitialVideoAdShowFailError:sspError(AdPopcornSSPNoInterstitialVideoAdLoaded, @"No InterstitialVideo Loaded") adapter:self];
            }
            break;

        case SSPRewardVideoAdType:
            if (_rewardedAd) {
                [_rewardedAd showFrom:_viewController];
            } else {
                if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowFailError:adapter:)])
                    [_delegate AdPopcornSSPAdapterRewardVideoAdShowFailError:sspError(AdPopcornSSPNoRewardVideoAdLoaded, @"No RewardVideo Loaded") adapter:self];
            }
            break;

        case SSPVideoMixAdType:
            switch (_videoMixAdType) {
                case VideoMix_InterstitialType:
                    if (_interstitialAd) {
                        [_interstitialAd showFrom:_viewController];
                    } else {
                        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowFailError:adapter:videoMixType:)])
                            [_delegate AdPopcornSSPAdapterVideoMixAdShowFailError:sspError(AdPopcornSSPNoVideoMixAdLoaded, @"No VideoMix Ad Loaded") adapter:self videoMixType:_videoMixAdType];
                    }
                    break;
                case VideoMix_InterstitialVideoType:
                    if (_interstitialVideoAd) {
                        [_interstitialVideoAd showFrom: _viewController];
                    } else {
                        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowFailError:adapter:videoMixType:)])
                            [_delegate AdPopcornSSPAdapterVideoMixAdShowFailError:sspError(AdPopcornSSPNoVideoMixAdLoaded, @"No VideoMix Ad Loaded") adapter:self videoMixType:_videoMixAdType];
                    }
                    break;
                case VideoMix_RewardVideoType:
                    if (_rewardedAd) {
                        [_rewardedAd showFrom:_viewController];
                    } else {
                        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowFailError:adapter:videoMixType:)])
                            [_delegate AdPopcornSSPAdapterVideoMixAdShowFailError:sspError(AdPopcornSSPNoVideoMixAdLoaded, @"No VideoMix Ad Loaded") adapter:self videoMixType:_videoMixAdType];
                    }
                    break;
            }
            break;

        default:
            break;
    }
}

#pragma mark - closeAd

- (void)closeAd {
    NSLog(@"InMobiAdapter : closeAd : %d", _adType);
    switch (_adType) {
        case SSPAdBannerType:
            [_bannerAd removeFromSuperview];
            _bannerAd.delegate = nil;
            _bannerAd = nil;
            break;
        case SSPAdInterstitialType:
            _interstitialAd.delegate = nil;
            _interstitialAd = nil;
            break;
        case SSPNativeAdType:
            _nativeAd.delegate = nil;
            _nativeAd = nil;
            break;
        case SSPInterstitialVideoAdType:
            _isCurrentRunningAdapter = NO;
            [self _invalidateTimer];
            _interstitialVideoAd.delegate = nil;
            _interstitialVideoAd = nil;
            break;
        case SSPRewardVideoAdType:
            _isCurrentRunningAdapter = NO;
            [self _invalidateTimer];
            _rewardedAd.delegate = nil;
            _rewardedAd = nil;
            break;
        case SSPVideoMixAdType:
            switch (_videoMixAdType) {
                case VideoMix_InterstitialType:
                    _interstitialAd.delegate = nil;
                    _interstitialAd = nil;
                    break;
                case VideoMix_InterstitialVideoType:
                    _isCurrentRunningAdapter = NO;
                    [self _invalidateTimer];
                    _interstitialVideoAd.delegate = nil;
                    _interstitialVideoAd = nil;
                    break;
                case VideoMix_RewardVideoType:
                    _isCurrentRunningAdapter = NO;
                    [self _invalidateTimer];
                    _rewardedAd.delegate = nil;
                    _rewardedAd = nil;
                    break;
            }
            break;
        default:
            break;
    }
}

- (void)loadRequest { /* not used */ }

#pragma mark - Private load helpers

- (long long)_placementId {
    return [[_integrationKey valueForKey:@"InMobiPlacementId"] longLongValue];
}

- (long long)_AccountId {
    return [[_integrationKey valueForKey:@"InMobiAccountId"] longLongValue];
}

- (void)_loadBanner {
    if (!_integrationKey) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:sspError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey") adapter:self];
        [self closeAd];
        return;
    }
    
    if(_size.width == 320.0f && _size.height == 50.0f) {
        long long pid = [self _placementId];
        NSLog(@"InMobiAdapter Banner placementId: %lld", pid);
        _bannerAd = [[IMBanner alloc] initWithFrame:CGRectMake(0, 0, 320, 50) placementId:pid];
        _bannerAd.delegate = self;
        [_bannerView addSubview:_bannerAd];
        [self _addCenterConstraintForView:_bannerAd width:320 height:50];
        [_bannerAd load];
    }
    else {
        NSLog(@"NAMAdapter can not load 300x250 or 320x100");
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:sspError(AdPopcornSSPLoadAdFailed, @"NAMAdapter can not load 300x250 or 320x100") adapter:self];
        }
        
        [self closeAd];
    }
}

- (void)_loadNative {
    if (!_integrationKey) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterNativeAdLoadFailError:sspError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey") adapter:self];
        [self closeAd];
        return;
    }
    long long pid = [self _placementId];
    NSLog(@"InMobiAdapter Native placementId: %lld", pid);
    _nativeAd = [[IMNative alloc] initWithPlacementId:pid delegate:self];
    
    [_nativeAd load];
}

- (void)_loadInterstitial {
    if (!_integrationKey) {
        if (_adType == SSPVideoMixAdType) {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
                [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:sspError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey") adapter:self videoMixType:_videoMixAdType];
        } else {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadFailError:adapter:)])
                [_delegate AdPopcornSSPAdapterInterstitialAdLoadFailError:sspError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey") adapter:self];
        }
        [self closeAd];
        return;
    }
    long long pid = [self _placementId];
    NSLog(@"InMobiAdapter Interstitial placementId: %lld", pid);
    _interstitialAd = [[IMInterstitial alloc] initWithPlacementId:pid];
    _interstitialAd.delegate = self;
    [_interstitialAd load];
}

- (void)_loadInterstitialVideo {
    _isCurrentRunningAdapter = YES;
    [self _startTimer];
    if (!_integrationKey) {
        if (_adType == SSPVideoMixAdType) {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
                [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:sspError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey") adapter:self videoMixType:_videoMixAdType];
        } else {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
                [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:sspError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey") adapter:self];
        }
        [self closeAd];
        return;
    }
    long long pid = [self _placementId];
    NSLog(@"InMobiAdapter InterstitialVideo placementId: %lld", pid);
    _interstitialVideoAd = [[IMInterstitial alloc] initWithPlacementId:pid];
    _interstitialVideoAd.delegate = self;
    [_interstitialVideoAd load];
}

- (void)_loadRewardVideo {
    _isCurrentRunningAdapter = YES;
    [self _startTimer];
    if (!_integrationKey) {
        if (_adType == SSPVideoMixAdType) {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
                [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:sspError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey") adapter:self videoMixType:_videoMixAdType];
        } else {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
                [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:sspError(AdPopcornSSPMediationInvalidIntegrationKey, @"Invalid IntegrationKey") adapter:self];
        }
        [self closeAd];
        return;
    }
    long long pid = [self _placementId];
    NSLog(@"InMobiAdapter RewardVideo placementId: %lld", pid);
    _rewardedAd = [[IMInterstitial alloc] initWithPlacementId:pid];
    _rewardedAd.delegate = self;
    [_rewardedAd load];
}

- (void)_notSupported {
    NSLog(@"InMobiAdapter: adType %d not supported", _adType);
}

#pragma mark - Timer

- (void)_startTimer {
    [self _invalidateTimer];
    _networkTimer = [NSTimer scheduledTimerWithTimeInterval:kNetworkTimeout
                                                     target:self
                                                   selector:@selector(_onTimeout:)
                                                   userInfo:nil
                                                    repeats:NO];
}

- (void)_invalidateTimer {
    [_networkTimer invalidate];
    _networkTimer = nil;
}

- (void)_onTimeout:(NSTimer *)timer {
    NSLog(@"InMobiAdapter load timeout adType:%d", _adType);
    if (_adType == SSPVideoMixAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:sspError(AdPopcornSSPLoadAdFailed, @"Load Ad Failed") adapter:self videoMixType:_videoMixAdType];
    } else if (_adType == SSPInterstitialVideoAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:sspError(AdPopcornSSPLoadAdFailed, @"Load Ad Failed") adapter:self];
    } else if (_adType == SSPRewardVideoAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:sspError(AdPopcornSSPLoadAdFailed, @"Load Ad Failed") adapter:self];
    }
    [self _invalidateTimer];
}

#pragma mark - Banner Layout helper

- (void)_addCenterConstraintForView:(UIView *)view width:(CGFloat)w height:(CGFloat)h {
    view.translatesAutoresizingMaskIntoConstraints = NO;
    UIView *sv = _bannerView;
    [sv addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:sv attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
    [sv addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:sv attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
    [sv addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeWidth  relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:0 constant:w]];
    [sv addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:0 constant:h]];
}

#pragma mark - IMBannerDelegate

- (void)banner:(IMBanner*)banner didReceiveWithMetaInfo:(IMAdMetaInfo*)info {
    NSLog(@"InMobiAdapter didReceiveWithMetaInfo");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadSuccess:)])
        [_delegate AdPopcornSSPAdapterBannerViewLoadSuccess:self];
}

- (void)bannerAdDidFinishLoading:(IMBanner *)bannerAd {
    NSLog(@"InMobiAdapter bannerAdDidFinishLoading");
}

- (void)bannerAd:(IMBanner *)bannerAd didFailToLoadWithError:(IMRequestStatus *)error {
    NSLog(@"InMobiAdapter bannerAd didFailToLoad: %@", error);
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
        [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:error adapter:self];
    [self closeAd];
}

- (void)bannerAdWasClicked:(IMBanner *)bannerAd {
    NSLog(@"InMobiAdapter bannerAdWasClicked");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewClicked:)])
        [_delegate AdPopcornSSPAdapterBannerViewClicked:self];
}

#pragma mark - IMInterstitialDelegate

- (void)interstitialDidFinishLoading:(IMInterstitial *)interstitial {
    NSLog(@"InMobiAdapter interstitialDidFinishLoading adType:%d", _adType);
    [self _invalidateTimer];

    if (_adType == SSPVideoMixAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadSuccess:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdLoadSuccess:self videoMixType:_videoMixAdType];
    } else if (_adType == SSPAdInterstitialType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadSuccess:)])
            [_delegate AdPopcornSSPAdapterInterstitialAdLoadSuccess:self];
    } else if (_adType == SSPInterstitialVideoAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:)])
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:self];
    } else if (_adType == SSPRewardVideoAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadSuccess:)])
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadSuccess:self];
    }
}

- (void)interstitial:(IMInterstitial *)interstitial didFailToLoadWithError:(IMRequestStatus *)error {
    NSLog(@"InMobiAdapter interstitial didFailToLoad: %@ adType:%d", error, _adType);
    [self _invalidateTimer];

    if (_adType == SSPVideoMixAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:error adapter:self videoMixType:_videoMixAdType];
    } else if (_adType == SSPAdInterstitialType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterInterstitialAdLoadFailError:error adapter:self];
    } else if (_adType == SSPInterstitialVideoAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:error adapter:self];
    } else if (_adType == SSPRewardVideoAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:error adapter:self];
    }
}

- (void)interstitialWillPresent:(IMInterstitial *)interstitial {
    NSLog(@"InMobiAdapter interstitialWillPresent adType:%d", _adType);

    if (_adType == SSPVideoMixAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowSuccess:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdShowSuccess:self videoMixType:_videoMixAdType];
    } else if (_adType == SSPAdInterstitialType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdShowSuccess:)])
            [_delegate AdPopcornSSPAdapterInterstitialAdShowSuccess:self];
    } else if (_adType == SSPInterstitialVideoAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdShowSuccess:)])
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdShowSuccess:self];
    } else if (_adType == SSPRewardVideoAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowSuccess:)])
            [_delegate AdPopcornSSPAdapterRewardVideoAdShowSuccess:self];
    }
}

- (void)interstitial:(IMInterstitial *)interstitial didFailToPresentWithError:(IMRequestStatus *)error {
    NSLog(@"InMobiAdapter interstitial didFailToPresent: %@ adType:%d", error, _adType);

    if (_adType == SSPVideoMixAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowFailError:adapter:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdShowFailError:error adapter:self videoMixType:_videoMixAdType];
    } else if (_adType == SSPAdInterstitialType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdShowFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterInterstitialAdShowFailError:error adapter:self];
    } else if (_adType == SSPInterstitialVideoAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdShowFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdShowFailError:error adapter:self];
    } else if (_adType == SSPRewardVideoAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterRewardVideoAdShowFailError:error adapter:self];
    }
}

- (void)interstitialDidDismiss:(IMInterstitial *)interstitial {
    NSLog(@"InMobiAdapter interstitialDidDismiss adType:%d", _adType);

    if (_adType == SSPVideoMixAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdClose:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdClose:self videoMixType:_videoMixAdType];
    } else if (_adType == SSPAdInterstitialType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdClosed:)])
            [_delegate AdPopcornSSPAdapterInterstitialAdClosed:self];
    } else if (_adType == SSPInterstitialVideoAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdClose:)])
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdClose:self];
    } else if (_adType == SSPRewardVideoAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdClose:)])
            [_delegate AdPopcornSSPAdapterRewardVideoAdClose:self];
    }
}

- (void)interstitialAdWasClicked:(IMInterstitial *)interstitial {
    NSLog(@"InMobiAdapter interstitialAdWasClicked adType:%d", _adType);
    if (_adType == SSPAdInterstitialType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdClicked:)])
            [_delegate AdPopcornSSPAdapterInterstitialAdClicked:self];
    } else if (_adType == SSPVideoMixAdType) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdClicked:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdClicked:self videoMixType:_videoMixAdType];
    }
}

- (void)interstitial:(IMInterstitial *)interstitial rewardActionCompletedWithRewards:(NSDictionary *)rewards {
    NSLog(@"InMobiAdapter rewardActionCompleted rewards:%@ adType:%d", rewards, _adType);
    if (_adType == SSPRewardVideoAdType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(onCompleteTrackingEvent:isCompleted:)])
            [_delegate onCompleteTrackingEvent:_adNetworkNo isCompleted:YES];
        _isCurrentRunningAdapter = NO;
    } else if (_adType == SSPVideoMixAdType && _videoMixAdType == VideoMix_RewardVideoType) {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdCompleteTrackingEvent:isCompleted:videoMixType:)])
            [_delegate AdPopcornSSPAdapterVideoMixAdCompleteTrackingEvent:_adNetworkNo isCompleted:YES videoMixType:_videoMixAdType];
        _isCurrentRunningAdapter = NO;
    }
}


#pragma mark - IMNativeDelegate

- (void)nativeDidFinishLoading:(IMNative *)native {
    NSLog(@"InMobiAdapter nativeDidFinishLoading");
    if (_inMobiNativeAdRenderer == nil || _inMobiNativeAdRenderer.inMobiNativeAdView == nil) {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadFailError:adapter:)])
            [_delegate AdPopcornSSPAdapterNativeAdLoadFailError:sspError(AdPopcornSSPInvalidNativeAssetsConfig, @"Invalid native assets config") adapter:self];
        return;
    }
    
    if(_inMobiNativeAdRenderer != nil && _inMobiNativeAdRenderer.inMobiNativeAdView != nil)
    {
        IMNative *nativeAd = native;
        
        NSLog(@"%@", nativeAd.adIcon);
        
        
        
        if(_inMobiNativeAdRenderer.adTitleLabel != nil)
        {
            _inMobiNativeAdRenderer.adTitleLabel.text = nativeAd.adTitle;
        }
        if(_inMobiNativeAdRenderer.adDescriptionLabel != nil)
        {
            _inMobiNativeAdRenderer.adDescriptionLabel.text = nativeAd.adDescription;
        }
        if(_inMobiNativeAdRenderer.adIcon != nil)
        {
            _inMobiNativeAdRenderer.adIcon = nativeAd.adIcon.imageview;
        }
        if(_inMobiNativeAdRenderer.adCtaTextLabel != nil)
        {
            _inMobiNativeAdRenderer.adCtaTextLabel.text = nativeAd.adCtaText;
        }
        if(_inMobiNativeAdRenderer.adRatingLabel != nil)
        {
            _inMobiNativeAdRenderer.adRatingLabel.text = nativeAd.adRating;
        }
        if(_inMobiNativeAdRenderer.advertiserNameLabel != nil)
        {
            _inMobiNativeAdRenderer.advertiserNameLabel.text = nativeAd.advertiserName;
        }
        if(_inMobiNativeAdRenderer.adChoice != nil)
        {
            _inMobiNativeAdRenderer.adChoice = nativeAd.adChoice;
            _inMobiNativeAdRenderer.adChoice.userInteractionEnabled = YES;
        }
    }

    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadSuccess:)])
        [_delegate AdPopcornSSPAdapterNativeAdLoadSuccess:self];
}

- (void)native:(IMNative *)native didFailToLoadWithError:(IMRequestStatus *)error {
    NSLog(@"InMobiAdapter native didFailToLoad: %@", error);
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadFailError:adapter:)])
        [_delegate AdPopcornSSPAdapterNativeAdLoadFailError:error adapter:self];
}

- (void)nativeDidRecordImpression:(IMNative *)native {
    NSLog(@"InMobiAdapter nativeDidRecordImpression");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdImpression:)])
        [_delegate AdPopcornSSPAdapterNativeAdImpression:self];
}

- (void)native:(IMNative *)native didInteractWithParams:(NSDictionary *)params {
    NSLog(@"InMobiAdapter native didInteractWithParams");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdClicked:)])
        [_delegate AdPopcornSSPAdapterNativeAdClicked:self];
}


@end

@implementation APInMobiNativeAdRenderer

- (instancetype)init {
    self = [super init];
    return self;
}

@end
