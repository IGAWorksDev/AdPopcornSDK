//
//  InMobiNativeVIewSample.h
//  IgaworksDevApp
//
//  Created by Odin on 3/16/26.
//  Copyright © 2026 AdPopcorn. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <InMobiSDK/InMobiSDK.h>

@interface InMobiNativeVIewSample : UIView

@property (strong, nonatomic) UILabel *adTitleLabel;
@property (strong, nonatomic) UILabel *adDescriptionLabel;
@property (strong, nonatomic) UIImageView *adIcon;
@property (strong, nonatomic) UILabel *adCtaTextLabel;
@property (strong, nonatomic) UILabel *adRatingLabel;        // optional
@property (strong, nonatomic) UILabel *advertiserNameLabel;  // optional
@property (strong, nonatomic) UIImageView *adChoice;         // optional

@end
