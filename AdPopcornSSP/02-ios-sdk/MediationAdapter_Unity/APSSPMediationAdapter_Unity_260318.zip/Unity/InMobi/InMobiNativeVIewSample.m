//
//  InMobiNativeVIewSample.m
//  IgaworksDevApp
//
//  Created by Odin on 3/16/26.
//  Copyright © 2026 AdPopcorn. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "InMobiNativeVIewSample.h"

@implementation InMobiNativeVIewSample


- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self commonInit];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    if (self) {
        [self commonInit];
    }
    return self;
}

- (void)commonInit {
    self.backgroundColor = [UIColor whiteColor];
    [self setupUI];
}


- (void)setupUI {
        
        // icon
        self.adIcon = [[UIImageView alloc] init];
        self.adIcon.translatesAutoresizingMaskIntoConstraints = NO;
        self.adIcon.layer.cornerRadius = 10.0;
        self.adIcon.clipsToBounds = YES;
        self.adIcon.backgroundColor = [UIColor redColor];
        [self addSubview:self.adIcon];
        
        // title
        self.adTitleLabel = [[UILabel alloc] init];
        self.adTitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.adTitleLabel.font = [UIFont boldSystemFontOfSize:18];
        self.adTitleLabel.textColor = [UIColor blackColor];
        [self addSubview:self.adTitleLabel];
        
        // description
        self.adDescriptionLabel = [[UILabel alloc] init];
        self.adDescriptionLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.adDescriptionLabel.numberOfLines = 3;
        self.adDescriptionLabel.textColor = [UIColor blackColor];
        self.adDescriptionLabel.font = [UIFont systemFontOfSize:14];
        [self addSubview:self.adDescriptionLabel];
        
        // CTA
        self.adCtaTextLabel = [[UILabel alloc] init];
        self.adCtaTextLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.adCtaTextLabel.backgroundColor = [UIColor systemBlueColor];
        self.adCtaTextLabel.textColor = [UIColor blackColor];
        self.adCtaTextLabel.textAlignment = NSTextAlignmentCenter;
        self.adCtaTextLabel.layer.cornerRadius = 8;
        self.adCtaTextLabel.clipsToBounds = YES;
        [self addSubview:self.adCtaTextLabel];
        
        // AdChoice
        self.adChoice = [[UIImageView alloc] init];
        self.adChoice.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:self.adChoice];
        
        // constraints
        [NSLayoutConstraint activateConstraints:@[
            
            [self.adIcon.topAnchor constraintEqualToAnchor:self.topAnchor constant:16],
            [self.adIcon.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:16],
            [self.adIcon.widthAnchor constraintEqualToConstant:60],
            [self.adIcon.heightAnchor constraintEqualToConstant:60],
            
            [self.adTitleLabel.topAnchor constraintEqualToAnchor:self.topAnchor constant:16],
            [self.adTitleLabel.leadingAnchor constraintEqualToAnchor:self.adIcon.trailingAnchor constant:12],
            [self.adTitleLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-16],
            
            [self.adDescriptionLabel.topAnchor constraintEqualToAnchor:self.adIcon.bottomAnchor constant:12],
            [self.adDescriptionLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:16],
            [self.adDescriptionLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-16],
            
            [self.adCtaTextLabel.topAnchor constraintEqualToAnchor:self.adDescriptionLabel.bottomAnchor constant:16],
            [self.adCtaTextLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:16],
            [self.adCtaTextLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-16],
            [self.adCtaTextLabel.heightAnchor constraintEqualToConstant:44],
            [self.adCtaTextLabel.bottomAnchor constraintEqualToAnchor:self.bottomAnchor constant:-16],
            
            [self.adChoice.topAnchor constraintEqualToAnchor:self.topAnchor constant:12],
            [self.adChoice.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-12],
            [self.adChoice.widthAnchor constraintEqualToConstant:24],
            [self.adChoice.heightAnchor constraintEqualToConstant:24]
        ]];
}


@end
