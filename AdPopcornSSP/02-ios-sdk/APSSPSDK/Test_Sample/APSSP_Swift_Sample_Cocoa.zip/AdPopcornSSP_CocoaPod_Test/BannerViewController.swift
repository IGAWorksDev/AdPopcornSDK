import UIKit
import APSSPSDK

class BannerViewController: UIViewController, APSSPBannerViewDelegate {

    private var bannerView: APSSPBannerView!
    private let logTextView = UITextView()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        setupBanner()
    }

    private func setupUI() {
        // Load button
        let loadButton = UIButton(type: .system)
        loadButton.setTitle("Load Banner", for: .normal)
        loadButton.addTarget(self, action: #selector(loadTapped), for: .touchUpInside)

        let stopButton = UIButton(type: .system)
        stopButton.setTitle("Stop Banner", for: .normal)
        stopButton.addTarget(self, action: #selector(stopTapped), for: .touchUpInside)

        let stack = UIStackView(arrangedSubviews: [loadButton, stopButton])
        stack.spacing = 16
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        logTextView.isEditable = false
        logTextView.font = .systemFont(ofSize: 12)
        logTextView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(logTextView)

        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            logTextView.topAnchor.constraint(equalTo: stack.bottomAnchor, constant: 16),
            logTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            logTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            logTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -70)
        ])
    }

    private func setupBanner() {
        bannerView = APSSPBannerView(
            appKey: "397261446",
            placementId: "iOS_BANNER_320x50",
            bannerSize: .banner320x50
        )
        bannerView.delegate = self
        bannerView.rootViewController = self
        view.addSubview(bannerView)
        bannerView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            bannerView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            bannerView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            bannerView.widthAnchor.constraint(equalToConstant: 320),
            bannerView.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    @objc private func loadTapped() {
        log("loadAd()")
        bannerView.loadAd()
    }

    @objc private func stopTapped() {
        log("stopAd()")
        bannerView.stopAd()
    }

    private func log(_ msg: String) {
        logTextView.text += "\(msg)\n"
        let bottom = NSRange(location: logTextView.text.count - 1, length: 1)
        logTextView.scrollRangeToVisible(bottom)
    }

    // MARK: - APSSPBannerViewDelegate

    func apsspBannerViewLoadSuccess(bannerView: APSSPBannerView) {
        log("✅ Banner Load Success")
    }

    func apsspBannerViewLoadFail(bannerView: APSSPBannerView, error: APSSPNetworkError) {
        log("❌ Banner Load Fail: \(error)")
    }

    func apsspBannerViewClicked(bannerView: APSSPBannerView) {
        log("👆 Banner Clicked")
    }

    func apsspBannerViewImpression(bannerView: APSSPBannerView) {
        log("👁 Banner Impression")
    }
}
