import UIKit

class MainViewController: UITableViewController {

    private let adFormats = [
        "Banner",
        "Interstitial",
        "Interstitial Video",
        "Reward Video",
        "Video Mix",
        "Native"
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "APSSPSDK SPM Test"
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        adFormats.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = adFormats[indexPath.row]
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let vc: UIViewController
        switch indexPath.row {
        case 0: vc = BannerViewController()
        case 1: vc = InterstitialViewController()
        case 2: vc = InterstitialVideoViewController()
        case 3: vc = RewardVideoViewController()
        case 4: vc = VideoMixViewController()
        case 5: vc = NativeViewController()
        default: return
        }
        vc.title = adFormats[indexPath.row]
        navigationController?.pushViewController(vc, animated: true)
    }
}
