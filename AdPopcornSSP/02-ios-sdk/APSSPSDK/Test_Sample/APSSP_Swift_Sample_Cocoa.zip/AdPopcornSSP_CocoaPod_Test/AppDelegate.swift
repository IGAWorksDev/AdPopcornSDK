import UIKit
import AppTrackingTransparency
import AdSupport
import APSSPSDK

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {

        let settings = APSSPInitializationSettings(appKey: "397261446")
        settings.logType = .all
        settings.adInspectorEnabled = true

        APSSPAds.initializeSDK(with: settings) {
            print("[APSSPSDK] Initialize completed")
        }

        return true
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        requestIDFA()
    }

    private func requestIDFA() {
        if #available(iOS 14, *) {
            ATTrackingManager.requestTrackingAuthorization { status in
                print("[ATT] status: \(status.rawValue)")
            }
        }
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication,
                     configurationForConnecting connectingSceneSession: UISceneSession,
                     options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
}
