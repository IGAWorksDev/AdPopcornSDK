import UIKit
import APSSPSDK

class InterstitialViewController: UIViewController, APSSPInterstitialAdDelegate {

    private var interstitialAd: APSSPInterstitialAd!
    private let logTextView = UITextView()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        setupAd()
    }

    private func setupUI() {
        let loadButton = UIButton(type: .system)
        loadButton.setTitle("Load", for: .normal)
        loadButton.addTarget(self, action: #selector(loadTapped), for: .touchUpInside)

        let showButton = UIButton(type: .system)
        showButton.setTitle("Show", for: .normal)
        showButton.addTarget(self, action: #selector(showTapped), for: .touchUpInside)

        let stack = UIStackView(arrangedSubviews: [loadButton, showButton])
        stack.spacing = 16
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        logTextView.isEditable = false
        logTextView.font = .systemFont(ofSize: 12)
        logTextView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(logTextView)

        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            logTextView.topAnchor.constraint(equalTo: stack.bottomAnchor, constant: 16),
            logTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            logTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            logTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16)
        ])
    }

    private func setupAd() {
        interstitialAd = APSSPInterstitialAd(
            appKey: "397261446",
            placementId: "iOS_INTERSTITIAL",
            rootViewController: self
        )
        interstitialAd.delegate = self
    }

    @objc private func loadTapped() {
        log("load()")
        interstitialAd.load()
    }

    @objc private func showTapped() {
        log("present()")
        interstitialAd.present(from: self)
    }

    private func log(_ msg: String) {
        logTextView.text += "\(msg)\n"
        let bottom = NSRange(location: logTextView.text.count - 1, length: 1)
        logTextView.scrollRangeToVisible(bottom)
    }

    // MARK: - APSSPInterstitialAdDelegate

    func apsspInterstitialAdLoadSuccess(interstitialAd: APSSPInterstitialAd) {
        log("✅ Load Success")
    }

    func apsspInterstitialAdLoadFail(interstitialAd: APSSPInterstitialAd, error: APSSPNetworkError) {
        log("❌ Load Fail: \(error)")
    }

    func apsspInterstitialAdShowSuccess(interstitialAd: APSSPInterstitialAd) {
        log("✅ Show Success")
    }

    func apsspInterstitialAdShowFail(interstitialAd: APSSPInterstitialAd, error: APSSPNetworkError) {
        log("❌ Show Fail: \(error)")
    }

    func apsspInterstitialAdClicked(interstitialAd: APSSPInterstitialAd) {
        log("👆 Clicked")
    }

    func apsspInterstitialAdClosed(interstitialAd: APSSPInterstitialAd) {
        log("🚪 Closed")
    }
}
