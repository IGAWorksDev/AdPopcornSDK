import UIKit
import APSSPSDK

class RewardVideoViewController: UIViewController, APSSPRewardVideoAdDelegate {

    private var rewardVideoAd: APSSPRewardVideoAd!
    private let logTextView = UITextView()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        setupAd()
    }

    private func setupUI() {
        let loadButton = UIButton(type: .system)
        loadButton.setTitle("Load", for: .normal)
        loadButton.addTarget(self, action: #selector(loadTapped), for: .touchUpInside)

        let showButton = UIButton(type: .system)
        showButton.setTitle("Show", for: .normal)
        showButton.addTarget(self, action: #selector(showTapped), for: .touchUpInside)

        let stack = UIStackView(arrangedSubviews: [loadButton, showButton])
        stack.spacing = 16
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        logTextView.isEditable = false
        logTextView.font = .systemFont(ofSize: 12)
        logTextView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(logTextView)

        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            logTextView.topAnchor.constraint(equalTo: stack.bottomAnchor, constant: 16),
            logTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            logTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            logTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16)
        ])
    }

    private func setupAd() {
        APSSPAds.setUSerID(usn: "TEST_USN")
        rewardVideoAd = APSSPRewardVideoAd(
            appKey: "397261446",
            placementId: "iOS_REWARD_VIDEO",
            rootViewController: self
        )
        rewardVideoAd.delegate = self
    }

    @objc private func loadTapped() {
        log("load()")
        rewardVideoAd.load()
    }

    @objc private func showTapped() {
        log("present()")
        rewardVideoAd.present(from: self)
    }

    private func log(_ msg: String) {
        logTextView.text += "\(msg)\n"
        let bottom = NSRange(location: logTextView.text.count - 1, length: 1)
        logTextView.scrollRangeToVisible(bottom)
    }

    // MARK: - APSSPRewardVideoAdDelegate

    func apsspRewardVideoAdLoadSuccess(rewardVideoAd: APSSPRewardVideoAd) {
        log("✅ Load Success")
    }

    func apsspRewardVideoAdLoadFail(rewardVideoAd: APSSPRewardVideoAd, error: APSSPNetworkError) {
        log("❌ Load Fail: \(error)")
    }

    func apsspRewardVideoAdShowSuccess(rewardVideoAd: APSSPRewardVideoAd) {
        log("✅ Show Success")
    }

    func apsspRewardVideoAdShowFail(rewardVideoAd: APSSPRewardVideoAd, error: APSSPNetworkError) {
        log("❌ Show Fail: \(error)")
    }

    func apsspRewardVideoAdClicked(rewardVideoAd: APSSPRewardVideoAd) {
        log("👆 Clicked")
    }

    func apsspRewardVideoAdClosed(rewardVideoAd: APSSPRewardVideoAd) {
        log("🚪 Closed")
    }

    func apsspRewardVideoAdPlayCompleted(rewardVideoAd: APSSPRewardVideoAd, adNetworkNo: Int, completed: Bool) {
        log("🎬 PlayCompleted - network: \(adNetworkNo), completed: \(completed)")
    }
}
