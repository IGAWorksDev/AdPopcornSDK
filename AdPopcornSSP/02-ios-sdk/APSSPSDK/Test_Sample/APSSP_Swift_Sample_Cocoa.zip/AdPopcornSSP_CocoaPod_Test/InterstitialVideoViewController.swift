import UIKit
import APSSPSDK

class InterstitialVideoViewController: UIViewController, APSSPInterstitialVideoAdDelegate {

    private var interstitialVideoAd: APSSPInterstitialVideoAd!
    private let logTextView = UITextView()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        setupAd()
    }

    private func setupUI() {
        let loadButton = UIButton(type: .system)
        loadButton.setTitle("Load", for: .normal)
        loadButton.addTarget(self, action: #selector(loadTapped), for: .touchUpInside)

        let showButton = UIButton(type: .system)
        showButton.setTitle("Show", for: .normal)
        showButton.addTarget(self, action: #selector(showTapped), for: .touchUpInside)

        let stack = UIStackView(arrangedSubviews: [loadButton, showButton])
        stack.spacing = 16
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        logTextView.isEditable = false
        logTextView.font = .systemFont(ofSize: 12)
        logTextView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(logTextView)

        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            logTextView.topAnchor.constraint(equalTo: stack.bottomAnchor, constant: 16),
            logTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            logTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            logTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16)
        ])
    }

    private func setupAd() {
        interstitialVideoAd = APSSPInterstitialVideoAd(
            appKey: "397261446",
            placementId: "iOS_VIDEO",
            rootViewController: self
        )
        interstitialVideoAd.delegate = self
    }

    @objc private func loadTapped() {
        log("load()")
        interstitialVideoAd.load()
    }

    @objc private func showTapped() {
        log("present()")
        interstitialVideoAd.present(from: self)
    }

    private func log(_ msg: String) {
        logTextView.text += "\(msg)\n"
        let bottom = NSRange(location: logTextView.text.count - 1, length: 1)
        logTextView.scrollRangeToVisible(bottom)
    }

    // MARK: - APSSPInterstitialVideoAdDelegate

    func apsspInterstitialVideoAdLoadSuccess(interstitialVideoAd: APSSPInterstitialVideoAd) {
        log("✅ Load Success")
    }

    func apsspInterstitialVideoAdLoadFail(interstitialVideoAd: APSSPInterstitialVideoAd, error: APSSPNetworkError) {
        log("❌ Load Fail: \(error)")
    }

    func apsspInterstitialVideoAdShowSuccess(interstitialVideoAd: APSSPInterstitialVideoAd) {
        log("✅ Show Success")
    }

    func apsspInterstitialVideoAdShowFail(interstitialVideoAd: APSSPInterstitialVideoAd, error: APSSPNetworkError) {
        log("❌ Show Fail: \(error)")
    }

    func apsspInterstitialVideoAdClicked(interstitialVideoAd: APSSPInterstitialVideoAd) {
        log("👆 Clicked")
    }

    func apsspInterstitialVideoAdClosed(interstitialVideoAd: APSSPInterstitialVideoAd) {
        log("🚪 Closed")
    }
}
