import SwiftUI
import APSSPSDK
internal import Combine

struct VideoMixAdView: View {
    @StateObject private var vm = VideoMixViewModel()

    var body: some View {
        VStack(spacing: 16) {
            HStack(spacing: 16) {
                Button("Load") { vm.load() }
                Button("Show") { vm.show() }
            }
            List(vm.logs, id: \.self) { Text($0).font(.caption) }
        }
        .navigationTitle("VideoMix")
    }
}

class VideoMixViewModel: NSObject, ObservableObject, APSSPVideoMixAdDelegate {
    @Published var logs: [String] = []
    private var ad: APSSPVideoMixAd?

    override init() {
        super.init()
        ad = APSSPVideoMixAd(appKey: "397261446", placementId: "iOS_VIDEO", rootViewController: UIApplication.shared.rootViewController)
        ad?.delegate = self
    }

    func load() {
        logs.append("Load...")
        ad?.load()
    }
    func show() {
        guard let vc = UIApplication.shared.rootViewController else { return }
        ad?.present(from: vc)
    }

    func apsspVideoMixAdLoadSuccess(videoMixAd: APSSPVideoMixAd, videoMixAdType: APSSPVideoMixAdType) { logs.append("✅ Load Success (type: \(videoMixAdType.rawValue))") }
    func apsspVideoMixAdLoadFail(videoMixAd: APSSPVideoMixAd, error: APSSPNetworkError) { logs.append("❌ Load Fail: \(error.rawValue)") }
    func apsspVideoMixAdShowSuccess(videoMixAd: APSSPVideoMixAd) { logs.append("✅ Show Success") }
    func apsspVideoMixAdPlayCompleted(videoMixAd: APSSPVideoMixAd, adNetworkNo: Int, completed: Bool) { logs.append("🎬 Completed: \(completed)") }
    func apsspVideoMixAdClosed(videoMixAd: APSSPVideoMixAd, videoMixAdType: APSSPVideoMixAdType) { logs.append("🚪 Closed") }
}
