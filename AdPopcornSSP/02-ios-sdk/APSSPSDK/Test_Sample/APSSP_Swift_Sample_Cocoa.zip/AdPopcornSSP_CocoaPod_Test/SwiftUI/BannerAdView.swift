import SwiftUI
import APSSPSDK

struct BannerAdView: View {
    @State private var logs: [String] = []

    var body: some View {
        VStack(spacing: 0) {
            List(logs, id: \.self) { Text($0).font(.caption) }
            BannerRepresentable(logs: $logs)
                .frame(height: 50)
        }
        .navigationTitle("Banner")
    }
}

struct BannerRepresentable: UIViewRepresentable {
    @Binding var logs: [String]

    func makeUIView(context: Context) -> APSSPBannerView {
        let banner = APSSPBannerView(appKey: "397261446", placementId: "iOS_BANNER_320x50", bannerSize: .banner320x50)
        banner.delegate = context.coordinator
        banner.rootViewController = UIApplication.shared.rootViewController
        banner.adRefreshTime = 60
        banner.loadAd()
        return banner
    }

    func updateUIView(_ uiView: APSSPBannerView, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(logs: $logs) }

    class Coordinator: NSObject, APSSPBannerViewDelegate {
        @Binding var logs: [String]
        init(logs: Binding<[String]>) { _logs = logs }

        func apsspBannerViewLoadSuccess(bannerView: APSSPBannerView) { logs.append("✅ Load Success") }
        func apsspBannerViewLoadFail(bannerView: APSSPBannerView, error: APSSPNetworkError) { logs.append("❌ Load Fail: \(error.rawValue)") }
        func apsspBannerViewClicked(bannerView: APSSPBannerView) { logs.append("👆 Clicked") }
        func apsspBannerViewImpression(bannerView: APSSPBannerView) { logs.append("👁 Impression") }
    }
}

extension UIApplication {
    var rootViewController: UIViewController? {
        connectedScenes.compactMap { $0 as? UIWindowScene }.first?.windows.first?.rootViewController
    }
}
