import SwiftUI
import APSSPSDK

struct ContentView: View {
    var body: some View {
        NavigationView {
            List {
                NavigationLink("Banner") { BannerAdView() }
                NavigationLink("Interstitial") { InterstitialAdView() }
                NavigationLink("InterstitialVideo") { InterstitialVideoAdView() }
                NavigationLink("RewardVideo") { RewardVideoAdView() }
                NavigationLink("VideoMix") { VideoMixAdView() }
                NavigationLink("Native") { NativeAdSwiftUIView() }
            }
            .navigationTitle("APSSPSDK SwiftUI")
        }
    }
}
