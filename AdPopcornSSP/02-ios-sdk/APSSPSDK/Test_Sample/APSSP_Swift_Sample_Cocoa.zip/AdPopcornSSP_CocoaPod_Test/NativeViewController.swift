import UIKit

import APSSPSDK
import APSSPMediationAdMob
import APSSPMediationADOP
import APSSPMediationGAM
import APSSPMediationAdForus
import APSSPMediationAppLovin
import APSSPMediationAppLovinMax
import APSSPMediationVungle
import APSSPMediationMintegral
import APSSPMediationNAM
import APSSPMediationAdFit
import APSSPMediationMezzo
import APSSPMediationFBAudienceNetwork
import APSSPMediationInMobi
import APSSPMediationFyber
import APSSPMediationCSJ
import APSSPMediationMoloco

import GFPSDK
import GoogleMobileAds
import AppLovinSDK
import VungleAdsSDK
import AdFitSDK


class NativeViewController: UIViewController, APSSPNativeAdDelegate {

    private var nativeAd: APSSPNativeAd!
    private let logTextView = UITextView()

    // 자사 네이티브 광고용 뷰
    private let nativeAdContainerView = APSSPNativeAdView()
    private let iconImageView = UIImageView()
    private let titleLabel = UILabel()
    private let descLabel = UILabel()
    private let mainImageView = UIImageView()
    private let ctaButton = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        setupAd()
    }

    private func setupUI() {
        let loadButton = UIButton(type: .system)
        loadButton.setTitle("Load Native", for: .normal)
        loadButton.addTarget(self, action: #selector(loadTapped), for: .touchUpInside)

        let stopButton = UIButton(type: .system)
        stopButton.setTitle("Stop", for: .normal)
        stopButton.addTarget(self, action: #selector(stopTapped), for: .touchUpInside)

        let stack = UIStackView(arrangedSubviews: [loadButton, stopButton])
        stack.spacing = 16
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        // Native ad container
        nativeAdContainerView.translatesAutoresizingMaskIntoConstraints = false
        nativeAdContainerView.backgroundColor = .secondarySystemBackground
        nativeAdContainerView.layer.cornerRadius = 8
        nativeAdContainerView.clipsToBounds = true

        iconImageView.translatesAutoresizingMaskIntoConstraints = false
        iconImageView.contentMode = .scaleAspectFit
        iconImageView.backgroundColor = .systemGray5

        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.font = .boldSystemFont(ofSize: 14)
        titleLabel.numberOfLines = 2

        descLabel.translatesAutoresizingMaskIntoConstraints = false
        descLabel.font = .systemFont(ofSize: 12)
        descLabel.numberOfLines = 2
        descLabel.textColor = .secondaryLabel

        mainImageView.translatesAutoresizingMaskIntoConstraints = false
        mainImageView.contentMode = .scaleAspectFill
        mainImageView.clipsToBounds = true
        mainImageView.backgroundColor = .systemGray5

        ctaButton.translatesAutoresizingMaskIntoConstraints = false
        ctaButton.setTitle("Install", for: .normal)

        nativeAdContainerView.addSubview(iconImageView)
        nativeAdContainerView.addSubview(titleLabel)
        nativeAdContainerView.addSubview(descLabel)
        nativeAdContainerView.addSubview(mainImageView)
        nativeAdContainerView.addSubview(ctaButton)

        NSLayoutConstraint.activate([
            iconImageView.topAnchor.constraint(equalTo: nativeAdContainerView.topAnchor, constant: 8),
            iconImageView.leadingAnchor.constraint(equalTo: nativeAdContainerView.leadingAnchor, constant: 8),
            iconImageView.widthAnchor.constraint(equalToConstant: 40),
            iconImageView.heightAnchor.constraint(equalToConstant: 40),
            titleLabel.topAnchor.constraint(equalTo: nativeAdContainerView.topAnchor, constant: 8),
            titleLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 8),
            titleLabel.trailingAnchor.constraint(equalTo: nativeAdContainerView.trailingAnchor, constant: -8),
            descLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 4),
            descLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            descLabel.trailingAnchor.constraint(equalTo: titleLabel.trailingAnchor),
            mainImageView.topAnchor.constraint(equalTo: iconImageView.bottomAnchor, constant: 8),
            mainImageView.leadingAnchor.constraint(equalTo: nativeAdContainerView.leadingAnchor),
            mainImageView.trailingAnchor.constraint(equalTo: nativeAdContainerView.trailingAnchor),
            mainImageView.heightAnchor.constraint(equalToConstant: 180),
            ctaButton.topAnchor.constraint(equalTo: mainImageView.bottomAnchor, constant: 8),
            ctaButton.trailingAnchor.constraint(equalTo: nativeAdContainerView.trailingAnchor, constant: -8),
            ctaButton.bottomAnchor.constraint(equalTo: nativeAdContainerView.bottomAnchor, constant: -8)
        ])

        logTextView.isEditable = false
        logTextView.font = .systemFont(ofSize: 12)
        logTextView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(logTextView)

        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            logTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16),
            logTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            logTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            logTextView.heightAnchor.constraint(equalToConstant: 120)
        ])
    }

    private func setupAd() {
        nativeAd = APSSPNativeAd(appKey: "397261446",placementId: "iOS_NATIVE", rootViewController: self)
        nativeAd.delegate = self

        // ========================================
        // 1. 자사 Renderer
        // ========================================
        let adPopcornRenderer = APSSPNativeAdRenderer()
        adPopcornRenderer.nativeView = nativeAdContainerView
        adPopcornRenderer.adTitleLabel = titleLabel
        adPopcornRenderer.adDescLabel = descLabel
        adPopcornRenderer.adMainImageView = mainImageView
        adPopcornRenderer.adAppIconView = iconImageView
        adPopcornRenderer.adCTAButton = ctaButton
        adPopcornRenderer.privacyIconPosition = .topRight
        adPopcornRenderer.useTemplate = false
        nativeAd.bindAdPopcornRenderer(adPopcornRender: adPopcornRenderer)

        // ========================================
        // 2. Google 계열 (AdMob / GAM / ADOP / AdForus)
        // ========================================
        let googleNativeAdView = buildGoogleNativeAdView()
        

        let adMobR = APSSPAdMobNativeAdRenderer()
        adMobR.admobNativewAdView = googleNativeAdView
        nativeAd.bindAdMobRenderer(renderer: adMobR)

        let gamR = APSSPGAMNativeAdRenderer()
        gamR.gamNativeAdView = googleNativeAdView
        nativeAd.bindGAMRenderer(renderer: gamR)

        let adopR = APSSPADOPNativeAdRenderer()
        adopR.admobNativewAdView = googleNativeAdView
        nativeAd.bindADOPRenderer(renderer: adopR)

        let adForusR = APSSPAdForusNativeAdRenderer()
        adForusR.adforusNativeAdView = googleNativeAdView
        nativeAd.bindAdForusRenderer(renderer: adForusR)

        // ========================================
        // 3. AppLovin MAX
        // ========================================
        let appLovinR = APSSPAppLovinNativeAdRenderer()
        appLovinR.nativeAdView = buildAppLovinMaxNativeAdView()
        nativeAd.bindAppLovinMaxRenderer(renderer: appLovinR)

        // ========================================
        // 4. Vungle
        // ========================================
        let vungleR = buildVungleRenderer()
        nativeAd.bindVungleRenderer(renderer: vungleR)

        // ========================================
        // 5. AdFit (BizBoard 모드) (커스텀 모드)
        // ========================================
        let adFitR = APSSPAdFitNativeAdRenderer()
        adFitR.useBizBoardTemplate = true
        nativeAd.bindAdFitRenderer(renderer: adFitR)
        
        // (커스텀 모드)
//        let adFitR = APSSPAdFitNativeAdRenderer()
//        adFitR.useBizBoardTemplate = false
//        adFitR.adfitNativewAdView = MyAdFitNativeAdView()
//        nativeAd.bindAdFitRenderer(renderer: adFitR)
        
        // ========================================
        // 7. NAM (심플형 + 일반형)
        // ========================================
        let namR = APSSPNAMNativeAdRenderer()
        namR.namNativeSimpleAdView = buildNAMNativeSimpleAdView()
        namR.namNativeAdView = buildNAMNativeAdView()
        namR.backgroundBlur = true
        nativeAd.bindNAMRenderer(renderer: namR)

        // 8. FAN
        let fanR = APSSPFBANNativeAdRenderer()
        nativeAd.bindFBANRenderer(renderer: fanR)

        // 9. InMobi
        let inMobiR = APSSPInMobiNativeAdRenderer()
        nativeAd.bindInMobiRenderer(renderer: inMobiR)

        // 10. Fyber
        let fyberR = APSSPFyberNativeAdRenderer()
        nativeAd.bindFyberRenderer(renderer: fyberR)

        // 11. CSJ
        let csjR = APSSPCSJNativeAdRenderer()
        nativeAd.bindCSJRenderer(renderer: csjR)

        // 12. Moloco
        let molocoR = APSSPMolocoNativeAdRenderer()
        nativeAd.bindMolocoRenderer(renderer: molocoR)

        // nativeAd를 뷰에 추가 (광고 로드 성공 시 contentView가 여기에 표시됨)
        view.addSubview(nativeAd)
        nativeAd.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            nativeAd.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 60),
            nativeAd.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            nativeAd.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            nativeAd.heightAnchor.constraint(equalToConstant: 350)
        ])
    }

    // MARK: - Google Native Ad View

    private func buildGoogleNativeAdView() -> NativeAdView {
        let nativeAdView = NativeAdView()
        let titleLabel = UILabel(); titleLabel.font = .boldSystemFont(ofSize: 15)
        let bodyLabel = UILabel(); bodyLabel.font = .systemFont(ofSize: 13); bodyLabel.numberOfLines = 2
        let iconImageView = UIImageView()
        let mediaView = MediaView()
        let ctaButton = UIButton(type: .system); ctaButton.setTitle("Install", for: .normal)

        [titleLabel, bodyLabel, iconImageView, mediaView, ctaButton].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            nativeAdView.addSubview($0)
        }
        NSLayoutConstraint.activate([
            iconImageView.topAnchor.constraint(equalTo: nativeAdView.topAnchor, constant: 8),
            iconImageView.leadingAnchor.constraint(equalTo: nativeAdView.leadingAnchor, constant: 8),
            iconImageView.widthAnchor.constraint(equalToConstant: 40),
            iconImageView.heightAnchor.constraint(equalToConstant: 40),
            titleLabel.topAnchor.constraint(equalTo: nativeAdView.topAnchor, constant: 10),
            titleLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 8),
            titleLabel.trailingAnchor.constraint(equalTo: nativeAdView.trailingAnchor, constant: -8),
            bodyLabel.topAnchor.constraint(equalTo: iconImageView.bottomAnchor, constant: 8),
            bodyLabel.leadingAnchor.constraint(equalTo: nativeAdView.leadingAnchor, constant: 8),
            bodyLabel.trailingAnchor.constraint(equalTo: nativeAdView.trailingAnchor, constant: -8),
            mediaView.topAnchor.constraint(equalTo: bodyLabel.bottomAnchor, constant: 8),
            mediaView.leadingAnchor.constraint(equalTo: nativeAdView.leadingAnchor),
            mediaView.trailingAnchor.constraint(equalTo: nativeAdView.trailingAnchor),
            mediaView.heightAnchor.constraint(equalToConstant: 160),
            ctaButton.topAnchor.constraint(equalTo: mediaView.bottomAnchor, constant: 8),
            ctaButton.trailingAnchor.constraint(equalTo: nativeAdView.trailingAnchor, constant: -8),
        ])

        nativeAdView.headlineView = titleLabel
        nativeAdView.bodyView = bodyLabel
        nativeAdView.iconView = iconImageView
        nativeAdView.mediaView = mediaView
        nativeAdView.callToActionView = ctaButton
        return nativeAdView
    }

    // MARK: - AppLovin MAX Native Ad View

    private func buildAppLovinMaxNativeAdView() -> MANativeAdView {
        let nativeAdView = MANativeAdView()
        let titleLabel = UILabel(); titleLabel.tag = 1001; titleLabel.font = .boldSystemFont(ofSize: 15)
        let advertiserLabel = UILabel(); advertiserLabel.tag = 1002; advertiserLabel.font = .systemFont(ofSize: 12); advertiserLabel.textColor = .gray
        let bodyLabel = UILabel(); bodyLabel.tag = 1003; bodyLabel.font = .systemFont(ofSize: 13); bodyLabel.numberOfLines = 2
        let iconImageView = UIImageView(); iconImageView.tag = 1004
        let optionsView = UIView(); optionsView.tag = 1005
        let mediaView = UIView(); mediaView.tag = 1006
        let ctaButton = UIButton(type: .system); ctaButton.tag = 1007; ctaButton.setTitle("CTA", for: .normal)

        [titleLabel, advertiserLabel, bodyLabel, iconImageView, optionsView, mediaView, ctaButton].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            nativeAdView.addSubview($0)
        }
        NSLayoutConstraint.activate([
            iconImageView.topAnchor.constraint(equalTo: nativeAdView.topAnchor, constant: 8),
            iconImageView.leadingAnchor.constraint(equalTo: nativeAdView.leadingAnchor, constant: 8),
            iconImageView.widthAnchor.constraint(equalToConstant: 40),
            iconImageView.heightAnchor.constraint(equalToConstant: 40),
            titleLabel.topAnchor.constraint(equalTo: nativeAdView.topAnchor, constant: 10),
            titleLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 8),
            titleLabel.trailingAnchor.constraint(equalTo: nativeAdView.trailingAnchor, constant: -8),
            advertiserLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 2),
            advertiserLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            bodyLabel.topAnchor.constraint(equalTo: iconImageView.bottomAnchor, constant: 8),
            bodyLabel.leadingAnchor.constraint(equalTo: nativeAdView.leadingAnchor, constant: 8),
            bodyLabel.trailingAnchor.constraint(equalTo: nativeAdView.trailingAnchor, constant: -8),
            mediaView.topAnchor.constraint(equalTo: bodyLabel.bottomAnchor, constant: 8),
            mediaView.leadingAnchor.constraint(equalTo: nativeAdView.leadingAnchor),
            mediaView.trailingAnchor.constraint(equalTo: nativeAdView.trailingAnchor),
            mediaView.heightAnchor.constraint(equalToConstant: 160),
            ctaButton.topAnchor.constraint(equalTo: mediaView.bottomAnchor, constant: 8),
            ctaButton.trailingAnchor.constraint(equalTo: nativeAdView.trailingAnchor, constant: -8),
            optionsView.topAnchor.constraint(equalTo: nativeAdView.topAnchor, constant: 4),
            optionsView.trailingAnchor.constraint(equalTo: nativeAdView.trailingAnchor, constant: -4),
            optionsView.widthAnchor.constraint(equalToConstant: 20),
            optionsView.heightAnchor.constraint(equalToConstant: 20),
        ])

        let binder = MANativeAdViewBinder { builder in
            builder.titleLabelTag = 1001
            builder.advertiserLabelTag = 1002
            builder.bodyLabelTag = 1003
            builder.iconImageViewTag = 1004
            builder.optionsContentViewTag = 1005
            builder.mediaContentViewTag = 1006
            builder.callToActionButtonTag = 1007
        }
        nativeAdView.bindViews(with: binder)
        return nativeAdView
    }

    // MARK: - Vungle Renderer

    private func buildVungleRenderer() -> APSSPVungleNativeAdRenderer {
        let container = UIView()
        let iconView = UIImageView()
        let titleLabel = UILabel(); titleLabel.font = .boldSystemFont(ofSize: 14)
        let bodyLabel = UILabel(); bodyLabel.font = .systemFont(ofSize: 12); bodyLabel.numberOfLines = 2
        let ctaButton = UIButton(type: .system); ctaButton.setTitle("Install", for: .normal)
        let mediaView = VungleAdsSDK.MediaView()

        [iconView, titleLabel, bodyLabel, ctaButton, mediaView].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            container.addSubview($0)
        }
        NSLayoutConstraint.activate([
            iconView.topAnchor.constraint(equalTo: container.topAnchor, constant: 8),
            iconView.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 8),
            iconView.widthAnchor.constraint(equalToConstant: 40),
            iconView.heightAnchor.constraint(equalToConstant: 40),
            titleLabel.topAnchor.constraint(equalTo: container.topAnchor, constant: 10),
            titleLabel.leadingAnchor.constraint(equalTo: iconView.trailingAnchor, constant: 8),
            titleLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -8),
            bodyLabel.topAnchor.constraint(equalTo: iconView.bottomAnchor, constant: 8),
            bodyLabel.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 8),
            bodyLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -8),
            mediaView.topAnchor.constraint(equalTo: bodyLabel.bottomAnchor, constant: 8),
            mediaView.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            mediaView.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            mediaView.heightAnchor.constraint(equalToConstant: 160),
            ctaButton.topAnchor.constraint(equalTo: mediaView.bottomAnchor, constant: 8),
            ctaButton.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -8),
        ])

        let renderer = APSSPVungleNativeAdRenderer()
        renderer.nativeAdView = container
        renderer.iconView = iconView
        renderer.titleLbl = titleLabel
        renderer.adTextLbl = bodyLabel
        renderer.downloadBtn = ctaButton
        renderer.mediaView = mediaView
        return renderer
    }

    // MARK: - NAM Native Simple Ad View (심플형)

    private func buildNAMNativeSimpleAdView() -> GFPNativeSimpleAdView {
        let adView = GFPNativeSimpleAdView(frame: CGRect(x: 0, y: 0, width: 320, height: 200))
        let mediaView = GFPMediaView()
        mediaView.translatesAutoresizingMaskIntoConstraints = false
        adView.addSubview(mediaView)
        NSLayoutConstraint.activate([
            mediaView.topAnchor.constraint(equalTo: adView.topAnchor),
            mediaView.leadingAnchor.constraint(equalTo: adView.leadingAnchor),
            mediaView.trailingAnchor.constraint(equalTo: adView.trailingAnchor),
            mediaView.bottomAnchor.constraint(equalTo: adView.bottomAnchor),
        ])
        adView.mediaView = mediaView
        return adView
    }

    // MARK: - NAM Native Ad View (일반형)

    private func buildNAMNativeAdView() -> GFPNativeAdView {
        let adView = GFPNativeAdView(frame: CGRect(x: 0, y: 0, width: 320, height: 300))
        let iconView = UIImageView()
        let titleLabel = UILabel(); titleLabel.font = .boldSystemFont(ofSize: 15)
        let bodyLabel = UILabel(); bodyLabel.font = .systemFont(ofSize: 13); bodyLabel.numberOfLines = 2
        let advertiserLabel = UILabel(); advertiserLabel.font = .systemFont(ofSize: 12); advertiserLabel.textColor = .gray
        let mediaView = GFPMediaView()
        let ctaLabel = UILabel(); ctaLabel.font = .boldSystemFont(ofSize: 14); ctaLabel.textColor = .systemBlue
        let adBadgeLabel = UILabel(); adBadgeLabel.text = "AD"; adBadgeLabel.font = .systemFont(ofSize: 10, weight: .semibold); adBadgeLabel.textColor = .gray

        [iconView, titleLabel, bodyLabel, advertiserLabel, mediaView, ctaLabel, adBadgeLabel].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            adView.addSubview($0)
        }
        NSLayoutConstraint.activate([
            iconView.topAnchor.constraint(equalTo: adView.topAnchor, constant: 8),
            iconView.leadingAnchor.constraint(equalTo: adView.leadingAnchor, constant: 8),
            iconView.widthAnchor.constraint(equalToConstant: 40),
            iconView.heightAnchor.constraint(equalToConstant: 40),
            titleLabel.topAnchor.constraint(equalTo: adView.topAnchor, constant: 10),
            titleLabel.leadingAnchor.constraint(equalTo: iconView.trailingAnchor, constant: 8),
            titleLabel.trailingAnchor.constraint(equalTo: adView.trailingAnchor, constant: -8),
            advertiserLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 2),
            advertiserLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            bodyLabel.topAnchor.constraint(equalTo: iconView.bottomAnchor, constant: 8),
            bodyLabel.leadingAnchor.constraint(equalTo: adView.leadingAnchor, constant: 8),
            bodyLabel.trailingAnchor.constraint(equalTo: adView.trailingAnchor, constant: -8),
            mediaView.topAnchor.constraint(equalTo: bodyLabel.bottomAnchor, constant: 8),
            mediaView.leadingAnchor.constraint(equalTo: adView.leadingAnchor),
            mediaView.trailingAnchor.constraint(equalTo: adView.trailingAnchor),
            mediaView.heightAnchor.constraint(equalToConstant: 160),
            ctaLabel.topAnchor.constraint(equalTo: mediaView.bottomAnchor, constant: 8),
            ctaLabel.trailingAnchor.constraint(equalTo: adView.trailingAnchor, constant: -8),
            adBadgeLabel.topAnchor.constraint(equalTo: adView.topAnchor, constant: 4),
            adBadgeLabel.leadingAnchor.constraint(equalTo: adView.leadingAnchor, constant: 4),
        ])

        adView.titleLabel = titleLabel
        adView.bodyLabel = bodyLabel
        adView.advertiserLabel = advertiserLabel
        adView.iconView = iconView
        adView.mediaView = mediaView
        adView.callToActionLabel = ctaLabel
        adView.adBadgeLabel = adBadgeLabel
        return adView
    }

    // MARK: - Actions

    @objc private func loadTapped() {
        log("load()")
        nativeAd.load()
    }

    @objc private func stopTapped() {
        log("stop()")
        nativeAd.stop()
    }

    private func log(_ msg: String) {
        logTextView.text += "\(msg)\n"
        let bottom = NSRange(location: logTextView.text.count - 1, length: 1)
        logTextView.scrollRangeToVisible(bottom)
    }

    // MARK: - APSSPNativeAdDelegate

    func apsspNativeAdLoadSuccess(nativeAdView: APSSPNativeAd) {
        log("✅ Native Load Success")
    }

    func apsspNativeAdLoadFail(nativeAdView: APSSPNativeAd, error: APSSPNetworkError) {
        log("❌ Native Load Fail: \(error.errorMessage)")
    }

    func apsspNativeAdImpression(nativeAd: APSSPNativeAd) {
        log("👁 Native Impression")
    }

    func apsspNativeAdClicked(nativeAd: APSSPNativeAd) {
        log("👆 Native Clicked")
    }

    func apsspNativeAdHidden(nativeAd: APSSPNativeAd) {
        log("🙈 Native Hidden")
    }
}
