import UIKit
import SwiftUI

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }
        window = UIWindow(windowScene: windowScene)
        
        window = UIWindow(windowScene: windowScene)

        // SwiftUI 모드
        window?.rootViewController = UIHostingController(rootView: ContentView())
        
        // UIKit 모드 (기존)
//        let nav = UINavigationController(rootViewController: MainViewController())
//        window?.rootViewController = nav
        
        window?.makeKeyAndVisible()
    }
}
