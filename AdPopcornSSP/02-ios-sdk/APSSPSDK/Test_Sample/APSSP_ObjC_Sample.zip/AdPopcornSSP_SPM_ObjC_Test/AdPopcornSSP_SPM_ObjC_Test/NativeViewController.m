#import "NativeViewController.h"
@import APSSPSDK;
@import GoogleMobileAds;
@import AppLovinSDK;
@import VungleAdsSDK;
@import AdFitSDK;
@import GFPSDK;

@import APSSPMediationAdMob;
@import APSSPMediationADOP;
@import APSSPMediationGAM;
@import APSSPMediationAdForus;
@import APSSPMediationAppLovinMax;
@import APSSPMediationVungle;
@import APSSPMediationMintegral;
@import APSSPMediationNAM;
@import APSSPMediationAdFit;

@interface NativeViewController () <APSSPNativeAdDelegate>
@property (nonatomic, strong) APSSPNativeAd *nativeAd;
@end

@implementation NativeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.view.opaque = YES;
    self.title = @"Native";
    
    UIButton *loadBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [loadBtn setTitle:@"Load Native" forState:UIControlStateNormal];
    [loadBtn addTarget:self action:@selector(loadTapped) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *stopBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [stopBtn setTitle:@"Stop" forState:UIControlStateNormal];
    [stopBtn addTarget:self action:@selector(stopTapped) forControlEvents:UIControlEventTouchUpInside];
    
    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[loadBtn, stopBtn]];
    stack.spacing = 16;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [stack.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:16],
        [stack.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor]
    ]];
    
    [self setupAd];
    
    self.nativeAd.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.nativeAd];
    [NSLayoutConstraint activateConstraints:@[
        [self.nativeAd.topAnchor constraintEqualToAnchor:stack.bottomAnchor constant:16],
        [self.nativeAd.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],
        [self.nativeAd.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],
        [self.nativeAd.heightAnchor constraintEqualToConstant:350]
    ]];
}

- (void)setupAd {
    self.nativeAd = [[APSSPNativeAd alloc] initWithAppKey:@"62198111" placementId:@"3rowMHvpjID7rB0" rootViewController:self];
    self.nativeAd.delegate = self;
    
    // 1. 자사 Renderer
    APSSPNativeAdView *nativeAdView = [[APSSPNativeAdView alloc] init];
    UILabel *titleLabel = [[UILabel alloc] init]; titleLabel.font = [UIFont boldSystemFontOfSize:14]; titleLabel.numberOfLines = 2;
    UILabel *descLabel = [[UILabel alloc] init]; descLabel.font = [UIFont systemFontOfSize:12]; descLabel.numberOfLines = 2;
    UIImageView *mainImageView = [[UIImageView alloc] init]; mainImageView.contentMode = UIViewContentModeScaleAspectFill; mainImageView.clipsToBounds = YES;
    UIImageView *iconImageView = [[UIImageView alloc] init]; iconImageView.contentMode = UIViewContentModeScaleAspectFit;
    UIButton *ctaButton = [UIButton buttonWithType:UIButtonTypeSystem]; [ctaButton setTitle:@"Install" forState:UIControlStateNormal];
    
    for (UIView *v in @[titleLabel, descLabel, mainImageView, iconImageView, ctaButton]) {
        v.translatesAutoresizingMaskIntoConstraints = NO;
        [nativeAdView addSubview:v];
    }
    [NSLayoutConstraint activateConstraints:@[
        [iconImageView.topAnchor constraintEqualToAnchor:nativeAdView.topAnchor constant:8],
        [iconImageView.leadingAnchor constraintEqualToAnchor:nativeAdView.leadingAnchor constant:8],
        [iconImageView.widthAnchor constraintEqualToConstant:40], [iconImageView.heightAnchor constraintEqualToConstant:40],
        [titleLabel.topAnchor constraintEqualToAnchor:nativeAdView.topAnchor constant:8],
        [titleLabel.leadingAnchor constraintEqualToAnchor:iconImageView.trailingAnchor constant:8],
        [titleLabel.trailingAnchor constraintEqualToAnchor:nativeAdView.trailingAnchor constant:-8],
        [descLabel.topAnchor constraintEqualToAnchor:titleLabel.bottomAnchor constant:4],
        [descLabel.leadingAnchor constraintEqualToAnchor:titleLabel.leadingAnchor],
        [descLabel.trailingAnchor constraintEqualToAnchor:titleLabel.trailingAnchor],
        [mainImageView.topAnchor constraintEqualToAnchor:iconImageView.bottomAnchor constant:8],
        [mainImageView.leadingAnchor constraintEqualToAnchor:nativeAdView.leadingAnchor],
        [mainImageView.trailingAnchor constraintEqualToAnchor:nativeAdView.trailingAnchor],
        [mainImageView.heightAnchor constraintEqualToConstant:180],
        [ctaButton.topAnchor constraintEqualToAnchor:mainImageView.bottomAnchor constant:8],
        [ctaButton.trailingAnchor constraintEqualToAnchor:nativeAdView.trailingAnchor constant:-8],
    ]];
    
    APSSPNativeAdRenderer *adPopcornR = [[APSSPNativeAdRenderer alloc] init];
    adPopcornR.nativeView = nativeAdView;
    adPopcornR.adTitleLabel = titleLabel;
    adPopcornR.adDescLabel = descLabel;
    adPopcornR.adMainImageView = mainImageView;
    adPopcornR.adAppIconView = iconImageView;
    adPopcornR.adCTAButton = ctaButton;
    adPopcornR.privacyIconPosition = APSSPPrivacyIconPositionTopRight;
    adPopcornR.useTemplate = NO;
    [self.nativeAd bindAdPopcornRendererWithAdPopcornRender:adPopcornR];
    
    // 2. Google 계열 (AdMob / GAM / ADOP / AdForus)
    GADNativeAdView *googleNativeAdView = [self buildGoogleNativeAdView];
    
    APSSPAdMobNativeAdRenderer *adMobR = [[APSSPAdMobNativeAdRenderer alloc] init];
    adMobR.admobNativewAdView = googleNativeAdView;
    [self.nativeAd bindAdMobRendererWithRenderer:adMobR];
    
    APSSPGAMNativeAdRenderer *gamR = [[APSSPGAMNativeAdRenderer alloc] init];
    gamR.contentView = googleNativeAdView;
    [self.nativeAd bindGAMRendererWithRenderer:gamR];
    
    APSSPADOPNativeAdRenderer *adopR = [[APSSPADOPNativeAdRenderer alloc] init];
    adopR.admobNativewAdView = googleNativeAdView;
    [self.nativeAd bindADOPRendererWithRenderer:adopR];
    
    APSSPAdForusNativeAdRenderer *adForusR = [[APSSPAdForusNativeAdRenderer alloc] init];
    adForusR.adforusNativeAdView = googleNativeAdView;
    [self.nativeAd bindAdForusRendererWithRenderer:adForusR];
    
    // 3. AppLovin MAX
    APSSPAppLovinNativeAdRenderer *appLovinR = [[APSSPAppLovinNativeAdRenderer alloc] init];
    appLovinR.nativeAdView = [self buildAppLovinMaxNativeAdView];
    [self.nativeAd bindAppLovinMaxRendererWithRenderer:appLovinR];
    
    // 4. Vungle
    [self.nativeAd bindVungleRendererWithRenderer:[self buildVungleRenderer]];
    
    // 5. AdFit (BizBoard)
    APSSPAdFitNativeAdRenderer *adFitR = [[APSSPAdFitNativeAdRenderer alloc] init];
    adFitR.useBizBoardTemplate = YES;
    [self.nativeAd bindAdFitRendererWithRenderer:adFitR];
    
    // 6. Mintegral
    APSSPMintegralNativeAdRenderer *mintegralR = [[APSSPMintegralNativeAdRenderer alloc] init];
    [self.nativeAd bindMintegralRendererWithRenderer:mintegralR];
    
    // 7. NAM (심플형 + 일반형)
    APSSPNAMNativeAdRenderer *namR = [[APSSPNAMNativeAdRenderer alloc] init];
    namR.namNativeSimpleAdView = [self buildNAMNativeSimpleAdView];
    namR.namNativeAdView = [self buildNAMNativeAdView];
    namR.backgroundBlur = YES;
    [self.nativeAd bindNAMRendererWithRenderer:namR];
}

#pragma mark - Google Native Ad View

- (GADNativeAdView *)buildGoogleNativeAdView {
    GADNativeAdView *nativeAdView = [[GADNativeAdView alloc] init];
    UILabel *titleLabel = [[UILabel alloc] init]; titleLabel.font = [UIFont boldSystemFontOfSize:15];
    UILabel *bodyLabel = [[UILabel alloc] init]; bodyLabel.font = [UIFont systemFontOfSize:13]; bodyLabel.numberOfLines = 2;
    UIImageView *iconImageView = [[UIImageView alloc] init];
    GADMediaView *mediaView = [[GADMediaView alloc] init];
    UIButton *ctaButton = [UIButton buttonWithType:UIButtonTypeSystem]; [ctaButton setTitle:@"Install" forState:UIControlStateNormal];
    
    NSArray *views = @[titleLabel, bodyLabel, iconImageView, mediaView, ctaButton];
    for (UIView *v in views) { v.translatesAutoresizingMaskIntoConstraints = NO; [nativeAdView addSubview:v]; }
    [NSLayoutConstraint activateConstraints:@[
        [iconImageView.topAnchor constraintEqualToAnchor:nativeAdView.topAnchor constant:8],
        [iconImageView.leadingAnchor constraintEqualToAnchor:nativeAdView.leadingAnchor constant:8],
        [iconImageView.widthAnchor constraintEqualToConstant:40], [iconImageView.heightAnchor constraintEqualToConstant:40],
        [titleLabel.topAnchor constraintEqualToAnchor:nativeAdView.topAnchor constant:10],
        [titleLabel.leadingAnchor constraintEqualToAnchor:iconImageView.trailingAnchor constant:8],
        [titleLabel.trailingAnchor constraintEqualToAnchor:nativeAdView.trailingAnchor constant:-8],
        [bodyLabel.topAnchor constraintEqualToAnchor:iconImageView.bottomAnchor constant:8],
        [bodyLabel.leadingAnchor constraintEqualToAnchor:nativeAdView.leadingAnchor constant:8],
        [bodyLabel.trailingAnchor constraintEqualToAnchor:nativeAdView.trailingAnchor constant:-8],
        [mediaView.topAnchor constraintEqualToAnchor:bodyLabel.bottomAnchor constant:8],
        [mediaView.leadingAnchor constraintEqualToAnchor:nativeAdView.leadingAnchor],
        [mediaView.trailingAnchor constraintEqualToAnchor:nativeAdView.trailingAnchor],
        [mediaView.heightAnchor constraintEqualToConstant:160],
        [ctaButton.topAnchor constraintEqualToAnchor:mediaView.bottomAnchor constant:8],
        [ctaButton.trailingAnchor constraintEqualToAnchor:nativeAdView.trailingAnchor constant:-8],
    ]];
    nativeAdView.headlineView = titleLabel;
    nativeAdView.bodyView = bodyLabel;
    nativeAdView.iconView = iconImageView;
    nativeAdView.mediaView = mediaView;
    nativeAdView.callToActionView = ctaButton;
    return nativeAdView;
}

#pragma mark - AppLovin MAX

- (MANativeAdView *)buildAppLovinMaxNativeAdView {
    MANativeAdView *nativeAdView = [[MANativeAdView alloc] init];
    UILabel *titleLabel = [[UILabel alloc] init]; titleLabel.tag = 1001; titleLabel.font = [UIFont boldSystemFontOfSize:15];
    UILabel *bodyLabel = [[UILabel alloc] init]; bodyLabel.tag = 1003; bodyLabel.font = [UIFont systemFontOfSize:13]; bodyLabel.numberOfLines = 2;
    UIImageView *iconImageView = [[UIImageView alloc] init]; iconImageView.tag = 1004;
    UIView *mediaView = [[UIView alloc] init]; mediaView.tag = 1006;
    UIButton *ctaButton = [UIButton buttonWithType:UIButtonTypeSystem]; ctaButton.tag = 1007; [ctaButton setTitle:@"CTA" forState:UIControlStateNormal];
    UIView *optionsView = [[UIView alloc] init]; optionsView.tag = 1005;
    
    NSArray *views = @[titleLabel, bodyLabel, iconImageView, mediaView, ctaButton, optionsView];
    for (UIView *v in views) { v.translatesAutoresizingMaskIntoConstraints = NO; [nativeAdView addSubview:v]; }
    [NSLayoutConstraint activateConstraints:@[
        [iconImageView.topAnchor constraintEqualToAnchor:nativeAdView.topAnchor constant:8],
        [iconImageView.leadingAnchor constraintEqualToAnchor:nativeAdView.leadingAnchor constant:8],
        [iconImageView.widthAnchor constraintEqualToConstant:40], [iconImageView.heightAnchor constraintEqualToConstant:40],
        [titleLabel.topAnchor constraintEqualToAnchor:nativeAdView.topAnchor constant:10],
        [titleLabel.leadingAnchor constraintEqualToAnchor:iconImageView.trailingAnchor constant:8],
        [titleLabel.trailingAnchor constraintEqualToAnchor:nativeAdView.trailingAnchor constant:-8],
        [bodyLabel.topAnchor constraintEqualToAnchor:iconImageView.bottomAnchor constant:8],
        [bodyLabel.leadingAnchor constraintEqualToAnchor:nativeAdView.leadingAnchor constant:8],
        [bodyLabel.trailingAnchor constraintEqualToAnchor:nativeAdView.trailingAnchor constant:-8],
        [mediaView.topAnchor constraintEqualToAnchor:bodyLabel.bottomAnchor constant:8],
        [mediaView.leadingAnchor constraintEqualToAnchor:nativeAdView.leadingAnchor],
        [mediaView.trailingAnchor constraintEqualToAnchor:nativeAdView.trailingAnchor],
        [mediaView.heightAnchor constraintEqualToConstant:160],
        [ctaButton.topAnchor constraintEqualToAnchor:mediaView.bottomAnchor constant:8],
        [ctaButton.trailingAnchor constraintEqualToAnchor:nativeAdView.trailingAnchor constant:-8],
        [optionsView.topAnchor constraintEqualToAnchor:nativeAdView.topAnchor constant:4],
        [optionsView.trailingAnchor constraintEqualToAnchor:nativeAdView.trailingAnchor constant:-4],
        [optionsView.widthAnchor constraintEqualToConstant:20], [optionsView.heightAnchor constraintEqualToConstant:20],
    ]];
    
    MANativeAdViewBinder *binder = [[MANativeAdViewBinder alloc] initWithBuilderBlock:^(MANativeAdViewBinderBuilder *builder) {
        builder.titleLabelTag = 1001;
        builder.bodyLabelTag = 1003;
        builder.iconImageViewTag = 1004;
        builder.optionsContentViewTag = 1005;
        builder.mediaContentViewTag = 1006;
        builder.callToActionButtonTag = 1007;
    }];
    [nativeAdView bindViewsWithAdViewBinder:binder];
    return nativeAdView;
}

#pragma mark - Vungle

- (APSSPVungleNativeAdRenderer *)buildVungleRenderer {
    UIView *container = [[UIView alloc] init];
    UIImageView *iconView = [[UIImageView alloc] init];
    UILabel *titleLabel = [[UILabel alloc] init]; titleLabel.font = [UIFont boldSystemFontOfSize:14];
    UILabel *bodyLabel = [[UILabel alloc] init]; bodyLabel.font = [UIFont systemFontOfSize:12]; bodyLabel.numberOfLines = 2;
    UIButton *ctaButton = [UIButton buttonWithType:UIButtonTypeSystem]; [ctaButton setTitle:@"Install" forState:UIControlStateNormal];
    MediaView *mediaView = [[MediaView alloc] init];
    
    NSArray *views = @[iconView, titleLabel, bodyLabel, ctaButton, mediaView];
    for (UIView *v in views) { v.translatesAutoresizingMaskIntoConstraints = NO; [container addSubview:v]; }
    [NSLayoutConstraint activateConstraints:@[
        [iconView.topAnchor constraintEqualToAnchor:container.topAnchor constant:8],
        [iconView.leadingAnchor constraintEqualToAnchor:container.leadingAnchor constant:8],
        [iconView.widthAnchor constraintEqualToConstant:40], [iconView.heightAnchor constraintEqualToConstant:40],
        [titleLabel.topAnchor constraintEqualToAnchor:container.topAnchor constant:10],
        [titleLabel.leadingAnchor constraintEqualToAnchor:iconView.trailingAnchor constant:8],
        [titleLabel.trailingAnchor constraintEqualToAnchor:container.trailingAnchor constant:-8],
        [bodyLabel.topAnchor constraintEqualToAnchor:iconView.bottomAnchor constant:8],
        [bodyLabel.leadingAnchor constraintEqualToAnchor:container.leadingAnchor constant:8],
        [bodyLabel.trailingAnchor constraintEqualToAnchor:container.trailingAnchor constant:-8],
        [mediaView.topAnchor constraintEqualToAnchor:bodyLabel.bottomAnchor constant:8],
        [mediaView.leadingAnchor constraintEqualToAnchor:container.leadingAnchor],
        [mediaView.trailingAnchor constraintEqualToAnchor:container.trailingAnchor],
        [mediaView.heightAnchor constraintEqualToConstant:160],
        [ctaButton.topAnchor constraintEqualToAnchor:mediaView.bottomAnchor constant:8],
        [ctaButton.trailingAnchor constraintEqualToAnchor:container.trailingAnchor constant:-8],
    ]];
    
    APSSPVungleNativeAdRenderer *renderer = [[APSSPVungleNativeAdRenderer alloc] init];
    renderer.nativeAdView = container;
    renderer.iconView = iconView;
    renderer.titleLbl = titleLabel;
    renderer.adTextLbl = bodyLabel;
    renderer.downloadBtn = ctaButton;
    renderer.mediaView = mediaView;
    return renderer;
}

#pragma mark - NAM

- (GFPNativeSimpleAdView *)buildNAMNativeSimpleAdView {
    GFPNativeSimpleAdView *adView = [[GFPNativeSimpleAdView alloc] initWithFrame:CGRectMake(0, 0, 320, 200)];
    GFPMediaView *mediaView = [[GFPMediaView alloc] init];
    mediaView.translatesAutoresizingMaskIntoConstraints = NO;
    [adView addSubview:mediaView];
    [NSLayoutConstraint activateConstraints:@[
        [mediaView.topAnchor constraintEqualToAnchor:adView.topAnchor],
        [mediaView.leadingAnchor constraintEqualToAnchor:adView.leadingAnchor],
        [mediaView.trailingAnchor constraintEqualToAnchor:adView.trailingAnchor],
        [mediaView.bottomAnchor constraintEqualToAnchor:adView.bottomAnchor],
    ]];
    adView.mediaView = mediaView;
    return adView;
}

- (GFPNativeAdView *)buildNAMNativeAdView {
    GFPNativeAdView *adView = [[GFPNativeAdView alloc] initWithFrame:CGRectMake(0, 0, 320, 300)];
    UIImageView *iconView = [[UIImageView alloc] init];
    UILabel *titleLabel = [[UILabel alloc] init]; titleLabel.font = [UIFont boldSystemFontOfSize:15];
    UILabel *bodyLabel = [[UILabel alloc] init]; bodyLabel.font = [UIFont systemFontOfSize:13]; bodyLabel.numberOfLines = 2;
    GFPMediaView *mediaView = [[GFPMediaView alloc] init];
    UILabel *ctaLabel = [[UILabel alloc] init]; ctaLabel.font = [UIFont boldSystemFontOfSize:14]; ctaLabel.textColor = UIColor.systemBlueColor;
    
    NSArray *views = @[iconView, titleLabel, bodyLabel, mediaView, ctaLabel];
    for (UIView *v in views) { v.translatesAutoresizingMaskIntoConstraints = NO; [adView addSubview:v]; }
    [NSLayoutConstraint activateConstraints:@[
        [iconView.topAnchor constraintEqualToAnchor:adView.topAnchor constant:8],
        [iconView.leadingAnchor constraintEqualToAnchor:adView.leadingAnchor constant:8],
        [iconView.widthAnchor constraintEqualToConstant:40], [iconView.heightAnchor constraintEqualToConstant:40],
        [titleLabel.topAnchor constraintEqualToAnchor:adView.topAnchor constant:10],
        [titleLabel.leadingAnchor constraintEqualToAnchor:iconView.trailingAnchor constant:8],
        [titleLabel.trailingAnchor constraintEqualToAnchor:adView.trailingAnchor constant:-8],
        [bodyLabel.topAnchor constraintEqualToAnchor:iconView.bottomAnchor constant:8],
        [bodyLabel.leadingAnchor constraintEqualToAnchor:adView.leadingAnchor constant:8],
        [bodyLabel.trailingAnchor constraintEqualToAnchor:adView.trailingAnchor constant:-8],
        [mediaView.topAnchor constraintEqualToAnchor:bodyLabel.bottomAnchor constant:8],
        [mediaView.leadingAnchor constraintEqualToAnchor:adView.leadingAnchor],
        [mediaView.trailingAnchor constraintEqualToAnchor:adView.trailingAnchor],
        [mediaView.heightAnchor constraintEqualToConstant:160],
        [ctaLabel.topAnchor constraintEqualToAnchor:mediaView.bottomAnchor constant:8],
        [ctaLabel.trailingAnchor constraintEqualToAnchor:adView.trailingAnchor constant:-8],
    ]];
    adView.titleLabel = titleLabel;
    adView.bodyLabel = bodyLabel;
    adView.iconView = iconView;
    adView.mediaView = mediaView;
    adView.callToActionLabel = ctaLabel;
    return adView;
}

#pragma mark - Actions

- (void)loadTapped {
    NSLog(@"load()");
    [self.nativeAd load];
}

- (void)stopTapped {
    NSLog(@"stop()");
    [self.nativeAd stop];
}

#pragma mark - APSSPNativeAdDelegate

- (void)apsspNativeAdLoadSuccessWithNativeAdView:(APSSPNativeAd *)nativeAdView {
    NSLog(@"✅ Native Load Success");
}

- (void)apsspNativeAdLoadFailWithNativeAdView:(APSSPNativeAd *)nativeAdView error:(enum APSSPNetworkError)error {
    NSLog(@"❌ Native Load Fail: %ld", (long)error);
}

- (void)apsspNativeAdImpressionWithNativeAd:(APSSPNativeAd *)nativeAd {
    NSLog(@"👁 Native Impression");
}

- (void)apsspNativeAdClickedWithNativeAd:(APSSPNativeAd *)nativeAd {
    NSLog(@"👆 Native Clicked");
}

@end
