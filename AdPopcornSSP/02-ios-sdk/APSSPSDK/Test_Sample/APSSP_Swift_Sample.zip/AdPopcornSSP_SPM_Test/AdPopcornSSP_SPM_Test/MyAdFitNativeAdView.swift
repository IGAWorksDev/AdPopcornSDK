//
//  MyAdFitNativeAdView.swift
//  AdPopcornSSP_SPM_Test
//
//  Created by Odin on 5/18/26.
//

import AdFitSDK

class MyAdFitNativeAdView: UIView, AdFitNativeAdRenderable {
    let titleLabel = UILabel()
    let bodyLabel = UILabel()
    let ctaButton = UIButton()
    let profileImageView = UIImageView()
    let profileNameLabel = UILabel()
    let mediaView = AdFitMediaView()

    func adTitleLabel() -> UILabel? { titleLabel }
    func adBodyLabel() -> UILabel? { bodyLabel }
    func adCallToActionButton() -> UIButton? { ctaButton }
    func adProfileIconView() -> UIImageView? { profileImageView }
    func adProfileNameLabel() -> UILabel? { profileNameLabel }
    func adMediaView() -> AdFitMediaView? { mediaView }
}
