import SwiftUI
import APSSPSDK

struct RewardVideoAdView: View {
    @StateObject private var vm = RewardVideoViewModel()

    var body: some View {
        VStack(spacing: 16) {
            HStack(spacing: 16) {
                Button("Load") { vm.load() }
                Button("Show") { vm.show() }
            }
            List(vm.logs, id: \.self) { Text($0).font(.caption) }
        }
        .navigationTitle("RewardVideo")
    }
}

class RewardVideoViewModel: NSObject, ObservableObject, APSSPRewardVideoAdDelegate {
    @Published var logs: [String] = []
    private var ad: APSSPRewardVideoAd?

    override init() {
        super.init()
        ad = APSSPRewardVideoAd(appKey: "397261446", placementId: "iOS_VIDEO", rootViewController: UIApplication.shared.rootViewController)
        ad?.delegate = self
    }

    func load() {
        logs.append("Load...")
        ad?.load()
    }
    func show() {
        guard let vc = UIApplication.shared.rootViewController else { return }
        ad?.present(from: vc)
    }

    func apsspRewardVideoAdLoadSuccess(rewardVideoAd: APSSPRewardVideoAd) { logs.append("✅ Load Success") }
    func apsspRewardVideoAdLoadFail(rewardVideoAd: APSSPRewardVideoAd, error: APSSPNetworkError) { logs.append("❌ Load Fail: \(error.rawValue)") }
    func apsspRewardVideoAdShowSuccess(rewardVideoAd: APSSPRewardVideoAd) { logs.append("✅ Show Success") }
    func apsspRewardVideoAdPlayCompleted(rewardVideoAd: APSSPRewardVideoAd, adNetworkNo: Int, completed: Bool) { logs.append("🎬 Completed: \(completed)") }
    func apsspRewardVideoAdClosed(rewardVideoAd: APSSPRewardVideoAd) { logs.append("🚪 Closed") }
}
