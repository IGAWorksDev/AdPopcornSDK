import SwiftUI
import APSSPSDK

struct InterstitialVideoAdView: View {
    @StateObject private var vm = InterstitialVideoViewModel()

    var body: some View {
        VStack(spacing: 16) {
            HStack(spacing: 16) {
                Button("Load") { vm.load() }
                Button("Show") { vm.show() }
            }
            List(vm.logs, id: \.self) { Text($0).font(.caption) }
        }
        .navigationTitle("InterstitialVideo")
    }
}

class InterstitialVideoViewModel: NSObject, ObservableObject, APSSPInterstitialVideoAdDelegate {
    @Published var logs: [String] = []
    private var ad: APSSPInterstitialVideoAd?

    override init() {
        super.init()
        ad = APSSPInterstitialVideoAd(appKey: "397261446", placementId: "iOS_VIDEO", rootViewController: UIApplication.shared.rootViewController)
        ad?.delegate = self
    }

    func load() {
        logs.append("Load...")
        ad?.load()
    }
    func show() {
        guard let vc = UIApplication.shared.rootViewController else { return }
        ad?.present(from: vc)
    }

    func apsspInterstitialVideoAdLoadSuccess(interstitialVideoAd: APSSPInterstitialVideoAd) { logs.append("✅ Load Success") }
    func apsspInterstitialVideoAdLoadFail(interstitialVideoAd: APSSPInterstitialVideoAd, error: APSSPNetworkError) { logs.append("❌ Load Fail: \(error.rawValue)") }
    func apsspInterstitialVideoAdShowSuccess(interstitialVideoAd: APSSPInterstitialVideoAd) { logs.append("✅ Show Success") }
    func apsspInterstitialVideoAdClosed(interstitialVideoAd: APSSPInterstitialVideoAd) { logs.append("🚪 Closed") }
}
