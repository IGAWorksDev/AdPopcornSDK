import SwiftUI
import APSSPSDK

struct NativeAdSwiftUIView: View {
    @StateObject private var vm = NativeAdViewModel()

    var body: some View {
        VStack(spacing: 16) {
            HStack(spacing: 16) {
                Button("Load") { vm.load() }
                Button("Stop") { vm.stop() }
            }
            List(vm.logs, id: \.self) { Text($0).font(.caption) }
            NativeAdRepresentable(vm: vm)
                .frame(height: 350)
        }
        .navigationTitle("Native")
    }
}

struct NativeAdRepresentable: UIViewRepresentable {
    @ObservedObject var vm: NativeAdViewModel

    func makeUIView(context: Context) -> APSSPNativeAd {
        return vm.nativeAd
    }
    func updateUIView(_ uiView: APSSPNativeAd, context: Context) {}
}

class NativeAdViewModel: NSObject, ObservableObject, APSSPNativeAdDelegate {
    @Published var logs: [String] = []
    let nativeAd: APSSPNativeAd

    override init() {
        nativeAd = APSSPNativeAd(appKey: "397261446", placementId: "iOS_NATIVE", rootViewController: UIApplication.shared.rootViewController)
        super.init()
        nativeAd.delegate = self
        setupRenderer()
    }

    private func setupRenderer() {
        let nativeView = APSSPNativeAdView()
        let titleLabel = UILabel()
        titleLabel.font = .boldSystemFont(ofSize: 14)
        titleLabel.numberOfLines = 2
        let descLabel = UILabel()
        descLabel.font = .systemFont(ofSize: 12)
        descLabel.numberOfLines = 2
        let mainImage = UIImageView()
        mainImage.contentMode = .scaleAspectFill
        mainImage.clipsToBounds = true
        let iconImage = UIImageView()
        iconImage.contentMode = .scaleAspectFit
        let ctaButton = UIButton(type: .system)
        ctaButton.setTitle("Install", for: .normal)

        for v in [titleLabel, descLabel, mainImage, iconImage, ctaButton] as [UIView] {
            v.translatesAutoresizingMaskIntoConstraints = false
            nativeView.addSubview(v)
        }
        NSLayoutConstraint.activate([
            iconImage.topAnchor.constraint(equalTo: nativeView.topAnchor, constant: 8),
            iconImage.leadingAnchor.constraint(equalTo: nativeView.leadingAnchor, constant: 8),
            iconImage.widthAnchor.constraint(equalToConstant: 40),
            iconImage.heightAnchor.constraint(equalToConstant: 40),
            titleLabel.topAnchor.constraint(equalTo: nativeView.topAnchor, constant: 8),
            titleLabel.leadingAnchor.constraint(equalTo: iconImage.trailingAnchor, constant: 8),
            titleLabel.trailingAnchor.constraint(equalTo: nativeView.trailingAnchor, constant: -8),
            descLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 4),
            descLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            descLabel.trailingAnchor.constraint(equalTo: titleLabel.trailingAnchor),
            mainImage.topAnchor.constraint(equalTo: iconImage.bottomAnchor, constant: 8),
            mainImage.leadingAnchor.constraint(equalTo: nativeView.leadingAnchor),
            mainImage.trailingAnchor.constraint(equalTo: nativeView.trailingAnchor),
            mainImage.heightAnchor.constraint(equalToConstant: 180),
            ctaButton.topAnchor.constraint(equalTo: mainImage.bottomAnchor, constant: 8),
            ctaButton.trailingAnchor.constraint(equalTo: nativeView.trailingAnchor, constant: -8),
        ])

        let renderer = APSSPNativeAdRenderer()
        renderer.nativeView = nativeView
        renderer.adTitleLabel = titleLabel
        renderer.adDescLabel = descLabel
        renderer.adMainImageView = mainImage
        renderer.adAppIconView = iconImage
        renderer.adCTAButton = ctaButton
        renderer.privacyIconPosition = .topRight
        renderer.useTemplate = false
        nativeAd.bindAdPopcornRenderer(adPopcornRender: renderer)
    }

    func load() {
        logs.append("Load...")
        nativeAd.load()
    }

    func stop() {
        logs.append("Stop")
        nativeAd.stop()
    }

    func apsspNativeAdLoadSuccess(nativeAdView: APSSPNativeAd) { logs.append("✅ Load Success") }
    func apsspNativeAdLoadFail(nativeAdView: APSSPNativeAd, error: APSSPNetworkError) { logs.append("❌ Load Fail: \(error.rawValue)") }
    func apsspNativeAdImpression(nativeAd: APSSPNativeAd) { logs.append("👁 Impression") }
    func apsspNativeAdClicked(nativeAd: APSSPNativeAd) { logs.append("👆 Clicked") }
}
