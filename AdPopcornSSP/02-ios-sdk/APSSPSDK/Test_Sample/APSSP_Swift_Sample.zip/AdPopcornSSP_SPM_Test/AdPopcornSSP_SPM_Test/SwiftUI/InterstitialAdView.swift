import SwiftUI
import APSSPSDK

struct InterstitialAdView: View {
    @StateObject private var vm = InterstitialViewModel()

    var body: some View {
        VStack(spacing: 16) {
            HStack(spacing: 16) {
                Button("Load") { vm.load() }
                Button("Show") { vm.show() }
            }
            List(vm.logs, id: \.self) { Text($0).font(.caption) }
        }
        .navigationTitle("Interstitial")
    }
}

class InterstitialViewModel: NSObject, ObservableObject, APSSPInterstitialAdDelegate {
    @Published var logs: [String] = []
    private var ad: APSSPInterstitialAd?

    override init() {
        super.init()
        ad = APSSPInterstitialAd(appKey: "397261446", placementId: "iOS_INTERSTITIAL", rootViewController: UIApplication.shared.rootViewController)
        ad?.delegate = self
    }

    func load() {
        logs.append("Load...")
        ad?.load()
    }
    func show() {
        guard let vc = UIApplication.shared.rootViewController else { return }
        ad?.present(from: vc)
    }

    func apsspInterstitialAdLoadSuccess(interstitialAd: APSSPInterstitialAd) { logs.append("✅ Load Success") }
    func apsspInterstitialAdLoadFail(interstitialAd: APSSPInterstitialAd, error: APSSPNetworkError) { logs.append("❌ Load Fail: \(error.rawValue)") }
    func apsspInterstitialAdShowSuccess(interstitialAd: APSSPInterstitialAd) { logs.append("✅ Show Success") }
    func apsspInterstitialAdClosed(interstitialAd: APSSPInterstitialAd) { logs.append("🚪 Closed") }
}
