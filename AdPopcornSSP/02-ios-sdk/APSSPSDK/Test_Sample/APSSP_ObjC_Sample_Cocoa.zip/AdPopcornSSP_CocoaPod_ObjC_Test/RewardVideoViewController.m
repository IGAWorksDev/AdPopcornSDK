#import "RewardVideoViewController.h"
@import APSSPSDK;

@interface RewardVideoViewController () <APSSPRewardVideoAdDelegate>
@property (nonatomic, strong) APSSPRewardVideoAd *rewardVideoAd;
@property (nonatomic, strong) UITextView *logTextView;
@end

@implementation RewardVideoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.view.opaque = YES;
    self.title = @"RewardVideo";
    [self setupUI];
    
    self.rewardVideoAd = [[APSSPRewardVideoAd alloc] initWithAppKey:@"397261446" placementId:@"iOS_REWARD_VIDEO" rootViewController:self];
    self.rewardVideoAd.delegate = self;
}

- (void)setupUI {
    UIButton *loadBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [loadBtn setTitle:@"Load" forState:UIControlStateNormal];
    [loadBtn addTarget:self action:@selector(loadTapped) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *showBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [showBtn setTitle:@"Show" forState:UIControlStateNormal];
    [showBtn addTarget:self action:@selector(showTapped) forControlEvents:UIControlEventTouchUpInside];
    
    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[loadBtn, showBtn]];
    stack.spacing = 16;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:stack];
    
    self.logTextView = [[UITextView alloc] init];
    self.logTextView.editable = NO;
    self.logTextView.font = [UIFont systemFontOfSize:12];
    self.logTextView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.logTextView];
    
    [NSLayoutConstraint activateConstraints:@[
        [stack.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:16],
        [stack.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [self.logTextView.topAnchor constraintEqualToAnchor:stack.bottomAnchor constant:16],
        [self.logTextView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],
        [self.logTextView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],
        [self.logTextView.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-16]
    ]];
}

- (void)loadTapped {
    [self appendLog:@"Load RewardVideo..."];
    [self.rewardVideoAd load];
}

- (void)showTapped {
    [self appendLog:@"Show RewardVideo..."];
    [self.rewardVideoAd presentFrom:self];
}

- (void)appendLog:(NSString *)msg {
    NSString *text = self.logTextView.text ?: @"";
    self.logTextView.text = [NSString stringWithFormat:@"%@\n%@", text, msg];
    [self.logTextView scrollRangeToVisible:NSMakeRange(self.logTextView.text.length, 0)];
}

#pragma mark - APSSPRewardVideoAdDelegate

- (void)apsspRewardVideoAdLoadSuccessWithRewardVideoAd:(APSSPRewardVideoAd *)rewardVideoAd {
    [self appendLog:@"✅ RV Load Success"];
}

- (void)apsspRewardVideoAdLoadFailWithRewardVideoAd:(APSSPRewardVideoAd *)rewardVideoAd error:(enum APSSPNetworkError)error {
    [self appendLog:[NSString stringWithFormat:@"❌ RV Load Fail: %ld", (long)error]];
}

- (void)apsspRewardVideoAdShowSuccessWithRewardVideoAd:(APSSPRewardVideoAd *)rewardVideoAd {
    [self appendLog:@"✅ RV Show Success"];
}

- (void)apsspRewardVideoAdPlayCompletedWithRewardVideoAd:(APSSPRewardVideoAd *)rewardVideoAd adNetworkNo:(NSInteger)adNetworkNo completed:(BOOL)completed {
    [self appendLog:[NSString stringWithFormat:@"🎬 RV Completed: %@", completed ? @"YES" : @"NO"]];
}

- (void)apsspRewardVideoAdClosedWithRewardVideoAd:(APSSPRewardVideoAd *)rewardVideoAd {
    [self appendLog:@"🚪 RV Closed"];
}

@end
