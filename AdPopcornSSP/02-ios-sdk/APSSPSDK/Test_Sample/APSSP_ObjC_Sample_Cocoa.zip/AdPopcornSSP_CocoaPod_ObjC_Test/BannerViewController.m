#import "BannerViewController.h"
@import APSSPSDK;

@interface BannerViewController () <APSSPBannerViewDelegate>
@property (nonatomic, strong) APSSPBannerView *bannerView;
@property (nonatomic, strong) UITextView *logTextView;
@end

@implementation BannerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.view.opaque = YES;
    self.title = @"Banner";
    [self setupUI];
    [self setupBanner];
}

- (void)setupUI {
    UIButton *loadBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [loadBtn setTitle:@"Load Banner" forState:UIControlStateNormal];
    [loadBtn addTarget:self action:@selector(loadTapped) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *stopBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [stopBtn setTitle:@"Stop Banner" forState:UIControlStateNormal];
    [stopBtn addTarget:self action:@selector(stopTapped) forControlEvents:UIControlEventTouchUpInside];
    
    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[loadBtn, stopBtn]];
    stack.spacing = 16;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:stack];
    
    self.logTextView = [[UITextView alloc] init];
    self.logTextView.editable = NO;
    self.logTextView.font = [UIFont systemFontOfSize:12];
    self.logTextView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.logTextView];
    
    [NSLayoutConstraint activateConstraints:@[
        [stack.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:16],
        [stack.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [self.logTextView.topAnchor constraintEqualToAnchor:stack.bottomAnchor constant:16],
        [self.logTextView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],
        [self.logTextView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],
    ]];
}

- (void)setupBanner {
    self.bannerView = [[APSSPBannerView alloc] initWithAppKey:@"397261446"
                                                  placementId:@"iOS_BANNER_320x50"
                                                   bannerSize:APSSPBannerSizeBanner320x50];
    self.bannerView.delegate = self;
    self.bannerView.rootViewController = self;
    self.bannerView.adRefreshTime = 60;
    self.bannerView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.bannerView];
    
    [NSLayoutConstraint activateConstraints:@[
        [self.bannerView.topAnchor constraintEqualToAnchor:self.logTextView.bottomAnchor constant:8],
        [self.bannerView.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [self.bannerView.widthAnchor constraintEqualToConstant:320],
        [self.bannerView.heightAnchor constraintEqualToConstant:50],
        [self.bannerView.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-10]
    ]];
}

- (void)loadTapped {
    [self appendLog:@"Load Banner..."];
    [self.bannerView loadAd];
}

- (void)stopTapped {
    [self appendLog:@"Stop Banner"];
    [self.bannerView stopAd];
}

- (void)appendLog:(NSString *)msg {
    NSString *text = self.logTextView.text ?: @"";
    self.logTextView.text = [NSString stringWithFormat:@"%@\n%@", text, msg];
    [self.logTextView scrollRangeToVisible:NSMakeRange(self.logTextView.text.length, 0)];
}

#pragma mark - APSSPBannerViewDelegate

- (void)apsspBannerViewLoadSuccessWithBannerView:(APSSPBannerView *)bannerView {
    [self appendLog:@"✅ Banner Load Success"];
}

- (void)apsspBannerViewLoadFailWithBannerView:(APSSPBannerView *)bannerView error:(enum APSSPNetworkError)error {
    [self appendLog:[NSString stringWithFormat:@"❌ Banner Load Fail: %ld", (long)error]];
}

- (void)apsspBannerViewClickedWithBannerView:(APSSPBannerView *)bannerView {
    [self appendLog:@"👆 Banner Clicked"];
}

- (void)apsspBannerViewImpressionWithBannerView:(APSSPBannerView *)bannerView {
    [self appendLog:@"👁 Banner Impression"];
}

@end
