#import "MainViewController.h"
#import "BannerViewController.h"
#import "InterstitialViewController.h"
#import "InterstitialVideoViewController.h"
#import "RewardVideoViewController.h"
#import "VideoMixViewController.h"
#import "NativeViewController.h"

@interface MainViewController ()
@property (nonatomic, strong) NSArray<NSString *> *menuItems;
@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"APSSPSDK ObjC Test";
    self.menuItems = @[@"Banner", @"Interstitial", @"InterstitialVideo", @"RewardVideo", @"VideoMix", @"Native"];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.menuItems.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    cell.textLabel.text = self.menuItems[indexPath.row];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    UIViewController *vc;
    switch (indexPath.row) {
        case 0: vc = [[BannerViewController alloc] init]; break;
        case 1: vc = [[InterstitialViewController alloc] init]; break;
        case 2: vc = [[InterstitialVideoViewController alloc] init]; break;
        case 3: vc = [[RewardVideoViewController alloc] init]; break;
        case 4: vc = [[VideoMixViewController alloc] init]; break;
        case 5: vc = [[NativeViewController alloc] init]; break;
        default: return;
    }
    [self.navigationController pushViewController:vc animated:YES];
}

@end
