#import <UIKit/UIKit.h>
@interface VideoMixViewController : UIViewController
@end
