#import <UIKit/UIKit.h>
@interface InterstitialVideoViewController : UIViewController
@end
