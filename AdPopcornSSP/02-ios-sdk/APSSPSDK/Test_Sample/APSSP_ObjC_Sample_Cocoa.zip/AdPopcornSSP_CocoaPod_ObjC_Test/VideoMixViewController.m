#import "VideoMixViewController.h"
@import APSSPSDK;

@interface VideoMixViewController () <APSSPVideoMixAdDelegate>
@property (nonatomic, strong) APSSPVideoMixAd *videoMixAd;
@property (nonatomic, strong) UITextView *logTextView;
@end

@implementation VideoMixViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.view.opaque = YES;
    self.title = @"VideoMix";
    [self setupUI];
    
    self.videoMixAd = [[APSSPVideoMixAd alloc] initWithAppKey:@"397261446" placementId:@"iOS_REWARD_VIDEO" rootViewController:self];
    self.videoMixAd.delegate = self;
}

- (void)setupUI {
    UIButton *loadBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [loadBtn setTitle:@"Load" forState:UIControlStateNormal];
    [loadBtn addTarget:self action:@selector(loadTapped) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *showBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [showBtn setTitle:@"Show" forState:UIControlStateNormal];
    [showBtn addTarget:self action:@selector(showTapped) forControlEvents:UIControlEventTouchUpInside];
    
    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[loadBtn, showBtn]];
    stack.spacing = 16;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:stack];
    
    self.logTextView = [[UITextView alloc] init];
    self.logTextView.editable = NO;
    self.logTextView.font = [UIFont systemFontOfSize:12];
    self.logTextView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.logTextView];
    
    [NSLayoutConstraint activateConstraints:@[
        [stack.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:16],
        [stack.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [self.logTextView.topAnchor constraintEqualToAnchor:stack.bottomAnchor constant:16],
        [self.logTextView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],
        [self.logTextView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],
        [self.logTextView.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-16]
    ]];
}

- (void)loadTapped {
    [self appendLog:@"Load VideoMix..."];
    [self.videoMixAd load];
}

- (void)showTapped {
    [self appendLog:@"Show VideoMix..."];
    [self.videoMixAd presentFrom:self];
}

- (void)appendLog:(NSString *)msg {
    NSString *text = self.logTextView.text ?: @"";
    self.logTextView.text = [NSString stringWithFormat:@"%@\n%@", text, msg];
    [self.logTextView scrollRangeToVisible:NSMakeRange(self.logTextView.text.length, 0)];
}

#pragma mark - APSSPVideoMixAdDelegate

- (void)apsspVideoMixAdLoadSuccessWithVideoMixAd:(APSSPVideoMixAd *)videoMixAd videoMixAdType:(enum APSSPVideoMixAdType)videoMixAdType {
    [self appendLog:[NSString stringWithFormat:@"✅ VideoMix Load Success (type: %ld)", (long)videoMixAdType]];
}

- (void)apsspVideoMixAdLoadFailWithVideoMixAd:(APSSPVideoMixAd *)videoMixAd error:(enum APSSPNetworkError)error {
    [self appendLog:[NSString stringWithFormat:@"❌ VideoMix Load Fail: %ld", (long)error]];
}

- (void)apsspVideoMixAdShowSuccessWithVideoMixAd:(APSSPVideoMixAd *)videoMixAd {
    [self appendLog:@"✅ VideoMix Show Success"];
}

- (void)apsspVideoMixAdPlayCompletedWithVideoMixAd:(APSSPVideoMixAd *)videoMixAd adNetworkNo:(NSInteger)adNetworkNo completed:(BOOL)completed {
    [self appendLog:[NSString stringWithFormat:@"🎬 VideoMix Completed: %@", completed ? @"YES" : @"NO"]];
}

- (void)apsspVideoMixAdClosedWithVideoMixAd:(APSSPVideoMixAd *)videoMixAd videoMixAdType:(enum APSSPVideoMixAdType)videoMixAdType {
    [self appendLog:@"🚪 VideoMix Closed"];
}

@end
