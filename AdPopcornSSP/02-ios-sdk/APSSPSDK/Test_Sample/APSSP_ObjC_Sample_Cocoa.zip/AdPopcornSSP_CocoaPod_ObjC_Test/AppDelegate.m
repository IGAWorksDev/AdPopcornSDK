#import "AppDelegate.h"
#import "MainViewController.h"
@import APSSPSDK;

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    APSSPInitializationSettings *settings = [[APSSPInitializationSettings alloc] initWithAppKey:@"397261446"];
    [settings setLogType:APSSPLogTypeAll];
    [settings setAdInspectorEnabled:YES];
    [APSSPAds initializeSDKWith:settings completion:^{
        NSLog(@"APSSPSDK initialized");
    }];
    [APSSPAds setUSerIDWithUsn:@"test_user_id"];
    
    return YES;
}

- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}

@end
