//
//  ADOPAdapter.h
//  AdPopcornSSP
//
//  Created by mick on 2023. 11. 28..
//  Copyright (c) 2023년 adpopcorn All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>

// Using pod install / unity
//#import <AdPopcornSSP/AdPopcornSSPAdapter.h>
// else
#import "AdPopcornSSPAdapter.h"

@interface ADOPAdapter : AdPopcornSSPAdapter
{
    GADBannerView *_adBannerView;
    GADInterstitialAd *_interstitial, *_interstitialVideo;
    GADRewardedAd *_rewardedAd;
    GADAdLoader *_adLoader;
}

@end

@interface APAdopNativeAdRenderer: NSObject
@property (strong, nonatomic) GADNativeAdView *adopNativeAdView;
@end
