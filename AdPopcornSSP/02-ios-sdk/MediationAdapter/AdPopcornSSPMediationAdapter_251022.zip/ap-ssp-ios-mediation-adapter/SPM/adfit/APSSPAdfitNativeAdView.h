//
//  APSSPAdfitNativeAdView.h
//  IgaworksDevApp
//
//  Created by 김민석 on 2024/02/19.
//  Copyright © 2024 AdPopcorn. All rights reserved.
//

#ifndef APSSPAdfitNativeAdView_h
#define APSSPAdfitNativeAdView_h
#endif /* APSSPAdfitNativeAdView_h */

#import <UIKit/UIKit.h>
#import <AdFitSDK/AdFitSDK-Swift.h>

@interface APSSPAdfitNativeAdView : UIView
{
    
}
@end
