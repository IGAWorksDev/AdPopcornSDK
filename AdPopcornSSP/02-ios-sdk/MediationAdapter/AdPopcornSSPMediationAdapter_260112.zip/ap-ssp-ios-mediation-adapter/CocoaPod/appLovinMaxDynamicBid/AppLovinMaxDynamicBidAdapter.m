//
//  AppLovinMaxDynamicBidAdapter.m
//  AdPopcornSSP
//
//  Created by 김민석 on 2023/06/04.
//  Copyright © 2023 AdPopcorn. All rights reserved.
//

// compatible with AppLovin v13.0.1
#import "AppLovinMaxDynamicBidAdapter.h"

static inline NSString *SSPErrorString(SSPErrorCode code)
{
    switch (code)
    {
        case AdPopcornSSPException:
            return @"Exception";
        case AdPopcornSSPInvalidParameter:
            return @"Invalid Parameter";
        case AdPopcornSSPUnknownServerError:
            return @"Unknown Server Error";
        case AdPopcornSSPInvalidMediaKey:
            return @"Invalid Media key";
        case AdPopcornSSPInvalidPlacementId:
            return @"Invalid Placement Id";
        case AdPopcornSSPInvalidNativeAssetsConfig:
            return @"Invalid native assets config";
        case AdPopcornSSPNativePlacementDoesNotInitialized:
            return @"Native Placement Does Not Initialized";
        case AdPopcornSSPServerTimeout:
            return @"Server Timeout";
        case AdPopcornSSPLoadAdFailed:
            return @"Load Ad Failed";
        case AdPopcornSSPNoAd:
            return @"No Ad";
        case AdPopcornSSPNoInterstitialLoaded:
            return @"No Interstitial Loaded";
        case AdPopcornSSPNoRewardVideoAdLoaded:
            return @"No Reward video ad Loaded";
        case AdPopcornSSPMediationAdapterNotInitialized:
            return @"Mediation Adapter Not Initialized";
        default: {
            return @"Success";
        }
    }
}

@interface AppLovinMaxDynamicBidAdapter () <MAAdViewAdDelegate, MAAdDelegate, MARewardedAdDelegate,
    MANativeAdDelegate, MAAdRevenueDelegate>
{
    BOOL _isCurrentRunningAdapter;
    NSTimer *networkScheduleTimer;
    NSInteger adNetworkNo;
    APAppLovinMaxNativeAdRenderer *appLovinMaxNativeAdRenderer;
    BOOL _isMute;
    NSString *priceParam;
    NSString *disableAutoRetriesParam;
    VideoMixAdType videoMixAdType;
}
@end

@implementation AppLovinMaxDynamicBidAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;
@synthesize viewController = _viewController;
@synthesize bannerView = _bannerView;
@synthesize adpopcornSSPNativeAd = _adpopcornSSPNativeAd;

- (instancetype)init
{
    self = [super init];
    if (self){}
    adNetworkNo = 23;
    priceParam = @"jC7Fp";
    disableAutoRetriesParam = @"disable_auto_retries";
    return self;
}

- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(AdPopcornSSPBannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = SSPAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPAdInterstitialType;
}

- (void)setRewardVideoViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPRewardVideoAdType;
}

- (void)setInterstitialVideoViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPInterstitialVideoAdType;
}

- (void)setVideoMixAdViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPVideoMixAdType;
}

- (void)setNativeAdViewController:(UIViewController *)viewController nativeAdRenderer:(id)nativeAdRenderer rootNativeAdView:(AdPopcornSSPNativeAd *)adpopcornSSPNativeAd
{
    _viewController = viewController;
    _adType = SSPNativeAdType;
    if([nativeAdRenderer isKindOfClass:[APAppLovinMaxNativeAdRenderer class]])
        appLovinMaxNativeAdRenderer = nativeAdRenderer;
    _adpopcornSSPNativeAd = adpopcornSSPNativeAd;
}

- (BOOL)isSupportInterstitialAd
{
    return YES;
}

- (BOOL)isSupportRewardVideoAd
{
    return YES;
}

- (BOOL)isSupportNativeAd
{
    return YES;
}

- (BOOL)isSupportInterstitialVideoAd
{
    return YES;
}

- (BOOL)isSupportVideoMixAd
{
    return YES;
}

- (void)setMute:(bool)mute
{
    _isMute = mute;
}

- (void)loadAd
{
    if (_adType == SSPAdBannerType) {
        [self setupBanner:@"Banner"];
    }
    else if (_adType == SSPNativeAdType) {
        [self setupNativeAd:@"Native"];
    }
    else if (_adType == SSPRewardVideoAdType) {
        [self setupRewardVideo:@"RewardVideo"];
    }
    else if(_adType == SSPInterstitialVideoAdType) {
        [self setupInterstitialVideo:@"InterstitialVideo"];
    }
    else if(_adType == SSPAdInterstitialType) {
        [self setupInterstitial:@"Interstitial"];
    }
    else if (_adType == SSPVideoMixAdType) {
        NSNumber *campaignType = [_integrationKey valueForKey:@"CampaignType"];
        NSInteger campaignValue = [campaignType integerValue];
        videoMixAdType = SSPVideoMixAdTypeFromInteger(campaignValue);
        
        switch (videoMixAdType) {
            case VideoMix_InterstitialType:
                [self setupInterstitial:@"VideoMix_Interstitial"];
                break;
                
            case VideoMix_InterstitialVideoType:
                [self setupInterstitialVideo:@"VideoMix_InterstitialVIdeo"];
                break;
                
            case VideoMix_RewardVideoType:
                [self setupRewardVideo:@"VideoMix_RewardVideo"];
                break;
        }
    }
}

- (MANativeAdView *)createNativeAdView
{
    MANativeAdView *nativeAdView = (MANativeAdView*)appLovinMaxNativeAdRenderer.appLovinNativeAdView;
    MANativeAdViewBinder *binder = [[MANativeAdViewBinder alloc] initWithBuilderBlock:^(MANativeAdViewBinderBuilder *builder) {
        /*builder.titleLabelTag = nativeAdView.titleLabel.tag;
         builder.bodyLabelTag = nativeAdView.bodyLabel.tag;
         builder.callToActionButtonTag = nativeAdView.callToActionButton.tag;
         builder.iconImageViewTag = nativeAdView.iconImageView.tag;
         builder.mediaContentViewTag = nativeAdView.mediaContentView.tag;
         builder.advertiserLabelTag = nativeAdView.advertiserLabel.tag;
         builder.optionsContentViewTag = nativeAdView.optionsContentView.tag;*/
        builder.titleLabelTag = 1001;
        builder.advertiserLabelTag = 1002;
        builder.bodyLabelTag = 1003;
        builder.iconImageViewTag = 1004;
        builder.optionsContentViewTag = 1005;
        builder.mediaContentViewTag = 1006;
        builder.callToActionButtonTag = 1007;
    }];
    [nativeAdView bindViewsWithAdViewBinder: binder];
    return nativeAdView;
}

-(void)setupBanner:(NSString*) typeName {
    if (_integrationKey != nil)
    {
        NSString *unitId = [_integrationKey valueForKey:@"AppLovinMaxUnitId"];
        NSString *price = [_integrationKey valueForKey:@"price"];
        
        NSLog(@"AppLovinMaxDynamicBidAdapter SSPAdBannerType unitId : %@", unitId);
        if(_size.width == 320.0f && _size.height == 50.0f)
        {
            maxBannerView = [[MAAdView alloc] initWithAdUnitIdentifier: unitId];
            maxBannerView.delegate = self;
            
            CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);
            CGFloat height = 50;
            
            maxBannerView.frame = CGRectMake(0, 0, width, height);
        }
        else if(_size.width == 300.0f && _size.height == 250.0f)
        {
            maxBannerView = [[MAAdView alloc] initWithAdUnitIdentifier: unitId adFormat:MAAdFormat.mrec];
            maxBannerView.delegate = self;
            
            CGFloat width = 300;
            CGFloat height = 250;
            
            // Center the MREC
            CGFloat x = _bannerView.center.x - 150;
            maxBannerView.frame = CGRectMake(x, 0, width, height);
        }
        else
        {
            NSLog(@"%@ : AppLovinMaxDynamicBidAdapter can not load 320x100", self);
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
            }
            
            [self closeAd];
            return;
        }
        [maxBannerView setExtraParameterForKey:disableAutoRetriesParam value:@"true"];
        [maxBannerView setExtraParameterForKey:priceParam value:price];
        [_bannerView addSubview: maxBannerView];
        
        // Load the ad
        [maxBannerView loadAd];
    }
    else
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
        }
        
        [self closeAd];
    }
}

-(void)setupNativeAd:(NSString*) typeName {
    if (_integrationKey != nil)
    {
        if(appLovinMaxNativeAdRenderer != nil && appLovinMaxNativeAdRenderer.appLovinNativeAdView != nil)
        {
            NSString *unitId = [_integrationKey valueForKey:@"AppLovinMaxUnitId"];
            NSString *price = [_integrationKey valueForKey:@"price"];
            
            NSLog(@"AppLovinMaxDynamicBidAdapter SSPNativeAdType unitId : %@", unitId);
            nativeAdLoader = [[MANativeAdLoader alloc] initWithAdUnitIdentifier: unitId];
            nativeAdLoader.nativeAdDelegate = self;
            nativeAdLoader.revenueDelegate = self;
            
            [nativeAdLoader setExtraParameterForKey:disableAutoRetriesParam value:@"true"];
            [nativeAdLoader setExtraParameterForKey:priceParam value:price];
            [nativeAdLoader loadAdIntoAdView:[self createNativeAdView]];
        }
        else
        {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
                [self closeAd];
            }
        }
    }
    else
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
        }
        [self closeAd];
    }
}

-(void)setupInterstitial:(NSString*) typeName {
    if (_integrationKey != nil)
    {
        NSString *unitId = [_integrationKey valueForKey:@"AppLovinMaxUnitId"];
        
        NSString *price = [_integrationKey valueForKey:@"price"];
        
        NSLog(@"AppLovinMaxDynamicBidAdapter SSPAdInterstitialType unitId : %@", unitId);
        maxInterstitialAd = [[MAInterstitialAd alloc] initWithAdUnitIdentifier:unitId];
        maxInterstitialAd.delegate = self;
        
        [maxInterstitialAd setExtraParameterForKey:disableAutoRetriesParam value:@"true"];
        [maxInterstitialAd setExtraParameterForKey:priceParam value:price];
        [maxInterstitialAd loadAd];
    }
    else
    {
        if(_adType == SSPVideoMixAdType) {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
            {
                [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self videoMixType:videoMixAdType];
            }
        } else {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitialAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
        }
        
        [self closeAd];
    }
}
-(void)setupInterstitialVideo:(NSString*) typeName {
    if(networkScheduleTimer == nil)
        networkScheduleTimer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(networkScheduleTimeoutHandler:) userInfo:nil repeats:NO];
    
    _isCurrentRunningAdapter = YES;
    if (_integrationKey != nil)
    {
        NSString *unitId = [_integrationKey valueForKey:@"AppLovinMaxUnitId"];
        NSString *price = [_integrationKey valueForKey:@"price"];
        
        NSLog(@"AppLovinMaxDynamicBidAdapter SSPAdInterstitialVideoType unitId : %@", unitId);
        maxInterstitialVideoAd = [[MAInterstitialAd alloc] initWithAdUnitIdentifier:unitId];
        maxInterstitialVideoAd.delegate = self;
        
        [maxInterstitialVideoAd setExtraParameterForKey:disableAutoRetriesParam value:@"true"];
        [maxInterstitialVideoAd setExtraParameterForKey:priceParam value:price];
        [maxInterstitialVideoAd loadAd];
    }
    else
    {
        if(_adType == SSPVideoMixAdType) {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
            {
                [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self videoMixType:videoMixAdType];
            }
        } else {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
        }
        
        [self closeAd];
    }
}
-(void)setupRewardVideo:(NSString*) typeName {
    if(networkScheduleTimer == nil)
    {
        networkScheduleTimer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(networkScheduleTimeoutHandler:) userInfo:nil repeats:NO];
    }
    else{
        [self invalidateNetworkTimer];
        networkScheduleTimer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(networkScheduleTimeoutHandler:) userInfo:nil repeats:NO];
    }
    
    _isCurrentRunningAdapter = YES;
    if (_integrationKey != nil)
    {
        NSString *unitId = [_integrationKey valueForKey:@"AppLovinMaxUnitId"];
        NSString *price = [_integrationKey valueForKey:@"price"];
        NSLog(@"AppLovinMaxDynamicBidAdapter SSPRewardVideoAdType unitId : %@", unitId);
        
        maxRewardVideoAd= [MARewardedAd sharedWithAdUnitIdentifier: unitId];
        maxRewardVideoAd.delegate = self;
        
        [maxRewardVideoAd setExtraParameterForKey:disableAutoRetriesParam value:@"true"];
        [maxRewardVideoAd setExtraParameterForKey:priceParam value:price];
        [maxRewardVideoAd loadAd];
    }
    else
    {
        if(_adType == SSPVideoMixAdType) {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
            {
                [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self videoMixType:videoMixAdType];
            }
        } else {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
        }
        [self closeAd];
    }
}

- (void)showAd
{
    NSLog(@"AppLovinMaxDynamicBidAdapter : showAd %d", _adType);
    if (_adType == SSPAdInterstitialType)
    {
        if ( [maxInterstitialAd isReady] )
        {
            [maxInterstitialAd showAd];
        }
        else
        {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdShowFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitialAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoInterstitialLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoInterstitialLoaded)}] adapter:self];
            }
        }
    }
    else if (_adType == SSPRewardVideoAdType)
    {
        if(_isMute)
            [ALSdk shared].settings.muted = YES;
        if ([maxRewardVideoAd isReady] )
        {
            [maxRewardVideoAd showAd];
        }
        else
        {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoRewardVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoRewardVideoAdLoaded)}] adapter:self];
            }
        }
    }
    else if (_adType == SSPInterstitialVideoAdType)
    {
        if(_isMute)
            [ALSdk shared].settings.muted = YES;
        if ([maxInterstitialVideoAd isReady])
        {
            [maxInterstitialVideoAd showAd];
        }
        else
        {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdShowFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitialVideoAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoInterstitialVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoInterstitialVideoAdLoaded)}] adapter:self];
            }
        }
    }
    else if (_adType == SSPVideoMixAdType) {
        switch (videoMixAdType) {
            case VideoMix_InterstitialType:
                if ( [maxInterstitialAd isReady] )
                {
                    [maxInterstitialAd showAd];
                }
                else
                {
                    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowFailError:adapter:videoMixType:)])
                    {
                        [_delegate AdPopcornSSPAdapterVideoMixAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoInterstitialLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoInterstitialLoaded)}] adapter:self videoMixType: videoMixAdType];
                    }
                }
                break;
                
            case VideoMix_InterstitialVideoType:
                if(_isMute)
                    [ALSdk shared].settings.muted = YES;
                if ([maxInterstitialVideoAd isReady])
                {
                    [maxInterstitialVideoAd showAd];
                }
                else
                {
                    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowFailError:adapter:videoMixType:)])
                    {
                        [_delegate AdPopcornSSPAdapterVideoMixAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoInterstitialLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoInterstitialLoaded)}] adapter:self videoMixType: videoMixAdType];
                    }
                }
                break;
                
            case VideoMix_RewardVideoType:
                if(_isMute)
                    [ALSdk shared].settings.muted = YES;
                if ([maxRewardVideoAd isReady] )
                {
                    [maxRewardVideoAd showAd];
                }
                else
                {
                    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowFailError:adapter:videoMixType:)])
                    {
                        [_delegate AdPopcornSSPAdapterVideoMixAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoInterstitialLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoInterstitialLoaded)}] adapter:self videoMixType: videoMixAdType];
                    }
                }
                break;
        }
    }
}

- (void)closeAd
{
    NSLog(@"AppLovinMaxDynamicBidAdapter : closeAd : %d", _adType);
   if (_adType == SSPRewardVideoAdType)
    {
        _isCurrentRunningAdapter = NO;
        [self invalidateNetworkTimer];
    }
    else if(_adType == SSPInterstitialVideoAdType)
    {
        _isCurrentRunningAdapter = NO;
        [self invalidateNetworkTimer];
    } else if(_adType == SSPVideoMixAdType){
        switch (videoMixAdType) {
            case VideoMix_InterstitialType:
                break;
                
            case VideoMix_InterstitialVideoType:
                _isCurrentRunningAdapter = NO;
                [self invalidateNetworkTimer];
                break;
                
            case VideoMix_RewardVideoType:
                _isCurrentRunningAdapter = NO;
                [self invalidateNetworkTimer];
                break;
        }
    }
}

-(void)networkScheduleTimeoutHandler:(NSTimer*) timer
{
    if(_adType == SSPRewardVideoAdType)
    {
        NSLog(@"AppLovinMaxDynamicBidAdapter rv load timeout, but not fired");
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
        }
    }
    else if(_adType == SSPInterstitialVideoAdType)
    {
        NSLog(@"AppLovinMaxDynamicBidAdapter iv load timeout, but not fired");
        /*if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
        }*/
    } else if (_adType == SSPVideoMixAdType) {
            switch (videoMixAdType) {
                case VideoMix_InterstitialType:
                    break;
                    
                case VideoMix_InterstitialVideoType:
                    NSLog(@"AppLovinMaxDynamicBidAdapter VideoMix_InterstitialVideo load timeout, but not fired");
                    break;
                    
                case VideoMix_RewardVideoType:
                    NSLog(@"AppLovinMaxDynamicBidAdapter  VideoMix_RewardVideo load timeout, but not fired");
                    break;
            }
    }
    [self invalidateNetworkTimer];
}

-(void)invalidateNetworkTimer
{
    if(networkScheduleTimer != nil)
        [networkScheduleTimer invalidate];
}

#pragma mark - MAAdDelegate Protocol
- (void)didLoadAd:(MAAd *)ad
{
    NSLog(@"AppLovinMaxDynamicBidAdapter : didLoadAd %d", _adType);
    [self invalidateNetworkTimer];
    if (_adType == SSPAdBannerType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterBannerViewLoadSuccess:self];
        }
    }
    else if (_adType == SSPAdInterstitialType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialAdLoadSuccess:self];
        }
    }
    else if (_adType == SSPRewardVideoAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadSuccess:self];
        }
    }
    else if (_adType == SSPInterstitialVideoAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:self];
        }
    }
    else if (_adType == SSPVideoMixAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadSuccess:videoMixType:)])
        {
            [_delegate AdPopcornSSPAdapterVideoMixAdLoadSuccess:self videoMixType:videoMixAdType];
        }
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    NSLog(@"AppLovinMaxDynamicBidAdapter : didFailToLoadAdWithError %d, error : %@", _adType, error);
    if (_adType == SSPAdBannerType)
    {
        
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterBannerViewLoadFailError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:error.code userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
        }
        
        [self closeAd];
    }
    else if (_adType == SSPAdInterstitialType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialAdLoadFailError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:error.code userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
        }
        [self closeAd];
    }
    else if (_adType == SSPRewardVideoAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:error.code userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
        }
        [self closeAd];
    }
    else if (_adType == SSPInterstitialVideoAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:error.code userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
        }
        [self closeAd];
    }
    else if (_adType == SSPVideoMixAdType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdLoadFailError:adapter:videoMixType:)])
        {
            [_delegate AdPopcornSSPAdapterVideoMixAdLoadFailError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:error.code userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self videoMixType:videoMixAdType];
        }
        [self closeAd];
    }
}

- (void)didClickAd:(MAAd *)ad
{
    NSLog(@"AppLovinMaxDynamicBidAdapter didClickAd : %@", ad);
    if (_adType == SSPAdBannerType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewClicked:)])
        {
            [_delegate AdPopcornSSPAdapterBannerViewClicked:self];
        }
    }
    else if(_adType == SSPAdInterstitialType){
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdClicked:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialAdClicked:self];
        }
    }
    else if(_adType == SSPVideoMixAdType){
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdClicked:videoMixType:)])
        {
            [_delegate AdPopcornSSPAdapterVideoMixAdClicked:self videoMixType:videoMixAdType];
        }
    }
}

- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error
{
    NSLog(@"AppLovinMaxDynamicBidAdapter didFailToDisplayAd : %@", ad);
    if (_adType == SSPAdInterstitialType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdShowFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoInterstitialLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoInterstitialLoaded)}] adapter:self];
        }
    }
    else if (_adType == SSPRewardVideoAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoRewardVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoRewardVideoAdLoaded)}] adapter:self];
        }
    }
    else if (_adType == SSPInterstitialVideoAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdShowFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoInterstitialVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoInterstitialVideoAdLoaded)}] adapter:self];
        }
    }
    else if (_adType == SSPVideoMixAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowFailError:adapter:videoMixType:)])
        {
            [_delegate AdPopcornSSPAdapterVideoMixAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoInterstitialVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoInterstitialVideoAdLoaded)}] adapter:self videoMixType:videoMixAdType];
        }
    }
}

- (void)didDisplayAd:(MAAd *)ad
{
    NSLog(@"AppLovinMaxDynamicBidAdapter didDisplayAd : %@", ad);
    if(_adType == SSPAdInterstitialType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdShowSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialAdShowSuccess:self];
        }
    }
    else if(_adType == SSPRewardVideoAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdShowSuccess:self];
        }
    }
    else if(_adType == SSPInterstitialVideoAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdShowSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdShowSuccess:self];
        }
    }
    else if(_adType == SSPVideoMixAdType)
    {
        if(videoMixAdType == VideoMix_InterstitialType) {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowSuccess:videoMixType:)])
            {
                [_delegate AdPopcornSSPAdapterVideoMixAdShowSuccess:self videoMixType:videoMixAdType];
            }
        } else {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdShowSuccess:videoMixType:)])
            {
                [_delegate AdPopcornSSPAdapterVideoMixAdShowSuccess:self videoMixType:videoMixAdType];
            }
        }
    }
}
- (void)didHideAd:(MAAd *)ad
{
    NSLog(@"AppLovinMaxDynamicBidAdapter didHideAd : %@", ad);
    if(_adType == SSPAdInterstitialType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdClosed:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialAdClosed:self];
        }
    }
    else if(_adType == SSPRewardVideoAdType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdClose:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdClose:self];
        }
    }
    else if(_adType == SSPInterstitialVideoAdType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdClose:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdClose:self];
        }
    }
    else if(_adType == SSPVideoMixAdType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterVideoMixAdClose:videoMixType:)])
        {
            [_delegate AdPopcornSSPAdapterVideoMixAdClose:self videoMixType:videoMixAdType];
        }
    }
}

#pragma mark - MARewardedAdDelegate Protocol
- (void)didRewardUserForAd:(MAAd *)ad withReward:(MAReward *)reward
{
    // Rewarded ad was displayed and user should receive the reward
    NSLog(@"AppLovinMaxDynamicBidAdapter didRewardUserForAd %@, reward %@", ad, reward);
    if(_adType == SSPRewardVideoAdType){
        if ([_delegate respondsToSelector:@selector(onCompleteTrackingEvent:isCompleted:)])
        {
            [_delegate onCompleteTrackingEvent:adNetworkNo isCompleted:YES];
        }
    }
    _isCurrentRunningAdapter = NO;
}

#pragma mark - MANativeAdDelegate Protocol
- (void)didLoadNativeAd:(nullable MANativeAdView *)nativeAdView forAd:(MAAd *)ad
{
    NSLog(@"AppLovinMaxDynamicBidAdapter didLoadNativeAd");
    if (loadedNativeAd)
    {
        [nativeAdLoader destroyAd:loadedNativeAd];
    }

    // Save ad for cleanup.
    loadedNativeAd = ad;

    [_adpopcornSSPNativeAd addSubview:nativeAdView];
    
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadSuccess:)])
    {
        [_delegate AdPopcornSSPAdapterNativeAdLoadSuccess:self];
    }
}

- (void)didFailToLoadNativeAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    NSLog(@"AppLovinMaxDynamicBidAdapter didFailToLoadNativeAdForAdUnitIdentifier");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdLoadFailError:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterNativeAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
    }
}

- (void)didClickNativeAd:(MAAd *)ad;
{
    NSLog(@"AppLovinMaxDynamicBidAdapter didClickNativeAd");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterNativeAdClicked:)])
    {
        [_delegate AdPopcornSSPAdapterNativeAdClicked:self];
    }
}

- (void)didExpireNativeAd:(MAAd *)ad
{
    NSLog(@"AppLovinMaxDynamicBidAdapter didExpireNativeAd");
}

@end

@implementation APAppLovinMaxNativeAdRenderer
{
    
}

- (instancetype)init
{
    self = [super init];
    if(self)
    {
    }
    return self;
}
@end
