//
//  TapJoyAdapter.m
//  AdPopcornSSP
//
//  Created by mick on 2020. 10. 28..
//  Copyright (c) 2020년 igaworks All rights reserved.
//

// compatible with TapJoy v13.2.1
#import "TapJoyAdapter.h"

static inline NSString *SSPErrorString(SSPErrorCode code)
{
    switch (code)
    {
        case AdPopcornSSPException:
            return @"Exception";
        case AdPopcornSSPInvalidParameter:
            return @"Invalid Parameter";
        case AdPopcornSSPUnknownServerError:
            return @"Unknown Server Error";
        case AdPopcornSSPInvalidMediaKey:
            return @"Invalid Media key";
        case AdPopcornSSPInvalidPlacementId:
            return @"Invalid Placement Id";
        case AdPopcornSSPInvalidNativeAssetsConfig:
            return @"Invalid native assets config";
        case AdPopcornSSPNativePlacementDoesNotInitialized:
            return @"Native Placement Does Not Initialized";
        case AdPopcornSSPServerTimeout:
            return @"Server Timeout";
        case AdPopcornSSPLoadAdFailed:
            return @"Load Ad Failed";
        case AdPopcornSSPNoAd:
            return @"No Ad";
        case AdPopcornSSPNoInterstitialLoaded:
            return @"No Interstitial Loaded";
        case AdPopcornSSPNoRewardVideoAdLoaded:
            return @"No Reward video ad Loaded";
        case AdPopcornSSPMediationAdapterNotInitialized:
            return @"Mediation Adapter Not Initialized";
        case AdPopcornSSPNoInterstitialVideoAdLoaded:
            return @"No Interstitial video ad Loaded";
        default: {
            return @"Success";
        }
    }
}

@interface TapJoyAdapter () <TJPlacementDelegate, TJPlacementVideoDelegate>
{
    BOOL _isCurrentRunningAdapter;
    NSString *tapJoySDKKey, *tapJoyRVPlacementId, *tapJoyIVPlacementId;
    NSTimer *networkScheduleTimer;
    NSInteger adNetworkNo;
    NSMutableArray *_impTrackersListArray, *_clickTrackersListArray;
    NSString *_biddingData;
    BOOL _isInAppBidding;
}

@end

@implementation TapJoyAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;
@synthesize viewController = _viewController;
@synthesize bannerView = _bannerView;

- (instancetype)init
{
    self = [super init];
    if (self){}
    adNetworkNo = 17;
    _isInAppBidding = NO;
    return self;
}

- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(AdPopcornSSPBannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = SSPAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPAdInterstitialType;
}

- (void)setRewardVideoViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPRewardVideoAdType;
}

- (void)setInterstitialVideoViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPInterstitialVideoAdType;
}

- (BOOL)isSupportInterstitialAd
{
    return NO;
}

- (BOOL)isSupportRewardVideoAd
{
    return YES;
}

- (BOOL)isSupportInterstitialVideoAd
{
    return YES;
}

- (void)setBiddingData:(NSString *)biddingData impressionList:(NSMutableArray *)impTrackersListArray clickList: (NSMutableArray *)clickTrackersListArray
{
    _biddingData = biddingData;
    _impTrackersListArray = impTrackersListArray;
    _clickTrackersListArray =  clickTrackersListArray;
}

- (void)setInAppBiddingMode:(bool)isInAppBiddingMode
{
    _isInAppBidding = isInAppBiddingMode;
    NSLog(@"TapJoyAdapter setInAppBiddingMode : %d", _isInAppBidding);
}

- (void)loadAd
{
    if(networkScheduleTimer == nil)
    {
        networkScheduleTimer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(networkScheduleTimeoutHandler:) userInfo:nil repeats:NO];
    }
    else{
        [self invalidateNetworkTimer];
        networkScheduleTimer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(networkScheduleTimeoutHandler:) userInfo:nil repeats:NO];
    }
    
    if (_adType == SSPRewardVideoAdType)
    {
        NSLog(@"TapJoyAdapter %@ : SSPRewardVideoAdType loadAd", self);
        _isCurrentRunningAdapter = YES;
        if (_integrationKey != nil)
        {
            if(_isInAppBidding)
            {
                tapJoyRVPlacementId = [_integrationKey valueForKey:@"tapjoy_placement_id"];
                TJPlacement *p = [TJPlacement placementWithName:tapJoyRVPlacementId mediationAgent:@"adpopcorn_ssp" mediationId:nil delegate:self];
                p.adapterVersion = [[AdPopcornSSP getSDKVersion] stringByReplacingOccurrencesOfString:@"in" withString:@""];

                // tjData = ext.tj_data, which is a json string
                NSData* data = [_biddingData dataUsingEncoding:NSUTF8StringEncoding];
                NSDictionary *responseData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];

                NSDictionary *auctionData = @{
                  TJ_AUCTION_DATA: responseData[TJ_AUCTION_DATA],
                  TJ_AUCTION_ID: responseData[TJ_AUCTION_ID]};

                [p setAuctionData:auctionData];
                [p requestContent];
            }
            else
            {
                tapJoySDKKey = [_integrationKey valueForKey:@"TapJoySDKKey"];
                tapJoyRVPlacementId = [_integrationKey valueForKey:@"TapJoyPlacementId"];
                if([Tapjoy isConnected])
                {
                    NSLog(@"TapJoyAdapter is already connected");
                    TJPlacement *p = [TJPlacement placementWithName:tapJoyRVPlacementId delegate:self];
                    if([p isContentReady])
                    {
                        NSLog(@"TapJoyAdapter isContentReady true");
                        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadSuccess:)])
                        {
                            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadSuccess:self];
                        }
                        [self invalidateNetworkTimer];
                    }
                    else
                    {
                        NSLog(@"TapJoyAdapter isContentReady false");
                        [p requestContent];
                    }
                }
                else
                {
                    NSLog(@"TapJoyAdapter try connect");
                    [Tapjoy connect:tapJoySDKKey];
                    TJPlacement *p = [TJPlacement placementWithName:tapJoyRVPlacementId delegate:self];
                    [p requestContent];
                }
            }
        }
        else
        {
            NSLog(@"TapJoyAdapter rv no integrationKey");
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
            [self invalidateNetworkTimer];
        }
    }
    else if(_adType == SSPInterstitialVideoAdType)
    {
        NSLog(@"TapJoyAdapter %@ : SSPInterstitialVideoAdType loadAd", self);
        _isCurrentRunningAdapter = YES;
        if (_integrationKey != nil)
        {
            if(_isInAppBidding)
            {
                tapJoyIVPlacementId = [_integrationKey valueForKey:@"tapjoy_placement_id"];
                TJPlacement *p = [TJPlacement placementWithName:tapJoyIVPlacementId mediationAgent:@"adpopcorn_ssp" mediationId:nil delegate:self];
                p.adapterVersion = [[AdPopcornSSP getSDKVersion] stringByReplacingOccurrencesOfString:@"in" withString:@""];

                // tjData = ext.tj_data, which is a json string
                NSData* data = [_biddingData dataUsingEncoding:NSUTF8StringEncoding];
                NSDictionary *responseData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];

                NSDictionary *auctionData = @{
                  TJ_AUCTION_DATA: responseData[TJ_AUCTION_DATA],
                  TJ_AUCTION_ID: responseData[TJ_AUCTION_ID]};

                [p setAuctionData:auctionData];
                [p requestContent];
            }
            else
            {
                tapJoySDKKey = [_integrationKey valueForKey:@"TapJoySDKKey"];
                tapJoyIVPlacementId = [_integrationKey valueForKey:@"TapJoyPlacementId"];
                    
                if([Tapjoy isConnected])
                {
                    NSLog(@"TapJoyAdapter is already connected");
                    TJPlacement *p = [TJPlacement placementWithName:tapJoyIVPlacementId delegate:self];
                    if([p isContentReady])
                    {
                        NSLog(@"TapJoyAdapter isContentReady true");
                        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:)])
                        {
                            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:self];
                        }
                        [self invalidateNetworkTimer];
                    }
                    else
                    {
                        NSLog(@"TapJoyAdapter isContentReady false");
                        [p requestContent];
                    }
                }
                else
                {
                    NSLog(@"TapJoyAdapter try connect");
                    [Tapjoy connect:tapJoySDKKey];
                    TJPlacement *p = [TJPlacement placementWithName:tapJoyIVPlacementId delegate:self];
                    [p requestContent];
                }
            }
        }
        else
        {
            NSLog(@"TapJoyAdapter rv no integrationKey");
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
            [self invalidateNetworkTimer];
        }
    }
}

- (void)showAd
{
    NSLog(@"TapJoyAdapter : showAd");
    if (_adType == SSPRewardVideoAdType)
    {
        TJPlacement *p;
        if(_isInAppBidding)
        {
            p = [TJPlacement placementWithName:tapJoyRVPlacementId mediationAgent:@"adpopcorn_ssp" mediationId:nil delegate:self];
        }
        else
        {
            p = [TJPlacement placementWithName:tapJoyRVPlacementId delegate:self];
        }
        if(p.isContentReady) {
           [p showContentWithViewController: _viewController];
        }
        else {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterRewardVideoAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoRewardVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoRewardVideoAdLoaded)}] adapter:self];
            }
        }
    }
    else if (_adType == SSPInterstitialVideoAdType)
    {
        TJPlacement *p;
        if(_isInAppBidding)
        {
            p = [TJPlacement placementWithName:tapJoyIVPlacementId mediationAgent:@"adpopcorn_ssp" mediationId:nil delegate:self];
        }
        else
        {
            p = [TJPlacement placementWithName:tapJoyIVPlacementId delegate:self];
        }
        if(p.isContentReady) {
           [p showContentWithViewController: _viewController];
        }
        else {
            if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdShowFailError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitialVideoAdShowFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPNoRewardVideoAdLoaded userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPNoRewardVideoAdLoaded)}] adapter:self];
            }
        }
    }
}

- (void)closeAd
{
    NSLog(@"TapJoyAdapter closeAd");
    _isCurrentRunningAdapter = NO;
}

- (void)loadRequest
{
    // Not used any more
}

-(void)networkScheduleTimeoutHandler:(NSTimer*) timer
{
    if(_adType == SSPRewardVideoAdType)
    {
        NSLog(@"TapJoyAdapter rv load timeout");
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
        }
    }
    else if(_adType == SSPInterstitialVideoAdType)
    {
        NSLog(@"TapJoyAdapter iv load timeout");
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
        }
    }
    [self invalidateNetworkTimer];
}

-(void)invalidateNetworkTimer
{
    if(networkScheduleTimer != nil)
        [networkScheduleTimer invalidate];
}

#pragma mark TJPlacementDelegate
// Called when the content request returns from Tapjoy's servers. Does not necessarily mean that content is available.
- (void)requestDidSucceed:(TJPlacement*)placement
{
    NSLog(@"TapJoyAdapter requestDidSucceed");
}

- (void)requestDidFail:(TJPlacement*)placement error:(NSError*)error
{
    NSLog(@"TapJoyAdapter requestDidFail");
    if(_adType == SSPRewardVideoAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
        }
    }
    else if(_adType == SSPInterstitialVideoAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:adapter:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadFailError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
        }
    }
    
    [self invalidateNetworkTimer];
}

//This is called when the content is actually available to display.
- (void)contentIsReady:(TJPlacement*)placement
{
    NSLog(@"TapJoyAdapter contentIsReady");
    if(_adType == SSPRewardVideoAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdLoadSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdLoadSuccess:self];
        }
    }
    else if(_adType == SSPInterstitialVideoAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdLoadSuccess:self];
        }
    }
    
    [self invalidateNetworkTimer];
}

- (void)contentDidAppear:(TJPlacement*)placement
{
    NSLog(@"TapJoyAdapter contentDidAppear");
    for(NSString *url in _impTrackersListArray)
    {
        if ([_delegate respondsToSelector:@selector(impClickTracking:)])
        {
            [_delegate impClickTracking:url];
        }
    }
    if(_adType == SSPRewardVideoAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdShowSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdShowSuccess:self];
        }
    }
    else if(_adType == SSPInterstitialVideoAdType)
    {
        if (_isCurrentRunningAdapter && [_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdShowSuccess:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdShowSuccess:self];
        }
    }
    if(placement != nil)
        placement.videoDelegate = self;
}

- (void)contentDidDisappear:(TJPlacement*)placement
{
    NSLog(@"TapJoyAdapter contentDidDisappear");
    if(_adType == SSPRewardVideoAdType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterRewardVideoAdClose:)])
        {
            [_delegate AdPopcornSSPAdapterRewardVideoAdClose:self];
        }
    }
    else if(_adType == SSPInterstitialVideoAdType)
    {
        if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialVideoAdClose:)])
        {
            [_delegate AdPopcornSSPAdapterInterstitialVideoAdClose:self];
        }
    }

    _isCurrentRunningAdapter = NO;
}

- (void)didClick:(TJPlacement *)placement
{
    NSLog(@"TapJoyAdapter didClick");
    for(NSString *url in _clickTrackersListArray)
    {
        if ([_delegate respondsToSelector:@selector(impClickTracking:)])
        {
            [_delegate impClickTracking:url];
        }
    }
}

#pragma mark TJPlacementVideoDelegate
- (void)videoDidStart:(TJPlacement*)placement
{
    NSLog(@"TapJoyAdapter videoDidStart");
}

- (void)videoDidComplete:(TJPlacement*)placement
{
    NSLog(@"TapJoyAdapter videoDidComplete");
    if(_adType == SSPRewardVideoAdType)
    {
        if ([_delegate respondsToSelector:@selector(onCompleteTrackingEvent:isCompleted:)])
        {
            [_delegate onCompleteTrackingEvent:adNetworkNo isCompleted:YES];
        }
    }
}

- (void)videoDidFail:(TJPlacement*)placement error:(NSString*)errorMsg
{
    NSLog(@"TapJoyAdapter videoDidFail");
}

- (NSString *)getBiddingToken
{
    return [Tapjoy getUserToken];
}
@end
