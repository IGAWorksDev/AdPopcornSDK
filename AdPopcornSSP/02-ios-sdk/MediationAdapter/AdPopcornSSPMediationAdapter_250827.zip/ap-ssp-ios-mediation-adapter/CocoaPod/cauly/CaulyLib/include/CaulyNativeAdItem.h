//
//  CaulyNativeAdItem.h
//  Cauly
//
//  Created by Neil Kwon on 10/14/15.
//  Copyright © 2015 Cauly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CaulyNativeAdItem : NSObject

@property NSString* nativeAdJSONString;
@property int index;

@end
