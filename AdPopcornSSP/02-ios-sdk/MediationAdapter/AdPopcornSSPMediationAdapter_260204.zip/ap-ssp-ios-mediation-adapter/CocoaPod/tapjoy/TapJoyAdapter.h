//
//  TapJoyAdapter.h
//  AdPopcornSSP
//
//  Created by mick on 2020. 10. 28..
//  Copyright (c) 2020년 igaworks All rights reserved.
//

#import <Tapjoy/Tapjoy.h>
#import <Tapjoy/TJPlacement.h>

// Using pod install / unity
//#import <AdPopcornSSP/AdPopcornSSPAdapter.h>
// else
#import "AdPopcornSSPAdapter.h"

@interface TapJoyAdapter : AdPopcornSSPAdapter
{
}
@end
