//
//  AppLovinMaxDynamicBidAdapter.h
//  AdPopcornSSP
//
//  Created by 김민석 on 2023/06/04.
//  Copyright © 2023 AdPopcorn. All rights reserved.
//

#import <AppLovinSDK/AppLovinSDK.h>

// Using pod install / unity
#import <AdPopcornSSP/AdPopcornSSPAdapter.h>
// else
//#import "AdPopcornSSPAdapter.h"

@interface AppLovinMaxDynamicBidAdapter : AdPopcornSSPAdapter
{
    MAAdView *maxBannerView;
    MAInterstitialAd *maxInterstitialAd, *maxInterstitialVideoAd;
    MARewardedAd *maxRewardVideoAd;
    MAAd *loadedNativeAd;
    MANativeAdLoader *nativeAdLoader;
}

@end

@interface APAppLovinMaxNativeAdRenderer: NSObject
@property (strong, nonatomic) MANativeAdView *appLovinNativeAdView;
@end
