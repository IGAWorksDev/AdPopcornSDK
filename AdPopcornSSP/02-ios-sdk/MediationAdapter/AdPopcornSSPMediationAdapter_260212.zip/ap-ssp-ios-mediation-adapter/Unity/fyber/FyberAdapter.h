//
//  FyberAdapter.h
//  AdPopcornSSP
//
//  Created by mick on 2020. 10. 28..
//  Copyright (c) 2020년 igaworks All rights reserved.
//
#import <IASDKCore/IASDKCore.h>

// Using pod install / unity
#import <AdPopcornSSP/AdPopcornSSPAdapter.h>
// else
//#import "AdPopcornSSPAdapter.h"

@interface FyberAdapter : AdPopcornSSPAdapter
{
    IAAdSpot *_adSpot;
    IANativeAdSpot *_nativeAdSpot;
    IAFullscreenUnitController *_fullscreenUnitController;
    IAVideoContentController *_videoContentController;
    IAViewUnitController *_bannerViewController;
    IAMRAIDContentController *_mraidContentController;
}
@end


@interface APFyberAdapterNativeAdRenderer: NSObject

@property (strong, nonatomic) UIView *adUIView;
@property (weak, nonatomic) UILabel *adTitle;
@property (weak, nonatomic) UILabel *adDescription;
@property (weak, nonatomic) UILabel *callToActionText;
@property (strong, nonatomic) UIView *appIcon;
@property (strong, nonatomic) UIView *mediaView;
@property (nonatomic) CGFloat rating;
@property (nonatomic) CGFloat mediaAspectRatio;

@end
