//
//  UnityAdsAdapter.h
//  AdPopcornSSP
//
//  Created by mick on 2019. 3. 19..
//  Copyright (c) 2019년 igaworks All rights reserved.
//

@import UnityAds;

// Using pod install / unity
#import <AdPopcornSSP/AdPopcornSSPAdapter.h>
// else
//#import "AdPopcornSSPAdapter.h"

@interface UnityAdsAdapter : AdPopcornSSPAdapter
{

}
@end
